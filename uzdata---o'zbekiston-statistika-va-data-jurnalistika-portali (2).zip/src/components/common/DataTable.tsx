import React, { useState, useMemo } from 'react';
import { ChevronUp, ChevronDown, Download, Search, ExternalLink } from 'lucide-react';
import { Statistic } from '../../types';

interface DataTableProps {
  data: Statistic[];
  onSelectStat: (stat: Statistic) => void;
}

export const DataTable: React.FC<DataTableProps> = ({ data, onSelectStat }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof Statistic>('title');
  const [sortAsc, setSortAsc] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState('all');

  const categories = useMemo(() => {
    const set = new Set(data.map((d) => d.category));
    return ['all', ...Array.from(set)];
  }, [data]);

  const filteredAndSorted = useMemo(() => {
    let result = [...data];

    if (categoryFilter !== 'all') {
      result = result.filter((d) => d.category === categoryFilter);
    }

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      result = result.filter(
        (d) =>
          d.title.toLowerCase().includes(q) ||
          d.sourceName.toLowerCase().includes(q) ||
          d.value.toLowerCase().includes(q)
      );
    }

    result.sort((a, b) => {
      const valA = a[sortField] ?? '';
      const valB = b[sortField] ?? '';
      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortAsc ? valA - valB : valB - valA;
      }
      return sortAsc
        ? String(valA).localeCompare(String(valB))
        : String(valB).localeCompare(String(valA));
    });

    return result;
  }, [data, searchTerm, sortField, sortAsc, categoryFilter]);

  const handleSort = (field: keyof Statistic) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  const exportAllCSV = () => {
    const headers = ['Nomi', 'Kategoriya', 'Qiymat', 'Birlik', "O'zgarish", 'Rasmiy Manba', 'Tekshirilgan sana'];
    const rows = filteredAndSorted.map((d) => [
      `"${d.title.replace(/"/g, '""')}"`,
      `"${d.category}"`,
      `"${d.value}"`,
      `"${d.unit}"`,
      `"${d.change || '-'}"`,
      `"${d.sourceName.replace(/"/g, '""')}"`,
      `"${d.verificationDate}"`,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'uzdata-umumiy-jadval.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
      {/* Table Toolbar */}
      <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-900/50">
        <div className="relative flex-1 max-w-sm">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Jadval bo'yicha qidirish..."
            className="w-full pl-9 pr-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            aria-label="Kategoriya bo'yicha saralash"
            className="px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-700 dark:text-slate-300 font-medium focus:outline-hidden"
          >
            <option value="all">Barcha sohalar</option>
            {categories.filter((c) => c !== 'all').map((c) => (
              <option key={c} value={c} className="capitalize">
                {c}
              </option>
            ))}
          </select>

          <button
            onClick={exportAllCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold transition"
          >
            <Download size={14} />
            <span>CSV Eksport</span>
          </button>
        </div>
      </div>

      {/* Table Element */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-100/70 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 font-bold uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
            <tr>
              <th
                onClick={() => handleSort('title')}
                className="py-3 px-4 cursor-pointer hover:text-teal-600 transition"
              >
                <div className="flex items-center gap-1">
                  <span>Ko'rsatkich Nomi</span>
                  {sortField === 'title' && (sortAsc ? <ChevronUp size={14} /> : <ChevronDown size={14} />)}
                </div>
              </th>
              <th
                onClick={() => handleSort('category')}
                className="py-3 px-4 cursor-pointer hover:text-teal-600 transition hidden md:table-cell"
              >
                <div className="flex items-center gap-1">
                  <span>Soha</span>
                  {sortField === 'category' && (sortAsc ? <ChevronUp size={14} /> : <ChevronDown size={14} />)}
                </div>
              </th>
              <th
                onClick={() => handleSort('value')}
                className="py-3 px-4 cursor-pointer hover:text-teal-600 transition text-right"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Joriy Qiymat</span>
                  {sortField === 'value' && (sortAsc ? <ChevronUp size={14} /> : <ChevronDown size={14} />)}
                </div>
              </th>
              <th className="py-3 px-4 hidden sm:table-cell">Dinamika</th>
              <th className="py-3 px-4 hidden lg:table-cell">Rasmiy Manba</th>
              <th className="py-3 px-4 text-center">Batafsil</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
            {filteredAndSorted.map((stat) => (
              <tr
                key={stat.id}
                onClick={() => onSelectStat(stat)}
                className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 cursor-pointer transition"
              >
                <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-white max-w-xs">
                  <div className="truncate font-medium">{stat.title}</div>
                  <div className="text-[11px] text-slate-400 font-normal md:hidden">
                    {stat.category} • {stat.sourceName}
                  </div>
                </td>
                <td className="py-3.5 px-4 hidden md:table-cell">
                  <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 capitalize text-[11px] font-medium">
                    {stat.category}
                  </span>
                </td>
                <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900 dark:text-white">
                  {stat.value}
                </td>
                <td className="py-3.5 px-4 hidden sm:table-cell font-semibold">
                  {stat.change ? (
                    <span className={stat.isPositiveChange ? 'text-emerald-600' : 'text-rose-500'}>
                      {stat.change}
                    </span>
                  ) : (
                    <span className="text-slate-400">-</span>
                  )}
                </td>
                <td className="py-3.5 px-4 hidden lg:table-cell text-slate-500 dark:text-slate-400 truncate max-w-xs">
                  {stat.sourceName}
                </td>
                <td className="py-3.5 px-4 text-center">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectStat(stat);
                    }}
                    className="p-1.5 rounded-lg text-teal-600 hover:bg-teal-50 dark:hover:bg-teal-950/50 transition"
                    title="Grafikni ko'rish"
                  >
                    <ExternalLink size={15} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
        <span>Jami ko'rsatkichlar: {filteredAndSorted.length} ta</span>
        <span>Manba: O'zbekiston Davlat Statistika Registrlari</span>
      </div>
    </div>
  );
};
