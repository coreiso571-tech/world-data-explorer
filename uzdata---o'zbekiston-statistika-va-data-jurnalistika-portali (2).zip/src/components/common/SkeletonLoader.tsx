import React from 'react';

export function StatCardSkeleton() {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs animate-pulse">
      <div className="flex items-center justify-between mb-3">
        <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-1/3"></div>
        <div className="h-5 w-5 bg-slate-200 dark:bg-slate-800 rounded-full"></div>
      </div>
      <div className="h-8 bg-slate-200 dark:bg-slate-800 rounded w-2/3 mb-2"></div>
      <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-1/2 mb-4"></div>
      <div className="h-10 bg-slate-100 dark:bg-slate-800/50 rounded w-full"></div>
    </div>
  );
}

export function ChartSkeleton() {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs animate-pulse">
      <div className="flex justify-between items-center mb-6">
        <div>
          <div className="h-6 bg-slate-200 dark:bg-slate-800 rounded w-48 mb-2"></div>
          <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-64"></div>
        </div>
        <div className="h-8 bg-slate-200 dark:bg-slate-800 rounded w-24"></div>
      </div>
      <div className="h-64 bg-slate-100 dark:bg-slate-800/40 rounded-lg flex items-end p-4 gap-4">
        {[40, 60, 30, 80, 55, 90, 75, 95].map((h, i) => (
          <div
            key={i}
            className="flex-1 bg-slate-200 dark:bg-slate-800 rounded-t"
            style={{ height: `${h}%` }}
          ></div>
        ))}
      </div>
    </div>
  );
}

export function ArticleSkeleton() {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs animate-pulse">
      <div className="h-48 bg-slate-200 dark:bg-slate-800 w-full"></div>
      <div className="p-5">
        <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-24 mb-3"></div>
        <div className="h-6 bg-slate-200 dark:bg-slate-800 rounded w-5/6 mb-2"></div>
        <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-full mb-1"></div>
        <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-4/5 mb-4"></div>
        <div className="flex justify-between items-center pt-3 border-t border-slate-100 dark:border-slate-800">
          <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-28"></div>
          <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-16"></div>
        </div>
      </div>
    </div>
  );
}
