import React, { useState, useEffect } from 'react';
import { 
  X, 
  ExternalLink, 
  CheckCircle, 
  Calendar, 
  Share2, 
  Copy, 
  Check, 
  FileSpreadsheet,
  Info,
  Bookmark
} from 'lucide-react';
import { Statistic } from '../../types';
import { DataChart } from './DataChart';
import { CommentSection } from './CommentSection';
import { userService } from '../../services/userService';

interface StatDetailModalProps {
  stat: Statistic | null;
  onClose: () => void;
  categoryName?: string;
}

export const StatDetailModal: React.FC<StatDetailModalProps> = ({ stat, onClose, categoryName }) => {
  const [copied, setCopied] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);

  useEffect(() => {
    if (stat) {
      setIsBookmarked(userService.isBookmarked(stat.id));
      // Record in user recently viewed pages
      userService.recordView({
        id: stat.id,
        type: 'stat',
        title: stat.title,
        slug: stat.slug,
        category: stat.category,
        value: stat.value,
      });
    }
  }, [stat]);

  if (!stat) return null;

  const handleToggleBookmark = () => {
    const newState = userService.toggleBookmark(stat.id);
    setIsBookmarked(newState);
  };

  const handleCopyLink = () => {
    const url = `${window.location.origin}/#statistika/${stat.slug}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/70">
          <div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-md bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300">
                {categoryName || stat.category}
              </span>
              <span className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                <CheckCircle size={14} />
                Tasdiqlangan Rasmiy Statistika
              </span>
              <span className="inline-flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
                <Calendar size={13} />
                {stat.verificationDate}
              </span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white leading-tight">
              {stat.title}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleToggleBookmark}
              className={`p-2 rounded-xl transition flex items-center gap-1.5 text-xs font-semibold cursor-pointer ${
                isBookmarked
                  ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/40 shadow-xs'
                  : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title={isBookmarked ? "Saqlanganlardan o'chirish" : "Materialni saqlash"}
            >
              <Bookmark size={16} className={isBookmarked ? "fill-amber-400 text-amber-400" : ""} />
              <span className="hidden sm:inline">{isBookmarked ? "Saqlangan" : "Saqlash"}</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              aria-label="Yopish"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Big Key Figures */}
          <div className="flex flex-wrap items-baseline gap-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800">
            <div>
              <p className="text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400 font-semibold mb-1">
                Joriy Ko'rsatkich
              </p>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-extrabold font-mono text-slate-900 dark:text-white">
                  {stat.value}
                </span>
                <span className="text-slate-500 font-mono text-sm">{stat.unit}</span>
              </div>
            </div>
            {stat.change && (
              <div className="sm:border-l sm:border-slate-200 dark:sm:border-slate-700 sm:pl-4">
                <p className="text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400 font-semibold mb-1">
                  Dinamika
                </p>
                <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                  {stat.change}
                </span>
              </div>
            )}
          </div>

          {/* Interactive Chart Section */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs">
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-2 flex items-center gap-2">
              <FileSpreadsheet size={16} className="text-teal-600 dark:text-teal-400" />
              Tarixiy va Qiyosiy Ko'rsatkichlar Grafigi
            </h4>
            <DataChart
              data={stat.dataSeries}
              type={stat.chartType}
              unit={stat.unit}
              title={stat.title}
              height={320}
              showToggle={true}
              color="#0d9488"
            />
          </div>

          {/* Detailed Editorial Description */}
          <div className="prose prose-slate dark:prose-invert max-w-none text-sm leading-relaxed text-slate-700 dark:text-slate-300 bg-slate-50/50 dark:bg-slate-900/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <Info size={15} className="text-teal-600 dark:text-teal-400" />
              Tahliliy Sharh va Metodologiya
            </h4>
            <p className="whitespace-pre-line">{stat.description}</p>
          </div>

          {/* Mandatory Source & Attribution */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200/50 dark:border-teal-900/40 text-xs">
            <div>
              <p className="text-slate-500 dark:text-slate-400 mb-0.5 font-medium">Rasmiy Manba:</p>
              <p className="font-semibold text-slate-900 dark:text-white text-sm">
                {stat.sourceName}
              </p>
            </div>
            {stat.sourceUrl && (
              <a
                href={stat.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-medium shadow-xs transition"
              >
                <span>Birlamchi Manbani Ochish</span>
                <ExternalLink size={13} />
              </a>
            )}
          </div>

          {/* Community & Comments Section */}
          <CommentSection targetId={stat.id} targetTitle={stat.title} />
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80">
          <button
            onClick={handleCopyLink}
            className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition"
          >
            {copied ? <Check size={14} className="text-emerald-500" /> : <Share2 size={14} />}
            <span>{copied ? "Havola nusxalandi!" : "Ulashish / Havola"}</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-white transition"
          >
            Yopish
          </button>
        </div>
      </div>
    </div>
  );
};
