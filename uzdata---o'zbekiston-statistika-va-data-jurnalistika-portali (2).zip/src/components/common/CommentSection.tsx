import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  ThumbsUp,
  ThumbsDown,
  Send,
  ShieldAlert,
  Sparkles,
  CheckCircle2,
  Clock,
  User,
  AlertCircle,
  Lightbulb,
  HelpCircle,
  Flag
} from 'lucide-react';
import { commentService, CommentItem } from '../../services/commentService';
import { useAuth } from '../../context/AuthContext';

interface CommentSectionProps {
  targetId: string;
  targetTitle: string;
}

export const CommentSection: React.FC<CommentSectionProps> = ({
  targetId,
  targetTitle,
}) => {
  const { user } = useAuth();
  const [comments, setComments] = useState<CommentItem[]>([]);
  const [activeFilter, setActiveFilter] = useState<'all' | 'fikr' | 'taklif' | 'savol'>('all');

  // New comment form
  const [authorName, setAuthorName] = useState(user?.displayName || '');
  const [commentText, setCommentText] = useState('');
  const [commentType, setCommentType] = useState<'fikr' | 'taklif' | 'savol'>('fikr');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [cooldownSeconds, setCooldownSeconds] = useState(0);
  const [reportedIds, setReportedIds] = useState<Record<string, boolean>>({});
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Load comments
  const loadComments = () => {
    const list = commentService.getCommentsForTarget(targetId);
    setComments(list);
  };

  useEffect(() => {
    loadComments();
    const handleUpdate = () => loadComments();
    window.addEventListener('uzdata_comments_updated', handleUpdate);
    return () => window.removeEventListener('uzdata_comments_updated', handleUpdate);
  }, [targetId]);

  // Anti-spam countdown timer
  useEffect(() => {
    if (cooldownSeconds > 0) {
      const timer = setTimeout(() => setCooldownSeconds((c) => c - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [cooldownSeconds]);

  const handleVote = (commentId: string, direction: 'up' | 'down') => {
    commentService.voteComment(commentId, direction);
    loadComments();
  };

  const handleReport = (commentId: string) => {
    setReportedIds((prev) => ({ ...prev, [commentId]: true }));
    setStatusMessage("Rahmat! Ushbu sharh moderatorlarga tekshirish uchun yuborildi.");
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cooldownSeconds > 0) return;

    const trimmed = commentText.trim();
    if (trimmed.length < 5) {
      setStatusMessage("Fikr kamida 5 ta belgidan iborat bo'lishi kerak.");
      return;
    }

    setIsSubmitting(true);

    const name = authorName.trim() || user?.displayName || 'Anonim Kuzatuvchi';

    commentService.addComment({
      targetId,
      author: name,
      authorRole: user ? 'Ro\'yxatdan o\'tgan tahlilchi' : 'Hamjamiyat a\'zosi',
      text: trimmed,
      type: commentType,
    });

    setCommentText('');
    setIsSubmitting(false);
    setCooldownSeconds(15); // 15 seconds anti-spam cooldown
    setStatusMessage("Fikringiz muvaffaqiyatli chop etildi!");
    setTimeout(() => setStatusMessage(null), 3500);
  };

  const filteredComments = comments.filter((c) => {
    if (activeFilter === 'all') return true;
    return c.type === activeFilter;
  });

  return (
    <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <MessageSquare size={18} className="text-teal-600 dark:text-lime-400" />
            <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
              Fikrlar va Hamjamiyat Muhokamasi
            </h3>
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-teal-500/15 text-teal-700 dark:text-lime-400">
              {comments.length}
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Ushbu ko'rsatkich bo'yicha tahliliy mulohazalar, savollar va takliflar almashing.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveFilter('all')}
            className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer ${
              activeFilter === 'all'
                ? 'bg-white dark:bg-slate-800 text-teal-700 dark:text-lime-400 shadow-xs'
                : 'text-slate-500'
            }`}
          >
            Barchasi
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('taklif')}
            className={`px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1 transition cursor-pointer ${
              activeFilter === 'taklif'
                ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 shadow-xs'
                : 'text-slate-500'
            }`}
          >
            <Lightbulb size={12} />
            <span>Takliflar</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('savol')}
            className={`px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1 transition cursor-pointer ${
              activeFilter === 'savol'
                ? 'bg-white dark:bg-slate-800 text-sky-600 dark:text-sky-400 shadow-xs'
                : 'text-slate-500'
            }`}
          >
            <HelpCircle size={12} />
            <span>Savollar</span>
          </button>
        </div>
      </div>

      {statusMessage && (
        <div className="mb-4 p-3 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-500/30 text-teal-800 dark:text-lime-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 size={16} className="text-teal-600 dark:text-lime-400 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* New Comment Submission Box */}
      <form
        onSubmit={handleSubmit}
        className="p-4 sm:p-5 rounded-2xl bg-slate-50/80 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 mb-6 shadow-xs"
      >
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-3">
          {/* Author Name */}
          <div className="flex items-center gap-2 flex-1">
            <div className="w-8 h-8 rounded-full bg-teal-500/15 text-teal-600 dark:text-lime-400 flex items-center justify-center font-bold text-xs shrink-0">
              <User size={14} />
            </div>
            <input
              type="text"
              value={authorName}
              onChange={(e) => setAuthorName(e.target.value)}
              placeholder="Ismingiz yoki taxallusingiz..."
              className="w-full sm:max-w-xs px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden focus:border-teal-500"
            />
          </div>

          {/* Type Selector (Fikr, Savol, Taklif) */}
          <div className="flex items-center gap-1 text-[11px]">
            <button
              type="button"
              onClick={() => setCommentType('fikr')}
              className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
                commentType === 'fikr'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
              }`}
            >
              Fikr
            </button>
            <button
              type="button"
              onClick={() => setCommentType('savol')}
              className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
                commentType === 'savol'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
              }`}
            >
              Savol
            </button>
            <button
              type="button"
              onClick={() => setCommentType('taklif')}
              className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
                commentType === 'taklif'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
              }`}
            >
              Taklif
            </button>
          </div>
        </div>

        {/* Textarea */}
        <textarea
          rows={3}
          value={commentText}
          onChange={(e) => setCommentText(e.target.value)}
          maxLength={600}
          placeholder="O'zbekiston statistikasi, hisoblash metodologiyasi yoki tendensiyalar haqida fikr yoki taklif qoldiring..."
          className="w-full p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:border-teal-500 dark:focus:border-lime-400 transition"
        />

        {/* Footer with Anti-Spam Indicator & Submit */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-3">
          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            <span className="flex items-center gap-1 font-mono">
              <ShieldAlert size={12} className="text-teal-500" />
              <span>Anti-Spam Himoya</span>
            </span>
            <span>•</span>
            <span className="font-mono">{commentText.length} / 600 belgi</span>
          </div>

          <button
            type="submit"
            disabled={isSubmitting || cooldownSeconds > 0 || commentText.trim().length < 5}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-teal-500 to-lime-500 hover:opacity-95 text-slate-950 font-bold text-xs shadow-sm transition disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {cooldownSeconds > 0 ? (
              <>
                <Clock size={13} className="animate-spin" />
                <span>Kuting ({cooldownSeconds}s)</span>
              </>
            ) : (
              <>
                <Send size={13} />
                <span>Chop etish</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* Comments List */}
      <div className="space-y-3">
        {filteredComments.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-50/50 dark:bg-slate-900/30 border border-dashed border-slate-200 dark:border-slate-800 text-center text-xs text-slate-400">
            <MessageSquare size={24} className="mx-auto mb-2 text-slate-300 dark:text-slate-600" />
            <p>Hozircha fikrlar mavjud emas. Birinchi bo'lib fikr yoki taklif bildiring!</p>
          </div>
        ) : (
          filteredComments.map((item) => {
            const userVote = commentService.getUserVote(item.id);
            const isReported = reportedIds[item.id];

            return (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900/70 border border-slate-200/80 dark:border-slate-800/80 shadow-xs hover:border-teal-500/40 transition"
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-teal-500/20 to-lime-500/20 text-teal-700 dark:text-lime-400 font-bold text-xs flex items-center justify-center shrink-0">
                      {item.author.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900 dark:text-white">
                          {item.author}
                        </span>
                        {item.type === 'taklif' && (
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-amber-500/15 text-amber-600 dark:text-amber-400">
                            Taklif
                          </span>
                        )}
                        {item.type === 'savol' && (
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-sky-500/15 text-sky-600 dark:text-sky-400">
                            Savol
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400">
                        {item.authorRole} • {new Date(item.createdAt).toLocaleDateString('uz-UZ')}
                      </span>
                    </div>
                  </div>

                  {/* Report Flag */}
                  <button
                    type="button"
                    onClick={() => handleReport(item.id)}
                    disabled={isReported}
                    className={`p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition ${
                      isReported ? 'text-rose-500 opacity-60' : ''
                    }`}
                    title={isReported ? "Shikoyat qilingan" : "Spam haqida xabar berish"}
                  >
                    <Flag size={13} />
                  </button>
                </div>

                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed mb-3">
                  {item.text}
                </p>

                {/* Vote Buttons (Thumbs Up / Thumbs Down) */}
                <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                  <button
                    type="button"
                    onClick={() => handleVote(item.id, 'up')}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition cursor-pointer ${
                      userVote === 'up'
                        ? 'bg-teal-500/20 text-teal-700 dark:text-lime-400 font-bold'
                        : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <ThumbsUp size={13} />
                    <span>{item.upvotes}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleVote(item.id, 'down')}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition cursor-pointer ${
                      userVote === 'down'
                        ? 'bg-rose-500/20 text-rose-600 font-bold'
                        : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <ThumbsDown size={13} />
                    <span>{item.downvotes}</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
