import React, { useState, useEffect, useMemo } from 'react';
import { Search, X, TrendingUp, BookOpen, MapPin, ArrowRight } from 'lucide-react';
import { Statistic, Article } from '../../types';
import { REGIONS_DATA } from '../../data/seedData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  statistics: Statistic[];
  articles: Article[];
  onSelectStat: (stat: Statistic) => void;
  onSelectArticle: (article: Article) => void;
  onSelectRegion?: (regionName: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  statistics,
  articles,
  onSelectStat,
  onSelectArticle,
  onSelectRegion,
}) => {
  const [query, setQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'stats' | 'articles' | 'regions'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [selectedDatePeriod, setSelectedDatePeriod] = useState<string>('all');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Debounced search results with advanced category, date, and region filtering
  const filteredResults = useMemo(() => {
    const q = query.trim().toLowerCase();

    let matchedStats = statistics.filter((s) => {
      // Category filter
      if (selectedCategory !== 'all' && s.category !== selectedCategory) return false;
      // Date filter
      if (selectedDatePeriod === '2026' && !s.verificationDate.startsWith('2026')) return false;
      if (selectedDatePeriod === '2025' && !s.verificationDate.startsWith('2025')) return false;
      if (selectedDatePeriod === 'recent5' && !s.dataSeries.some((d) => ['2022', '2023', '2024', '2025', '2026'].includes(d.label))) return false;

      // Text search
      if (!q) return true;
      return (
        s.title.toLowerCase().includes(q) ||
        s.category.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q) ||
        s.sourceName.toLowerCase().includes(q)
      );
    });

    let matchedArticles = articles.filter((a) => {
      // Category filter
      if (selectedCategory !== 'all' && a.category !== selectedCategory) return false;
      // Date filter
      if (selectedDatePeriod === '2026' && !a.createdAt.startsWith('2026')) return false;

      // Text search
      if (!q) return true;
      return (
        a.title.toLowerCase().includes(q) ||
        a.excerpt.toLowerCase().includes(q) ||
        a.category.toLowerCase().includes(q) ||
        a.tags.some((t) => t.toLowerCase().includes(q))
      );
    });

    let matchedRegions = REGIONS_DATA.filter((r) => {
      if (selectedRegion !== 'all' && r.name !== selectedRegion) return false;
      if (!q) return true;
      return (
        r.name.toLowerCase().includes(q) ||
        r.center.toLowerCase().includes(q)
      );
    });

    if (!q && selectedCategory === 'all' && selectedRegion === 'all' && selectedDatePeriod === 'all') {
      return {
        stats: statistics.slice(0, 4),
        articles: articles.slice(0, 3),
        regions: REGIONS_DATA.slice(0, 4),
      };
    }

    return {
      stats: matchedStats,
      articles: matchedArticles,
      regions: matchedRegions,
    };
  }, [query, selectedCategory, selectedRegion, selectedDatePeriod, statistics, articles]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-start justify-center p-4 pt-16 sm:pt-24 animate-in fade-in duration-150">
      <div 
        className="relative w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Box */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <Search size={20} className="text-slate-400 mr-3 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Statistika, YaIM, aholi, narxlar, viloyatlar bo'yicha qidiruv..."
            autoFocus
            className="w-full bg-transparent text-sm sm:text-base text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 mr-2"
            >
              <X size={16} />
            </button>
          )}
          <kbd className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-mono text-slate-400 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded">
            ESC
          </kbd>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 px-4 py-2 border-b border-slate-100 dark:border-slate-800 text-xs bg-slate-50/30 dark:bg-slate-900/30 overflow-x-auto">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1 rounded-lg font-medium transition ${
              filterType === 'all'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Barchasi
          </button>
          <button
            onClick={() => setFilterType('stats')}
            className={`px-3 py-1 rounded-lg font-medium transition flex items-center gap-1 ${
              filterType === 'stats'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <TrendingUp size={12} />
            Statistika ({filteredResults.stats.length})
          </button>
          <button
            onClick={() => setFilterType('articles')}
            className={`px-3 py-1 rounded-lg font-medium transition flex items-center gap-1 ${
              filterType === 'articles'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <BookOpen size={12} />
            Maqolalar ({filteredResults.articles.length})
          </button>
          <button
            onClick={() => setFilterType('regions')}
            className={`px-3 py-1 rounded-lg font-medium transition flex items-center gap-1 ${
              filterType === 'regions'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <MapPin size={12} />
            Hududlar ({filteredResults.regions.length})
          </button>
        </div>

        {/* Advanced Filters Toolbar (Category, Date, Region) */}
        <div className="grid grid-cols-3 gap-2 px-4 py-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 text-[11px]">
          <div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 focus:outline-hidden focus:border-teal-500 text-[11px]"
            >
              <option value="all">Soha: Barchasi</option>
              <option value="demografiya">Demografiya</option>
              <option value="iqtisodiyot">Iqtisodiyot</option>
              <option value="talim">Ta'lim</option>
              <option value="it-biznes">IT & Biznes</option>
              <option value="turizm">Turizm</option>
              <option value="narxlar">Narxlar</option>
              <option value="hududlar">Hududlar</option>
            </select>
          </div>
          <div>
            <select
              value={selectedDatePeriod}
              onChange={(e) => setSelectedDatePeriod(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 focus:outline-hidden focus:border-teal-500 text-[11px]"
            >
              <option value="all">Davr: Barcha yillar</option>
              <option value="2026">2026-yil</option>
              <option value="2025">2025-yil</option>
              <option value="recent5">So'nggi 5 yil</option>
            </select>
          </div>
          <div>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 focus:outline-hidden focus:border-teal-500 text-[11px]"
            >
              <option value="all">Hudud: Barchasi</option>
              {REGIONS_DATA.map((r) => (
                <option key={r.id} value={r.name}>
                  {r.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Results List */}
        <div className="p-3 max-h-[60vh] overflow-y-auto space-y-4 text-xs">
          {/* Statistics Results */}
          {(filterType === 'all' || filterType === 'stats') && filteredResults.stats.length > 0 && (
            <div>
              <p className="px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Statistika va Dinamika
              </p>
              <div className="space-y-1 mt-1">
                {filteredResults.stats.map((stat) => (
                  <div
                    key={stat.id}
                    onClick={() => {
                      onSelectStat(stat);
                      onClose();
                    }}
                    className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer transition group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold shrink-0">
                        <TrendingUp size={16} />
                      </div>
                      <div>
                        <h4 className="font-semibold text-slate-900 dark:text-white group-hover:text-teal-600 dark:group-hover:text-teal-400 transition text-sm">
                          {stat.title}
                        </h4>
                        <p className="text-slate-400 text-[11px] capitalize">{stat.category} • {stat.sourceName}</p>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="font-mono font-bold text-slate-900 dark:text-white text-sm">
                        {stat.value}
                      </span>
                      {stat.change && (
                        <p className="text-[10px] font-semibold text-emerald-600">{stat.change}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Articles Results */}
          {(filterType === 'all' || filterType === 'articles') && filteredResults.articles.length > 0 && (
            <div>
              <p className="px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Data Jurnalistika Maqolalari
              </p>
              <div className="space-y-1 mt-1">
                {filteredResults.articles.map((art) => (
                  <div
                    key={art.id}
                    onClick={() => {
                      onSelectArticle(art);
                      onClose();
                    }}
                    className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer transition group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold shrink-0">
                        <BookOpen size={16} />
                      </div>
                      <div>
                        <h4 className="font-semibold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition text-sm line-clamp-1">
                          {art.title}
                        </h4>
                        <p className="text-slate-400 text-[11px]">{art.readingTime} • {art.author}</p>
                      </div>
                    </div>
                    <ArrowRight size={14} className="text-slate-400 group-hover:text-blue-500 group-hover:translate-x-1 transition shrink-0" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Regions Results */}
          {(filterType === 'all' || filterType === 'regions') && filteredResults.regions.length > 0 && (
            <div>
              <p className="px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Hududiy Ko'rsatkichlar
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-1">
                {filteredResults.regions.map((reg) => (
                  <div
                    key={reg.id}
                    onClick={() => {
                      if (onSelectRegion) onSelectRegion(reg.name);
                      onClose();
                    }}
                    className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 hover:border-teal-500/40 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer transition"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-slate-900 dark:text-white text-xs">{reg.name}</span>
                      <span className="text-[11px] text-teal-600 font-mono font-semibold">{reg.populationStr}</span>
                    </div>
                    <p className="text-slate-400 text-[10px]">
                      Oylik maosh: {reg.avgSalaryStr} so'm • YaIM ulushi: {reg.gdpShare}%
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Empty State */}
          {filteredResults.stats.length === 0 &&
            filteredResults.articles.length === 0 &&
            filteredResults.regions.length === 0 && (
              <div className="py-12 text-center text-slate-400">
                <Search size={32} className="mx-auto mb-2 opacity-30" />
                <p className="font-medium text-sm">"{query}" bo'yicha ma'lumot topilmadi</p>
                <p className="text-xs text-slate-500 mt-1">Boshqa so'z bilan qidirib ko'ring (masalan: YaIM, Aholi, IT, Samarqand)</p>
              </div>
            )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/70 text-[11px] text-slate-400 flex items-center justify-between">
          <span>UZDATA Global Qidiruv Tizimi</span>
          <div className="flex items-center gap-3">
            <span>Tanlash: <kbd className="font-mono bg-white dark:bg-slate-800 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700">Enter</kbd></span>
            <span>Yopish: <kbd className="font-mono bg-white dark:bg-slate-800 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700">ESC</kbd></span>
          </div>
        </div>
      </div>
    </div>
  );
};
