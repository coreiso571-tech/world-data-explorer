import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, CheckCircle2, ArrowRight, Download, Bookmark } from 'lucide-react';
import { Statistic } from '../../types';
import { DataChart } from './DataChart';
import { userService } from '../../services/userService';

interface StatCardProps {
  stat: Statistic;
  onSelect: (stat: Statistic) => void;
  categoryName?: string;
}

export const StatCard: React.FC<StatCardProps> = ({ stat, onSelect, categoryName }) => {
  const isPositive = stat.isPositiveChange ?? true;
  const [isBookmarked, setIsBookmarked] = useState(false);

  useEffect(() => {
    setIsBookmarked(userService.isBookmarked(stat.id));
    const handleUpdate = () => setIsBookmarked(userService.isBookmarked(stat.id));
    window.addEventListener('uzdata_bookmarks_updated', handleUpdate);
    return () => window.removeEventListener('uzdata_bookmarks_updated', handleUpdate);
  }, [stat.id]);

  const handleBookmarkClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = userService.toggleBookmark(stat.id);
    setIsBookmarked(updated);
  };

  return (
    <div
      onClick={() => onSelect(stat)}
      className="group relative bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-xl p-5 shadow-xs hover:shadow-lg hover:border-teal-500/50 dark:hover:border-teal-500/40 transition-all duration-200 cursor-pointer flex flex-col justify-between"
    >
      <div>
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              {categoryName || stat.category}
            </span>
            {stat.status === 'Draft' && (
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300">
                Qoralama
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <button
              type="button"
              onClick={handleBookmarkClick}
              className="p-1 rounded-md text-slate-400 hover:text-amber-500 transition cursor-pointer"
              title={isBookmarked ? "Saqlanganlardan o'chirish" : "Profilga saqlash"}
            >
              <Bookmark size={14} className={isBookmarked ? "fill-amber-400 text-amber-400" : ""} />
            </button>
            <div className="flex items-center gap-1 text-teal-600 dark:text-teal-400 font-medium">
              <CheckCircle2 size={13} className="shrink-0" />
              <span>Tasdiqlangan</span>
            </div>
          </div>
        </div>

        <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors line-clamp-1 mb-2">
          {stat.title}
        </h3>

        <div className="flex items-baseline gap-2 mb-3">
          <span className="text-3xl font-extrabold tracking-tight font-mono text-slate-950 dark:text-slate-50">
            {stat.value}
          </span>
          {stat.change && (
            <span
              className={`inline-flex items-center gap-0.5 text-xs font-semibold px-1.5 py-0.5 rounded-full ${
                isPositive
                  ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400'
                  : 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400'
              }`}
            >
              {isPositive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
              {stat.change}
            </span>
          )}
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-4 leading-relaxed">
          {stat.description}
        </p>

        {stat.dataSeries && stat.dataSeries.length > 0 && (
          <div className="h-28 -mx-2 mb-2 pointer-events-none">
            <DataChart
              data={stat.dataSeries}
              type={stat.chartType === 'donut' ? 'donut' : 'area'}
              unit={stat.unit}
              height={110}
              color="#0d9488"
            />
          </div>
        )}
      </div>

      <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
        <div className="truncate pr-2">
          <span className="font-medium text-slate-700 dark:text-slate-300">Manba:</span> {stat.sourceName}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (!stat.dataSeries || stat.dataSeries.length === 0) return;
              const headers = ["Davr", `Qiymat (${stat.unit})`, "Izoh"];
              const rows = stat.dataSeries.map((d) => [`"${d.label}"`, d.value, `"${d.note || ''}"`]);
              const csv = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
              const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
              const url = URL.createObjectURL(blob);
              const link = document.createElement('a');
              link.href = url;
              link.download = `${stat.slug || 'statistika'}-uzdata.csv`;
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              URL.revokeObjectURL(url);
            }}
            className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold transition hover:text-teal-600 dark:hover:text-lime-400"
            title="CSV yuklash"
          >
            <Download size={11} className="text-teal-600 dark:text-lime-400" />
            <span>CSV</span>
          </button>
          <div className="flex items-center gap-1 font-semibold text-teal-600 dark:text-teal-400 group-hover:translate-x-0.5 transition-transform">
            <span>Tahlil</span>
            <ArrowRight size={12} />
          </div>
        </div>
      </div>
    </div>
  );
};
