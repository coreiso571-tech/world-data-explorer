import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { 
  Download, 
  ChevronDown, 
  FileSpreadsheet, 
  Image as ImageIcon, 
  Table as TableIcon, 
  BarChart3, 
  LineChart as LineIcon,
  Check,
  Sparkles,
  PieChart as PieIcon
} from 'lucide-react';
import { ChartType, DataPoint } from '../../types';
import { useTheme } from '../../context/ThemeContext';

interface DataChartProps {
  data: DataPoint[];
  type: ChartType;
  unit?: string;
  title?: string;
  color?: string;
  height?: number;
  showToggle?: boolean;
}

const COLORS = ['#0d9488', '#10b981', '#06b6d4', '#6366f1', '#f59e0b', '#ec4899', '#8b5cf6', '#f97316'];

export const DataChart: React.FC<DataChartProps> = ({
  data,
  type = 'line',
  unit = '',
  title = 'Statistika Grafigi',
  color = '#0d9488',
  height = 320,
  showToggle = false,
}) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const [activeType, setActiveType] = useState<ChartType>(type);
  const [viewTable, setViewTable] = useState(false);
  const [exportMenuOpen, setExportMenuOpen] = useState(false);
  const [exportStatus, setExportStatus] = useState<string | null>(null);
  const [disabledPoints, setDisabledPoints] = useState<Record<string, boolean>>({});

  const displayData = useMemo(() => {
    const active = data.filter((d) => !disabledPoints[d.label]);
    return active.length > 0 ? active : data;
  }, [data, disabledPoints]);

  const containerRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setExportMenuOpen(false);
      }
    };
    if (exportMenuOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [exportMenuOpen]);

  // Export to CSV
  const exportCSV = () => {
    if (!data || data.length === 0) return;
    setExportStatus('csv_success');
    setExportMenuOpen(false);

    const headers = ["Ko'rsatkich / Yil", `Qiymat (${unit || 'Birlik'})`, 'Izoh'];
    const rows = data.map((d) => [
      `"${String(d.label).replace(/"/g, '""')}"`,
      d.value,
      `"${String(d.note || '').replace(/"/g, '""')}"`,
    ]);
    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    const safeTitle = (title || 'uzdata-statistika')
      .toLowerCase()
      .replace(/[^a-z0-9а-яёўқғҳ]+/gi, '-')
      .replace(/^-|-$/g, '');
    
    link.setAttribute('href', url);
    link.setAttribute('download', `${safeTitle}-uzdata.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setTimeout(() => setExportStatus(null), 2500);
  };

  // Export visual chart to PNG image via HTML5 Canvas
  const exportPNG = async () => {
    if (!data || data.length === 0) return;
    setExportStatus('png_loading');
    setExportMenuOpen(false);

    try {
      const chartEl = containerRef.current?.querySelector('.recharts-wrapper svg') as SVGElement | null;
      const safeTitle = (title || 'uzdata-statistika')
        .toLowerCase()
        .replace(/[^a-z0-9а-яёўқғҳ]+/gi, '-')
        .replace(/^-|-$/g, '');

      const canvasWidth = 900;
      const canvasHeight = 560;
      const canvas = document.createElement('canvas');
      canvas.width = canvasWidth * 2; // 2x Retina resolution
      canvas.height = canvasHeight * 2;
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        throw new Error('Canvas context not available');
      }

      ctx.scale(2, 2);

      // 1. Draw premium background
      const bgColor = isDark ? '#081225' : '#ffffff';
      ctx.fillStyle = bgColor;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

      // Subtle gradient highlight
      const grad = ctx.createLinearGradient(0, 0, canvasWidth, canvasHeight);
      if (isDark) {
        grad.addColorStop(0, 'rgba(13, 148, 136, 0.12)');
        grad.addColorStop(0.5, 'rgba(8, 18, 37, 0.95)');
        grad.addColorStop(1, 'rgba(163, 230, 53, 0.08)');
      } else {
        grad.addColorStop(0, 'rgba(240, 253, 250, 0.8)');
        grad.addColorStop(1, 'rgba(255, 255, 255, 1)');
      }
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

      // Top glowing banner strip (Navy/Lime)
      const topBar = ctx.createLinearGradient(0, 0, canvasWidth, 0);
      topBar.addColorStop(0, '#0d9488');
      topBar.addColorStop(0.5, '#a3e635');
      topBar.addColorStop(1, '#10b981');
      ctx.fillStyle = topBar;
      ctx.fillRect(0, 0, canvasWidth, 5);

      // 2. Draw Header
      // Portal badge
      ctx.font = 'bold 11px system-ui, -apple-system, sans-serif';
      ctx.fillStyle = isDark ? '#a3e635' : '#0d9488';
      ctx.fillText("UZDATA • O'ZBEKISTON MILLIY MA'LUMOTLAR PORTALI", 36, 38);

      // Chart Title
      ctx.font = 'bold 20px system-ui, -apple-system, sans-serif';
      ctx.fillStyle = isDark ? '#ffffff' : '#0f172a';
      const cleanTitle = title || "Statistik Ko'rsatkich Grafigi";
      ctx.fillText(cleanTitle.slice(0, 55), 36, 68);

      // Subtitle / Unit
      ctx.font = '12px system-ui, -apple-system, sans-serif';
      ctx.fillStyle = isDark ? '#94a3b8' : '#64748b';
      ctx.fillText(`Birlik: ${unit || "Ko'rsatkich"}  •  Sanasi: ${new Date().toLocaleDateString('uz-UZ')}`, 36, 88);

      // 3. Render Chart visual
      if (chartEl && !viewTable) {
        const svgClone = chartEl.cloneNode(true) as SVGElement;
        svgClone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
        svgClone.setAttribute('width', `${canvasWidth - 72}`);
        svgClone.setAttribute('height', `${canvasHeight - 165}`);

        // Ensure text nodes have visible fill
        const textElements = svgClone.querySelectorAll('text');
        textElements.forEach((t) => {
          if (!t.getAttribute('fill') || t.getAttribute('fill') === 'currentColor') {
            t.setAttribute('fill', isDark ? '#cbd5e1' : '#475569');
          }
        });

        const svgData = new XMLSerializer().serializeToString(svgClone);
        const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
        const url = URL.createObjectURL(svgBlob);

        const img = new Image();
        img.crossOrigin = 'anonymous';
        await new Promise((resolve) => {
          img.onload = () => {
            ctx.drawImage(img, 36, 105, canvasWidth - 72, canvasHeight - 165);
            URL.revokeObjectURL(url);
            resolve(true);
          };
          img.onerror = () => {
            URL.revokeObjectURL(url);
            resolve(false);
          };
          img.src = url;
        });
      } else {
        // Fallback drawing if chart DOM wasn't rendered yet
        ctx.fillStyle = isDark ? '#334155' : '#cbd5e1';
        ctx.font = '14px monospace';
        ctx.fillText("Jadval ko'rinishidagi ma'lumotlar", 36, 200);
      }

      // 4. Draw Footer & Attribution
      ctx.fillStyle = isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)';
      ctx.fillRect(36, canvasHeight - 45, canvasWidth - 72, 1);

      ctx.font = '11px system-ui, -apple-system, sans-serif';
      ctx.fillStyle = isDark ? '#64748b' : '#94a3b8';
      ctx.fillText("Manba: Rasmiy davlat statistikasi va Markaziy Bank reestrlari  |  uzdata.uz", 36, canvasHeight - 20);

      ctx.font = 'bold 11px system-ui, -apple-system, sans-serif';
      ctx.fillStyle = isDark ? '#a3e635' : '#0d9488';
      const devNote = "Sayt Asoschisi: Muhammadiso Akbarov";
      const devWidth = ctx.measureText(devNote).width;
      ctx.fillText(devNote, canvasWidth - 36 - devWidth, canvasHeight - 20);

      // 5. Download PNG
      canvas.toBlob((blob) => {
        if (!blob) return;
        const pngUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = pngUrl;
        link.download = `${safeTitle}-uzdata-grafik.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(pngUrl);
        setExportStatus('png_success');
        setTimeout(() => setExportStatus(null), 2500);
      }, 'image/png');
    } catch (err) {
      console.error('Failed to export PNG chart:', err);
      setExportStatus(null);
    }
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const point = payload[0];
      return (
        <div className="bg-slate-900/95 dark:bg-[#071120]/95 text-white p-3 rounded-xl shadow-2xl border border-teal-500/30 text-xs backdrop-blur-md">
          <p className="font-semibold text-slate-300 mb-1">{label}</p>
          <p className="text-lime-400 font-mono text-sm font-bold flex items-center gap-1">
            <span>{typeof point.value === 'number' ? point.value.toLocaleString('uz-UZ') : point.value}</span>
            <span className="text-teal-300 text-xs font-normal">{unit}</span>
          </p>
          {point.payload?.note && (
            <p className="text-slate-400 text-[10px] mt-1.5 italic border-t border-slate-800 pt-1">
              {point.payload.note}
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center bg-slate-50 dark:bg-slate-900/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-400 text-sm">
        Ushbu ko'rsatkich uchun grafik ma'lumotlari kiritilmagan
      </div>
    );
  }

  return (
    <div className="w-full relative" ref={containerRef}>
      {/* Top Controls: Unit & 'Export Options' Dropdown */}
      <div className="flex items-center justify-between mb-3 text-xs gap-2">
        <span className="text-slate-500 dark:text-slate-400 font-medium font-mono truncate">
          Birlik: <span className="font-semibold text-slate-700 dark:text-slate-300">{unit || "Ko'rsatkich"}</span>
        </span>

        <div className="flex items-center gap-2 shrink-0">
          {/* Chart Type Toggle */}
          {showToggle && (
            <div className="flex bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => { setActiveType('line'); setViewTable(false); }}
                className={`p-1.5 rounded-md transition ${activeType === 'line' && !viewTable ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs' : 'text-slate-500'}`}
                title="Chiziqli grafik"
              >
                <LineIcon size={14} />
              </button>
              <button
                type="button"
                onClick={() => { setActiveType('bar'); setViewTable(false); }}
                className={`p-1.5 rounded-md transition ${activeType === 'bar' && !viewTable ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs' : 'text-slate-500'}`}
                title="Ustunli grafik"
              >
                <BarChart3 size={14} />
              </button>
              <button
                type="button"
                onClick={() => { setActiveType('donut'); setViewTable(false); }}
                className={`p-1.5 rounded-md transition ${activeType === 'donut' && !viewTable ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs' : 'text-slate-500'}`}
                title="Doiraviy diagramma"
              >
                <PieIcon size={14} />
              </button>
              <button
                type="button"
                onClick={() => setViewTable(!viewTable)}
                className={`p-1.5 rounded-md transition ${viewTable ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs' : 'text-slate-500'}`}
                title="Jadval ko'rinishi"
              >
                <TableIcon size={14} />
              </button>
            </div>
          )}

          {/* Premium 'Export Options' Dropdown Button */}
          <div className="relative" ref={dropdownRef}>
            <button
              type="button"
              onClick={() => setExportMenuOpen(!exportMenuOpen)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold text-xs bg-gradient-to-r from-teal-500/10 via-lime-500/10 to-emerald-500/10 hover:from-teal-500/20 hover:to-lime-500/20 text-slate-800 dark:text-lime-300 border border-teal-500/30 dark:border-lime-500/40 hover:border-lime-500/70 transition shadow-xs cursor-pointer"
              title="Grafik va ma'lumotlarni yuklab olish parametrlari"
            >
              {exportStatus === 'png_loading' ? (
                <div className="w-3.5 h-3.5 border-2 border-lime-400 border-t-transparent rounded-full animate-spin" />
              ) : exportStatus?.endsWith('_success') ? (
                <Check size={14} className="text-lime-400" />
              ) : (
                <Download size={14} className="text-teal-600 dark:text-lime-400" />
              )}
              <span>Export Options</span>
              <ChevronDown
                size={13}
                className={`transition-transform duration-200 text-slate-500 dark:text-slate-400 ${
                  exportMenuOpen ? 'rotate-180' : ''
                }`}
              />
            </button>

            {/* Dropdown Menu Modal/Popover */}
            {exportMenuOpen && (
              <div className="absolute right-0 top-full mt-1.5 z-40 w-64 rounded-2xl bg-white/95 dark:bg-[#0b172d]/95 backdrop-blur-xl border border-slate-200 dark:border-teal-500/30 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
                {/* Navy / Lime gradient accent header */}
                <div className="h-1 w-full bg-gradient-to-r from-teal-400 via-lime-400 to-emerald-400" />

                <div className="p-3 border-b border-slate-100 dark:border-slate-800/80">
                  <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center gap-1.5">
                    <Sparkles size={11} className="text-lime-400" />
                    <span>Eksport Imkoniyatlari</span>
                  </div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white mt-0.5 truncate">
                    {title}
                  </div>
                </div>

                <div className="p-1.5 space-y-1">
                  {/* Option 1: CSV Export */}
                  <button
                    type="button"
                    onClick={exportCSV}
                    className="w-full flex items-start gap-2.5 p-2 rounded-xl text-left hover:bg-slate-100 dark:hover:bg-slate-800/80 transition group cursor-pointer"
                  >
                    <div className="w-8 h-8 rounded-lg bg-teal-500/15 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      <FileSpreadsheet size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-slate-900 dark:text-white flex items-center justify-between">
                        <span>CSV formatida yuklash</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-teal-500/10 text-teal-600 dark:text-teal-300">.csv</span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        Excel, Google Sheets va jadval tahlillari uchun
                      </p>
                    </div>
                  </button>

                  {/* Option 2: PNG Visual Image Export */}
                  <button
                    type="button"
                    onClick={exportPNG}
                    className="w-full flex items-start gap-2.5 p-2 rounded-xl text-left hover:bg-slate-100 dark:hover:bg-slate-800/80 transition group cursor-pointer"
                  >
                    <div className="w-8 h-8 rounded-lg bg-lime-500/15 text-lime-600 dark:text-lime-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      <ImageIcon size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-slate-900 dark:text-white flex items-center justify-between">
                        <span>PNG rasm formatida yuklash</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-lime-500/10 text-lime-600 dark:text-lime-300">.png</span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        Prezentatsiya va hisobotlar uchun sifatli tasvir
                      </p>
                    </div>
                  </button>

                  {/* Option 3: View Table Toggle */}
                  <button
                    type="button"
                    onClick={() => {
                      setViewTable(!viewTable);
                      setExportMenuOpen(false);
                    }}
                    className="w-full flex items-start gap-2.5 p-2 rounded-xl text-left hover:bg-slate-100 dark:hover:bg-slate-800/80 transition group cursor-pointer border-t border-slate-100 dark:border-slate-800/60 mt-1 pt-2"
                  >
                    <div className="w-8 h-8 rounded-lg bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      <TableIcon size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-slate-900 dark:text-white">
                        {viewTable ? "Grafik rejimiga qaytish" : "Jadval ko'rinishida ochish"}
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        Barcha sonli qatorlarni matnli jadvalda ko'rish
                      </p>
                    </div>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Dynamic Data Points Toggle Row (when showToggle is enabled) */}
      {showToggle && data.length > 1 && (
        <div className="flex items-center gap-1.5 flex-wrap mb-3 p-2 rounded-xl bg-slate-50/80 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800/80 text-[11px]">
          <span className="text-slate-400 font-semibold text-[10px] uppercase tracking-wider mr-1">
            Nuqtalar ({displayData.length}/{data.length}):
          </span>
          {data.map((pt) => {
            const isExcluded = disabledPoints[pt.label];
            return (
              <button
                key={pt.label}
                type="button"
                onClick={() =>
                  setDisabledPoints((prev) => ({
                    ...prev,
                    [pt.label]: !prev[pt.label],
                  }))
                }
                className={`px-2 py-0.5 rounded-lg font-medium text-[10px] transition cursor-pointer ${
                  !isExcluded
                    ? 'bg-teal-500/15 text-teal-700 dark:text-lime-300 border border-teal-500/30'
                    : 'bg-slate-200/50 dark:bg-slate-800 text-slate-400 line-through opacity-60'
                }`}
                title={isExcluded ? "Nuqtani yoqish" : "Nuqtani o'chirish"}
              >
                {pt.label}
              </button>
            );
          })}
        </div>
      )}

      {/* Main Chart or Table View */}
      {viewTable ? (
        <div className="overflow-x-auto max-h-80 border border-slate-200 dark:border-slate-800 rounded-xl">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 uppercase font-semibold">
              <tr>
                <th className="py-2.5 px-4">Davr / Ko'rsatkich</th>
                <th className="py-2.5 px-4 text-right">Qiymat ({unit})</th>
                <th className="py-2.5 px-4">Izoh</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {displayData.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                  <td className="py-2 px-4 font-medium text-slate-900 dark:text-white">{row.label}</td>
                  <td className="py-2 px-4 text-right font-mono text-teal-600 dark:text-teal-400 font-semibold">
                    {typeof row.value === 'number' ? row.value.toLocaleString('uz-UZ') : row.value}
                  </td>
                  <td className="py-2 px-4 text-slate-500 dark:text-slate-400 italic">{row.note || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div style={{ height: `${height}px` }} className="w-full">
          <ResponsiveContainer width="100%" height="100%">
            {activeType === 'donut' ? (
              <PieChart>
                <Pie
                  data={displayData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                  nameKey="label"
                >
                  {displayData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            ) : activeType === 'bar' ? (
              <BarChart data={displayData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.15} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 11, fill: isDark ? '#94a3b8' : '#64748b' }}
                  tickLine={false}
                  axisLine={{ stroke: isDark ? '#334155' : '#cbd5e1' }}
                  dy={8}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: isDark ? '#94a3b8' : '#64748b' }}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar
                  dataKey="value"
                  fill={color}
                  radius={[4, 4, 0, 0]}
                  maxBarSize={45}
                />
              </BarChart>
            ) : activeType === 'area' ? (
              <AreaChart data={displayData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <defs>
                  <linearGradient id={`areaColor-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={color} stopOpacity={0.4} />
                    <stop offset="95%" stopColor={color} stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.15} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 11, fill: isDark ? '#94a3b8' : '#64748b' }}
                  tickLine={false}
                  axisLine={{ stroke: isDark ? '#334155' : '#cbd5e1' }}
                  dy={8}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: isDark ? '#94a3b8' : '#64748b' }}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke={color}
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill={`url(#areaColor-${color.replace('#', '')})`}
                />
              </AreaChart>
            ) : (
              <LineChart data={displayData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.15} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 11, fill: isDark ? '#94a3b8' : '#64748b' }}
                  tickLine={false}
                  axisLine={{ stroke: isDark ? '#334155' : '#cbd5e1' }}
                  dy={8}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: isDark ? '#94a3b8' : '#64748b' }}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke={color}
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: color }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            )}
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
};
