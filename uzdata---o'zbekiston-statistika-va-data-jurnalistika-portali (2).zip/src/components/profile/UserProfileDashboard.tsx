import React, { useState, useEffect } from 'react';
import {
  User,
  Bookmark,
  History,
  Settings,
  ArrowRight,
  Trash2,
  TrendingUp,
  BookOpen,
  CheckCircle2,
  Mail,
  MapPin,
  Bell,
  Sparkles,
  ShieldCheck,
  ExternalLink,
  Save,
  LogIn
} from 'lucide-react';
import { userService, RecentlyViewedItem, UserProfileSettings } from '../../services/userService';
import { Statistic, Article } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { REGIONS_DATA } from '../../data/seedData';

interface UserProfileDashboardProps {
  statistics: Statistic[];
  articles: Article[];
  onSelectStat: (stat: Statistic) => void;
  onSelectArticle: (article: Article) => void;
  onBackToHome?: () => void;
}

export const UserProfileDashboard: React.FC<UserProfileDashboardProps> = ({
  statistics,
  articles,
  onSelectStat,
  onSelectArticle,
  onBackToHome,
}) => {
  const { user, loginWithGoogle, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<'bookmarks' | 'history' | 'settings'>('bookmarks');

  // Bookmarks state
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  // History state
  const [recentItems, setRecentItems] = useState<RecentlyViewedItem[]>([]);
  // Profile settings state
  const [settings, setSettings] = useState<UserProfileSettings>(userService.getProfileSettings());
  const [saveSuccess, setSaveSuccess] = useState(false);

  const loadUserData = () => {
    setBookmarkedIds(userService.getBookmarkedIds());
    setRecentItems(userService.getRecentlyViewed());
    setSettings(userService.getProfileSettings());
  };

  useEffect(() => {
    loadUserData();
    const handleBookmarkUpdate = () => setBookmarkedIds(userService.getBookmarkedIds());
    const handleRecentUpdate = () => setRecentItems(userService.getRecentlyViewed());

    window.addEventListener('uzdata_bookmarks_updated', handleBookmarkUpdate);
    window.addEventListener('uzdata_recent_views_updated', handleRecentUpdate);
    return () => {
      window.removeEventListener('uzdata_bookmarks_updated', handleBookmarkUpdate);
      window.removeEventListener('uzdata_recent_views_updated', handleRecentUpdate);
    };
  }, []);

  const handleRemoveBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    userService.toggleBookmark(id);
    setBookmarkedIds(userService.getBookmarkedIds());
  };

  const handleClearHistory = () => {
    userService.clearRecentViews();
    setRecentItems([]);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    userService.saveProfileSettings(settings);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  // Find saved statistics and articles
  const savedStats = statistics.filter((s) => bookmarkedIds.includes(s.id));
  const savedArticles = articles.filter((a) => bookmarkedIds.includes(a.id));

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 animate-in fade-in duration-300">
      {/* Profile Header Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden mb-8 border border-teal-500/30">
        <div className="absolute top-0 right-0 w-96 h-96 bg-lime-400/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-teal-500 to-lime-400 p-1 shadow-lg shrink-0">
              <div className="w-full h-full rounded-xl bg-slate-950 flex items-center justify-center font-bold text-2xl text-lime-400">
                {user?.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'Profil'}
                    className="w-full h-full object-cover rounded-xl"
                  />
                ) : (
                  (user?.displayName || settings.displayName).charAt(0)
                )}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight">
                  {user?.displayName || settings.displayName}
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-lime-400/20 text-lime-300 border border-lime-400/40">
                  {user ? 'Faol Foydalanuvchi' : 'Mehmon Tahlilchi'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 flex items-center gap-2">
                <span>{user?.email || 'foydalanuvchi@uzdata.uz'}</span>
                <span>•</span>
                <span className="text-teal-400">{settings.profession}</span>
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                Hudud: <span className="text-white font-medium">{settings.preferredRegion}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {!user ? (
              <button
                onClick={loginWithGoogle}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-teal-500 to-lime-400 text-slate-950 font-bold text-xs shadow-md hover:opacity-95 transition cursor-pointer"
              >
                <LogIn size={15} />
                <span>Google bilan kirish</span>
              </button>
            ) : (
              <button
                onClick={logout}
                className="px-4 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-700 transition cursor-pointer"
              >
                Chiqish
              </button>
            )}

            {onBackToHome && (
              <button
                onClick={onBackToHome}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition cursor-pointer"
              >
                Bosh sahifaga
              </button>
            )}
          </div>
        </div>

        {/* Quick Stats Bar in Header */}
        <div className="grid grid-cols-3 gap-3 mt-6 pt-6 border-t border-slate-800/80 text-xs">
          <div>
            <span className="text-[10px] font-bold uppercase text-slate-400">Saqlangan Materiallar</span>
            <p className="text-lg font-mono font-bold text-lime-400 mt-0.5">
              {bookmarkedIds.length} ta
            </p>
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase text-slate-400">Yaqinda Ko'rilgan</span>
            <p className="text-lg font-mono font-bold text-teal-400 mt-0.5">
              {recentItems.length} ta
            </p>
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase text-slate-400">Xavfsizlik & Kirish</span>
            <p className="text-lg font-mono font-bold text-white mt-0.5 flex items-center gap-1">
              <ShieldCheck size={16} className="text-emerald-400" />
              <span>Himoyalangan</span>
            </p>
          </div>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-2 pb-4 mb-6 border-b border-slate-200 dark:border-slate-800 overflow-x-auto">
        <button
          onClick={() => setActiveTab('bookmarks')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition cursor-pointer ${
            activeTab === 'bookmarks'
              ? 'bg-teal-600 dark:bg-lime-400 text-white dark:text-slate-950 shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:border-teal-500'
          }`}
        >
          <Bookmark size={16} />
          <span>Saqlanganlar ({bookmarkedIds.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition cursor-pointer ${
            activeTab === 'history'
              ? 'bg-teal-600 dark:bg-lime-400 text-white dark:text-slate-950 shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:border-teal-500'
          }`}
        >
          <History size={16} />
          <span>Yaqinda Ko'rilganlar ({recentItems.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition cursor-pointer ${
            activeTab === 'settings'
              ? 'bg-teal-600 dark:bg-lime-400 text-white dark:text-slate-950 shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:border-teal-500'
          }`}
        >
          <Settings size={16} />
          <span>Profil Sozlamalari</span>
        </button>
      </div>

      {/* Tab 1: Bookmarks / Saqlanganlar */}
      {activeTab === 'bookmarks' && (
        <div className="space-y-6 animate-in fade-in">
          {savedStats.length === 0 && savedArticles.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-white dark:bg-slate-900/80 border border-dashed border-slate-200 dark:border-slate-800">
              <Bookmark size={36} className="mx-auto text-slate-300 dark:text-slate-600 mb-3" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
                Saqlangan materiallar topilmadi
              </h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
                Statistika va tahliliy maqolalarni yulduzcha yoki saqlash tugmasini bosib shu yerda to'plashingiz mumkin.
              </p>
            </div>
          ) : (
            <div>
              {/* Saved Statistics */}
              {savedStats.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                    <TrendingUp size={15} className="text-teal-500" />
                    <span>Saqlangan Statistik Ko'rsatkichlar ({savedStats.length})</span>
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {savedStats.map((stat) => (
                      <div
                        key={stat.id}
                        onClick={() => onSelectStat(stat)}
                        className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500 transition shadow-xs cursor-pointer flex flex-col justify-between group"
                      >
                        <div>
                          <div className="flex items-center justify-between mb-2 text-xs">
                            <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-lime-300">
                              {stat.category}
                            </span>
                            <button
                              onClick={(e) => handleRemoveBookmark(stat.id, e)}
                              className="p-1 rounded-md text-slate-400 hover:text-rose-500 transition"
                              title="Saqlanganlardan o'chirish"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                          <h4 className="font-bold text-slate-900 dark:text-white text-sm line-clamp-1 group-hover:text-teal-600 transition">
                            {stat.title}
                          </h4>
                          <p className="text-2xl font-black font-mono text-teal-600 dark:text-lime-400 mt-2">
                            {stat.value}
                          </p>
                        </div>
                        <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 mt-3">
                          <span>{stat.unit}</span>
                          <span className="text-teal-600 dark:text-teal-400 font-semibold flex items-center gap-1">
                            Batafsil <ArrowRight size={12} />
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Saved Articles */}
              {savedArticles.length > 0 && (
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                    <BookOpen size={15} className="text-sky-500" />
                    <span>Saqlangan Tahliliy Maqolalar ({savedArticles.length})</span>
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {savedArticles.map((art) => (
                      <div
                        key={art.id}
                        onClick={() => onSelectArticle(art)}
                        className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500 transition shadow-xs cursor-pointer flex flex-col justify-between group"
                      >
                        <div>
                          <div className="flex items-center justify-between mb-2 text-xs">
                            <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300">
                              {art.category}
                            </span>
                            <button
                              onClick={(e) => handleRemoveBookmark(art.id, e)}
                              className="p-1 rounded-md text-slate-400 hover:text-rose-500 transition"
                              title="O'chirish"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                          <h4 className="font-bold text-slate-900 dark:text-white text-sm line-clamp-1 group-hover:text-teal-600 transition">
                            {art.title}
                          </h4>
                          <p className="text-xs text-slate-500 line-clamp-2 mt-1.5">
                            {art.excerpt}
                          </p>
                        </div>
                        <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 mt-3">
                          <span>{art.readingTime}</span>
                          <span className="text-teal-600 font-semibold flex items-center gap-1">
                            O'qish <ArrowRight size={12} />
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Recently Viewed / Yaqinda ko'rilganlar */}
      {activeTab === 'history' && (
        <div className="animate-in fade-in">
          <div className="flex items-center justify-between mb-4">
            <p className="text-xs text-slate-400">
              Siz ko'rib chiqqan so'nggi ma'lumotlar va sahifalar xronologiyasi.
            </p>
            {recentItems.length > 0 && (
              <button
                onClick={handleClearHistory}
                className="inline-flex items-center gap-1.5 text-xs text-rose-500 hover:text-rose-600 font-semibold cursor-pointer"
              >
                <Trash2 size={13} />
                <span>Tarixni tozalash</span>
              </button>
            )}
          </div>

          {recentItems.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-white dark:bg-slate-900/80 border border-dashed border-slate-200 dark:border-slate-800">
              <History size={36} className="mx-auto text-slate-300 dark:text-slate-600 mb-3" />
              <p className="text-xs text-slate-400">Hozircha ko'rilgan sahifalar tarixi mavjud emas.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {recentItems.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    if (item.type === 'stat') {
                      const found = statistics.find((s) => s.id === item.id || s.slug === item.slug);
                      if (found) onSelectStat(found);
                    } else {
                      const found = articles.find((a) => a.id === item.id || a.slug === item.slug);
                      if (found) onSelectArticle(found);
                    }
                  }}
                  className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500 transition shadow-xs cursor-pointer flex items-center justify-between gap-4 group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-600 dark:text-lime-400 flex items-center justify-center font-bold shrink-0">
                      {item.type === 'stat' ? <TrendingUp size={16} /> : <BookOpen size={16} />}
                    </div>
                    <div>
                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white group-hover:text-teal-600 transition">
                        {item.title}
                      </h4>
                      <p className="text-[10px] text-slate-400 capitalize">
                        {item.category} {item.value ? `• ${item.value}` : ''}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[10px] font-mono text-slate-400">
                      {new Date(item.viewedAt).toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Profile Settings / Sozlamalar */}
      {activeTab === 'settings' && (
        <div className="max-w-2xl bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-xl animate-in fade-in">
          {saveSuccess && (
            <div className="mb-6 p-3.5 rounded-xl bg-lime-500/15 border border-lime-500/30 text-lime-800 dark:text-lime-300 text-xs flex items-center gap-2">
              <CheckCircle2 size={16} className="text-lime-500 shrink-0" />
              <span>Profil sozlamalari muvaffaqiyatli saqlandi!</span>
            </div>
          )}

          <form onSubmit={handleSaveSettings} className="space-y-5 text-xs sm:text-sm">
            {/* Display Name */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                Ism va Familiya
              </label>
              <input
                type="text"
                value={settings.displayName}
                onChange={(e) => setSettings({ ...settings, displayName: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs focus:outline-hidden focus:border-teal-500"
              />
            </div>

            {/* Profession */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                Faoliyat sohasi / Mutaxassislik
              </label>
              <input
                type="text"
                value={settings.profession}
                onChange={(e) => setSettings({ ...settings, profession: e.target.value })}
                placeholder="Masalan: Iqtisodchi, Dasturchi, Talaba, Jurnalist"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs focus:outline-hidden focus:border-teal-500"
              />
            </div>

            {/* Preferred Region */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                Asosiy qiziqish hududi
              </label>
              <select
                value={settings.preferredRegion}
                onChange={(e) => setSettings({ ...settings, preferredRegion: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs focus:outline-hidden focus:border-teal-500"
              >
                <option value="O'zbekiston">Butun O'zbekiston (Respublika)</option>
                {REGIONS_DATA.map((r) => (
                  <option key={r.id} value={r.name}>
                    {r.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Notifications Toggles */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <span className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                Bildirishnomalar & Xabarlar
              </span>

              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/60 dark:border-slate-800 cursor-pointer">
                <div>
                  <p className="font-semibold text-xs text-slate-900 dark:text-white">
                    Muhim statistik yangiliklar
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Yangi davlat hisobotlari va asosiy ko'rsatkichlar chop etilganda
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.emailAlerts}
                  onChange={(e) => setSettings({ ...settings, emailAlerts: e.target.checked })}
                  className="w-4 h-4 text-teal-600 rounded cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/60 dark:border-slate-800 cursor-pointer">
                <div>
                  <p className="font-semibold text-xs text-slate-900 dark:text-white">
                    Haftalik Tahliliy Dayjest
                  </p>
                  <p className="text-[11px] text-slate-400">
                    O'zbekiston iqtisodiyoti bo'yicha haftalik xulosa
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.weeklyDigest}
                  onChange={(e) => setSettings({ ...settings, weeklyDigest: e.target.checked })}
                  className="w-4 h-4 text-teal-600 rounded cursor-pointer"
                />
              </label>
            </div>

            <div className="pt-4">
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-lime-400 text-slate-950 font-bold text-xs shadow-md hover:opacity-95 transition cursor-pointer"
              >
                <Save size={15} />
                <span>O'zgarishlarni saqlash</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
