import React, { useState } from 'react';
import { Shield, Lock, AlertCircle, ArrowLeft, CheckCircle2, KeyRound } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface AdminLoginProps {
  onBackToPublic: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onBackToPublic }) => {
  const { loginWithGoogle, loading, authError, clearAuthError, targetAdminEmail } = useAuth();
  const [submitting, setSubmitting] = useState(false);

  const handleLogin = async () => {
    setSubmitting(true);
    await loginWithGoogle();
    setSubmitting(false);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
        {/* Accent Bar */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-teal-500 via-cyan-500 to-indigo-500" />

        <button
          onClick={onBackToPublic}
          className="inline-flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white mb-6 font-semibold transition"
        >
          <ArrowLeft size={14} />
          <span>Ommaviy sahifaga qaytish</span>
        </button>

        <div className="text-center mb-8">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-950 text-teal-400 flex items-center justify-center font-bold mb-4 shadow-lg">
            <Shield size={28} />
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            UZDATA Tahririyat Portali
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
            Statistika va data-jurnalistika ma'lumotlarini boshqarish bo'yicha yopiq xizmat tizimi.
          </p>
        </div>

        {/* Security Notice */}
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 mb-6 text-xs text-amber-900 dark:text-amber-200">
          <div className="flex items-start gap-2.5">
            <Lock size={16} className="text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold mb-0.5">Xavfsizlik talabi:</p>
              <p className="leading-relaxed text-[11px] opacity-90">
                Tizimda ochiq ro'yxatdan o'tish mavjud emas. Faqat oldindan tasdiqlangan tahririyat pochtasi (<strong>{targetAdminEmail}</strong>) orqali kirish mumkin.
              </p>
            </div>
          </div>
        </div>

        {/* Error notification */}
        {authError && (
          <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/60 mb-6 text-xs text-rose-800 dark:text-rose-200">
            <div className="flex items-start gap-2">
              <AlertCircle size={16} className="text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-bold">Kirish rad etildi</p>
                <p className="text-[11px] mt-0.5">{authError}</p>
                <button
                  onClick={clearAuthError}
                  className="mt-2 text-[10px] font-semibold underline text-rose-700 dark:text-rose-300"
                >
                  Qayta urinish
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Action Button: Google Sign In */}
        <button
          onClick={handleLogin}
          disabled={loading || submitting}
          className="w-full py-3.5 px-4 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-sm hover:bg-slate-800 dark:hover:bg-slate-100 transition shadow-md flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50"
        >
          {loading || submitting ? (
            <div className="w-5 h-5 border-2 border-slate-300 border-t-white dark:border-slate-600 dark:border-t-slate-900 rounded-full animate-spin" />
          ) : (
            <>
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Google Hisob orqali Kirish</span>
            </>
          )}
        </button>

        <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 text-center text-[11px] text-slate-400">
          <p>UZDATA CMS v2.4 Enterprise</p>
          <p className="mt-0.5">Firestore Zero-Trust RBAC protokoli asosida himoyalangan</p>
        </div>
      </div>
    </div>
  );
};
