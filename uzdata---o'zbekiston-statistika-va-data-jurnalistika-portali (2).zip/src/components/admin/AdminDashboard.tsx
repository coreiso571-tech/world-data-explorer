import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  BookOpen, 
  Plus, 
  Trash2, 
  Edit3, 
  CheckCircle, 
  Clock, 
  EyeOff, 
  Database, 
  LogOut, 
  Search, 
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  User,
  Check
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Statistic, Article, ContentStatus } from '../../types';
import { dataService } from '../../services/dataService';
import { StatisticFormModal } from './StatisticFormModal';
import { ArticleFormModal } from './ArticleFormModal';
import { DeleteConfirmModal } from './DeleteConfirmModal';
import { AdminProfileCard } from './AdminProfileCard';

export const AdminDashboard: React.FC = () => {
  const { adminUser, logout } = useAuth();

  const [activeTab, setActiveTab] = useState<'stats' | 'articles' | 'system'>('stats');
  const [statistics, setStatistics] = useState<Statistic[]>([]);
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | ContentStatus>('all');

  // Modals state
  const [statModalOpen, setStatModalOpen] = useState(false);
  const [selectedStat, setSelectedStat] = useState<Statistic | null>(null);

  const [articleModalOpen, setArticleModalOpen] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<{ type: 'stat' | 'article'; id: string; title: string } | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Seeder state
  const [seeding, setSeeding] = useState(false);
  const [seedSuccess, setSeedSuccess] = useState<string | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const [fetchedStats, fetchedArticles] = await Promise.all([
        dataService.getAllStatisticsForAdmin(),
        dataService.getAllArticlesForAdmin(),
      ]);
      setStatistics(fetchedStats);
      setArticles(fetchedArticles);
    } catch (err) {
      console.error('Error loading admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Status metrics calculation
  const totalItems = statistics.length + articles.length;
  const publishedCount = 
    statistics.filter((s) => s.status === 'Published').length +
    articles.filter((a) => a.status === 'Published').length;
  const draftCount = 
    statistics.filter((s) => s.status === 'Draft').length +
    articles.filter((a) => a.status === 'Draft').length;
  const unpublishedCount = 
    statistics.filter((s) => s.status === 'Unpublished').length +
    articles.filter((a) => a.status === 'Unpublished').length;

  // Filtered statistics
  const filteredStats = statistics.filter((s) => {
    const matchesSearch = s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || s.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Filtered articles
  const filteredArticles = articles.filter((a) => {
    const matchesSearch = a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || a.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // CRUD actions for Statistics
  const handleSaveStat = async (stat: Statistic) => {
    await dataService.saveStatistic(stat);
    await loadData();
  };

  const handleToggleStatStatus = async (stat: Statistic, newStatus: ContentStatus) => {
    const updated = { ...stat, status: newStatus };
    await dataService.saveStatistic(updated);
    await loadData();
  };

  // CRUD actions for Articles
  const handleSaveArticle = async (art: Article) => {
    await dataService.saveArticle(art);
    await loadData();
  };

  const handleToggleArticleStatus = async (art: Article, newStatus: ContentStatus) => {
    const updated = { ...art, status: newStatus };
    await dataService.saveArticle(updated);
    await loadData();
  };

  // Delete execution
  const executeDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      if (deleteTarget.type === 'stat') {
        await dataService.deleteStatistic(deleteTarget.id);
      } else {
        await dataService.deleteArticle(deleteTarget.id);
      }
      setDeleteModalOpen(false);
      setDeleteTarget(null);
      await loadData();
    } catch (err) {
      console.error(err);
    } finally {
      setDeleting(false);
    }
  };

  // Seeder
  const handleRunSeeder = async () => {
    setSeeding(true);
    setSeedSuccess(null);
    try {
      const res = await dataService.seedInitialData();
      setSeedSuccess(`Muvaffaqiyatli yuklandi: ${res.statsCount} ta statistika, ${res.articlesCount} ta maqola, ${res.categoriesCount} ta soha Firestore bazasiga yozildi.`);
      await loadData();
    } catch (err: unknown) {
      setSeedSuccess(`Yuklashda xatolik: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setSeeding(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Bar with Admin Profile */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800 mb-8">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-teal-500 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-teal-600 dark:text-teal-400 font-semibold">
              UZDATA Editorial Console
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Tahririyat Boshqaruv Paneli (CMS)
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-300">
            <div className="w-6 h-6 rounded-full bg-teal-600 text-white flex items-center justify-center font-bold text-[10px]">
              {adminUser?.displayName?.[0] || 'A'}
            </div>
            <div className="text-left">
              <p className="font-bold leading-none">{adminUser?.displayName || 'Administrator'}</p>
              <p className="text-[10px] text-slate-400 font-mono leading-none mt-0.5">{adminUser?.email}</p>
            </div>
          </div>

          <button
            onClick={logout}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
          >
            <LogOut size={14} />
            <span className="hidden sm:inline">Chiqish</span>
          </button>
        </div>
      </div>

      {/* Premium Admin Profile Card */}
      <AdminProfileCard />

      {/* KPI Overview Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Jami Kontent</p>
          <p className="text-3xl font-black font-mono text-slate-900 dark:text-white mt-1">{totalItems}</p>
          <p className="text-[11px] text-slate-500 mt-1">{statistics.length} statistika • {articles.length} maqola</p>
        </div>

        <div className="p-5 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-900/40 shadow-xs">
          <div className="flex items-center justify-between text-xs text-emerald-700 dark:text-emerald-400 font-semibold uppercase tracking-wider">
            <span>Chop Etilgan</span>
            <CheckCircle size={15} />
          </div>
          <p className="text-3xl font-black font-mono text-emerald-700 dark:text-emerald-400 mt-1">{publishedCount}</p>
          <p className="text-[11px] text-emerald-600/80 mt-1">Ommaviy sahifada jonli</p>
        </div>

        <div className="p-5 rounded-2xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40 shadow-xs">
          <div className="flex items-center justify-between text-xs text-amber-700 dark:text-amber-400 font-semibold uppercase tracking-wider">
            <span>Qoralama (Draft)</span>
            <Clock size={15} />
          </div>
          <p className="text-3xl font-black font-mono text-amber-700 dark:text-amber-400 mt-1">{draftCount}</p>
          <p className="text-[11px] text-amber-600/80 mt-1">Tahririyatda tekshiruvda</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider">
            <span>Yashiringan</span>
            <EyeOff size={15} />
          </div>
          <p className="text-3xl font-black font-mono text-slate-700 dark:text-slate-300 mt-1">{unpublishedCount}</p>
          <p className="text-[11px] text-slate-400 mt-1">Omma uchun yopiq</p>
        </div>
      </div>

      {/* Tabs and Action Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        {/* Navigation Tabs */}
        <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-semibold self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('stats')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition ${
              activeTab === 'stats'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <BarChart3 size={15} />
            <span>Statistikalar ({statistics.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('articles')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition ${
              activeTab === 'articles'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <BookOpen size={15} />
            <span>Maqolalar ({articles.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('system')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition ${
              activeTab === 'system'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Database size={15} />
            <span>Baza / Seeder</span>
          </button>
        </div>

        {/* Primary Action Button */}
        {activeTab === 'stats' && (
          <button
            onClick={() => {
              setSelectedStat(null);
              setStatModalOpen(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow-md transition"
          >
            <Plus size={16} />
            <span>Yangi Statistika Qo'shish</span>
          </button>
        )}

        {activeTab === 'articles' && (
          <button
            onClick={() => {
              setSelectedArticle(null);
              setArticleModalOpen(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow-md transition"
          >
            <Plus size={16} />
            <span>Yangi Maqola Yozish</span>
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      {activeTab !== 'system' && (
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 mb-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="relative w-full sm:w-80">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Nomi yoki sohasi bo'yicha qidirish..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <span className="text-slate-400">Holat:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-300 font-medium focus:outline-hidden"
            >
              <option value="all">Barcha holatlar</option>
              <option value="Published">Chop etilgan (Published)</option>
              <option value="Draft">Qoralama (Draft)</option>
              <option value="Unpublished">Yashiringan (Unpublished)</option>
            </select>

            <button
              onClick={loadData}
              className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="Yangilash"
            >
              <RefreshCw size={15} className={loading ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>
      )}

      {/* TAB CONTENT 1: STATISTICS TABLE */}
      {activeTab === 'stats' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/70 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 font-bold uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Ko'rsatkich Nomi</th>
                  <th className="py-3 px-4">Soha</th>
                  <th className="py-3 px-4">Qiymat</th>
                  <th className="py-3 px-4">Grafik</th>
                  <th className="py-3 px-4">Manba</th>
                  <th className="py-3 px-4">Holat (Status)</th>
                  <th className="py-3 px-4 text-right">Amallar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredStats.map((stat) => (
                  <tr key={stat.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-white max-w-xs">
                      <div className="truncate">{stat.title}</div>
                      <div className="text-[10px] text-slate-400 font-mono truncate">{stat.slug}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 capitalize text-[11px] font-medium">
                        {stat.category}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white">
                      {stat.value}
                    </td>
                    <td className="py-3.5 px-4 uppercase text-[10px] font-mono font-semibold text-slate-500">
                      {stat.chartType} ({stat.dataSeries?.length || 0} nuqta)
                    </td>
                    <td className="py-3.5 px-4 max-w-xs truncate text-slate-500 dark:text-slate-400">
                      {stat.sourceName}
                    </td>
                    <td className="py-3.5 px-4">
                      <select
                        value={stat.status}
                        onChange={(e) => handleToggleStatStatus(stat, e.target.value as ContentStatus)}
                        className={`text-[11px] font-bold px-2 py-1 rounded-lg border transition ${
                          stat.status === 'Published'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                            : stat.status === 'Draft'
                            ? 'bg-amber-50 text-amber-700 border-amber-300 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800'
                            : 'bg-slate-100 text-slate-600 border-slate-300 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
                        }`}
                      >
                        <option value="Published">Chop etilgan</option>
                        <option value="Draft">Qoralama</option>
                        <option value="Unpublished">Yashiringan</option>
                      </select>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => {
                            setSelectedStat(stat);
                            setStatModalOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                          title="Tahrirlash"
                        >
                          <Edit3 size={15} />
                        </button>
                        <button
                          onClick={() => {
                            setDeleteTarget({ type: 'stat', id: stat.id, title: stat.title });
                            setDeleteModalOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                          title="O'chirish"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredStats.length === 0 && (
            <div className="py-12 text-center text-slate-400 text-xs">
              Ushbu filtr bo'yicha statistika topilmadi
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT 2: ARTICLES TABLE */}
      {activeTab === 'articles' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/70 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 font-bold uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Maqola Sarlavhasi</th>
                  <th className="py-3 px-4">Soha</th>
                  <th className="py-3 px-4">Muallif</th>
                  <th className="py-3 px-4">O'qish vaqti</th>
                  <th className="py-3 px-4">Holat (Status)</th>
                  <th className="py-3 px-4 text-right">Amallar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredArticles.map((art) => (
                  <tr key={art.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-white max-w-sm">
                      <div className="truncate">{art.title}</div>
                      <div className="text-[10px] text-slate-400 font-mono truncate">{art.slug}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 capitalize text-[11px] font-medium">
                        {art.category}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                      {art.author}
                    </td>
                    <td className="py-3.5 px-4 text-slate-500 font-mono">
                      {art.readingTime}
                    </td>
                    <td className="py-3.5 px-4">
                      <select
                        value={art.status}
                        onChange={(e) => handleToggleArticleStatus(art, e.target.value as ContentStatus)}
                        className={`text-[11px] font-bold px-2 py-1 rounded-lg border transition ${
                          art.status === 'Published'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                            : art.status === 'Draft'
                            ? 'bg-amber-50 text-amber-700 border-amber-300 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800'
                            : 'bg-slate-100 text-slate-600 border-slate-300 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
                        }`}
                      >
                        <option value="Published">Chop etilgan</option>
                        <option value="Draft">Qoralama</option>
                        <option value="Unpublished">Yashiringan</option>
                      </select>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => {
                            setSelectedArticle(art);
                            setArticleModalOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                          title="Tahrirlash"
                        >
                          <Edit3 size={15} />
                        </button>
                        <button
                          onClick={() => {
                            setDeleteTarget({ type: 'article', id: art.id, title: art.title });
                            setDeleteModalOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                          title="O'chirish"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredArticles.length === 0 && (
            <div className="py-12 text-center text-slate-400 text-xs">
              Ushbu filtr bo'yicha maqolalar topilmadi
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT 3: SYSTEM SEEDER & CLOUD DIAGNOSTICS */}
      {activeTab === 'system' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs">
            <div className="flex items-start gap-4 mb-6">
              <div className="w-12 h-12 rounded-2xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0">
                <Database size={24} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                  Boshlang'ich Rasmiy Ma'lumotlarni Firestorega Yuklash (Seeder)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
                  Agar Firestore ma'lumotlar bazangiz yangi yoki bo'sh bo'lsa, ushbu tugma orqali O'zbekistonning barcha rasmiy statistikalarini (Aholi soni, YaIM, Inflyatsiya, IT Eksport, Turizm, Ta'lim va 14 ta hudud ma'lumotlari) bir zumda Firestore to'plamlariga yozib olishingiz mumkin.
                </p>
              </div>
            </div>

            {seedSuccess && (
              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900/60 mb-6 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
                <Check size={16} className="text-emerald-600 shrink-0" />
                <span>{seedSuccess}</span>
              </div>
            )}

            <button
              onClick={handleRunSeeder}
              disabled={seeding}
              className="py-3 px-6 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow-md transition flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {seeding ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Firestorega yozilmoqda...</span>
                </>
              ) : (
                <>
                  <Database size={15} />
                  <span>Boshlang'ich Ma'lumotlarni Sinxronlash</span>
                </>
              )}
            </button>
          </div>

          <div className="bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 text-xs text-slate-500 dark:text-slate-400 space-y-3">
            <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldCheck size={16} className="text-teal-600" />
              <span>Xavfsizlik & Arxitektura Ma'lumotlari</span>
            </h4>
            <ul className="space-y-1.5 list-disc list-inside">
              <li>Firestore xavfsizlik qoidalari: faqat <code className="font-mono text-teal-600">status == 'Published'</code> yozuvlari ommaviy o'qiladi.</li>
              <li>O'zgartirish va o'chirish faqat tizim ma'muri (<code className="font-mono text-teal-600">coreiso571@gmail.com</code>) uchun ochiq.</li>
              <li>Har bir yozuvda rasmiy manba URL manzili va tekshiruv sanasi majburiy saqlanadi.</li>
            </ul>
          </div>
        </div>
      )}

      {/* MODALS */}
      <StatisticFormModal
        isOpen={statModalOpen}
        stat={selectedStat}
        onClose={() => {
          setStatModalOpen(false);
          setSelectedStat(null);
        }}
        onSave={handleSaveStat}
      />

      <ArticleFormModal
        isOpen={articleModalOpen}
        article={selectedArticle}
        onClose={() => {
          setArticleModalOpen(false);
          setSelectedArticle(null);
        }}
        onSave={handleSaveArticle}
      />

      <DeleteConfirmModal
        isOpen={deleteModalOpen}
        title={deleteTarget?.type === 'stat' ? "Statistikani o'chirish" : "Maqolani o'chirish"}
        itemTitle={deleteTarget?.title || ''}
        loading={deleting}
        onConfirm={executeDelete}
        onCancel={() => {
          setDeleteModalOpen(false);
          setDeleteTarget(null);
        }}
      />
    </div>
  );
};
