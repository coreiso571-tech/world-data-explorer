import React from 'react';
import { 
  User, 
  Mail, 
  GraduationCap, 
  ShieldCheck, 
  CheckCircle2, 
  Key, 
  Award,
  Sparkles,
  Lock,
  Globe2
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const AdminProfileCard: React.FC = () => {
  const { adminUser } = useAuth();

  return (
    <div className="relative overflow-hidden rounded-3xl bg-slate-900 border border-slate-800 text-white p-6 sm:p-7 shadow-xl mb-8 group hover:border-lime-500/40 transition-all duration-300">
      {/* Decorative background glow accents in navy/lime/teal */}
      <div className="absolute -right-16 -top-16 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -left-12 -bottom-12 w-48 h-48 bg-lime-400/10 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-teal-500 via-lime-400 to-emerald-500" />

      <div className="relative z-10">
        {/* Top bar with system badges */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-5 mb-5 border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-lime-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-lime-400"></span>
            </span>
            <span className="text-[11px] font-mono tracking-wider font-bold uppercase text-lime-400">
              Admin Profile &amp; Tizim Boshqaruvchisi
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-teal-950/80 text-teal-300 border border-teal-800/60 flex items-center gap-1">
              <ShieldCheck size={11} className="text-teal-400" />
              Verified Super Admin
            </span>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800/90 text-slate-300 border border-slate-700/50">
              <Lock size={12} className="text-lime-400" />
              Xavfsiz Seans (TLS 1.3)
            </span>
          </div>
        </div>

        {/* Main profile row: Avatar + Identity + Information Grid */}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          {/* Avatar and Primary Identity */}
          <div className="flex items-center gap-4 sm:gap-5">
            <div className="relative shrink-0">
              {/* Outer glowing ring */}
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-teal-400 via-emerald-500 to-lime-400 p-0.5 shadow-lg shadow-teal-900/30">
                <div className="w-full h-full rounded-2xl bg-slate-900 flex items-center justify-center overflow-hidden">
                  <div className="w-full h-full bg-gradient-to-tr from-slate-900 via-slate-800 to-teal-950/60 flex items-center justify-center text-lime-400">
                    <User size={36} className="text-lime-400 drop-shadow-md" />
                  </div>
                </div>
              </div>
              {/* Active status pip */}
              <div 
                className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-lime-400 border-2 border-slate-900 flex items-center justify-center"
                title="Sessiya faol"
              >
                <CheckCircle2 size={12} className="text-slate-950 font-bold" />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                  <span>Name: [Ismingiz Familiyangiz]</span>
                  <Award size={18} className="text-lime-400 shrink-0" />
                </h2>
              </div>
              <p className="text-xs text-slate-300 flex items-center gap-1.5 font-medium">
                <Sparkles size={13} className="text-teal-400" />
                <span>Boshqaruv Tizimi Ma'muri &amp; Bosh Muharrir</span>
              </p>
              <div className="pt-1 flex flex-wrap gap-2 text-[11px]">
                <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700/60 font-mono">
                  ID: #UZDATA-ADM-01
                </span>
                <span className="px-2 py-0.5 rounded-md bg-lime-950/60 text-lime-300 border border-lime-800/50 font-semibold flex items-center gap-1">
                  <Key size={10} />
                  To'liq CRUD &amp; Firestore Boshqaruvi
                </span>
              </div>
            </div>
          </div>

          {/* Quick Metrics / Status Tag */}
          <div className="flex lg:flex-col items-center lg:items-end justify-between w-full lg:w-auto gap-2 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-800">
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">
              Autentifikatsiya Holati
            </span>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-950/60 border border-teal-500/30 text-teal-300 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-lime-400 animate-pulse" />
              <span>Faol Administrator Seansi</span>
            </div>
          </div>
        </div>

        {/* Structured Profile Cards with the exact mandatory values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-6 pt-5 border-t border-slate-800/80">
          {/* Card 1: Name */}
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 hover:border-lime-500/40 transition">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 mb-1.5">
              <div className="w-6 h-6 rounded-lg bg-teal-500/10 text-teal-400 flex items-center justify-center">
                <User size={13} />
              </div>
              <span className="uppercase tracking-wider font-mono text-[10px]">To'liq Ism (Full Name)</span>
            </div>
            <div className="text-sm font-bold text-white tracking-wide font-mono">
              Name: [Ismingiz Familiyangiz]
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Bosh tizim ma'muri va loyiha rahbari
            </div>
          </div>

          {/* Card 2: Email */}
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 hover:border-lime-500/40 transition">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 mb-1.5">
              <div className="w-6 h-6 rounded-lg bg-lime-500/10 text-lime-400 flex items-center justify-center">
                <Mail size={13} />
              </div>
              <span className="uppercase tracking-wider font-mono text-[10px]">Aloqa &amp; Kirish Emaili</span>
            </div>
            <div className="text-sm font-bold text-lime-300 tracking-wide font-mono break-all">
              Email: [Gmail manzilingiz]
            </div>
            <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5">
              <Globe2 size={11} className="text-slate-500" />
              <span>Tizimga ulangan: {adminUser?.email || 'coreiso571@gmail.com'}</span>
            </div>
          </div>

          {/* Card 3: Education */}
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 hover:border-lime-500/40 transition">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 mb-1.5">
              <div className="w-6 h-6 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <GraduationCap size={13} />
              </div>
              <span className="uppercase tracking-wider font-mono text-[10px]">Ta'lim Muassasasi</span>
            </div>
            <div className="text-sm font-bold text-emerald-300 tracking-tight">
              Education: School of Engineering named after Mirzo Ulugbek.
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Muhandislik va axborot tizimlari yo'nalishi
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
