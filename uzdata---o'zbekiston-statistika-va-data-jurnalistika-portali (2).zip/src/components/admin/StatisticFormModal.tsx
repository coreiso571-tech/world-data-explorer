import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, Save, BarChart2, AlertCircle, Sparkles } from 'lucide-react';
import { Statistic, ChartType, ContentStatus, DataPoint } from '../../types';
import { INITIAL_CATEGORIES } from '../../data/seedData';
import { DataChart } from '../common/DataChart';

interface StatisticFormModalProps {
  isOpen: boolean;
  stat: Statistic | null; // null for Create, object for Edit
  onClose: () => void;
  onSave: (stat: Statistic) => Promise<void>;
}

export const StatisticFormModal: React.FC<StatisticFormModalProps> = ({
  isOpen,
  stat,
  onClose,
  onSave,
}) => {
  const [formData, setFormData] = useState<Partial<Statistic>>({
    title: '',
    slug: '',
    category: 'iqtisodiyot',
    value: '',
    unit: '',
    change: '',
    isPositiveChange: true,
    chartType: 'line',
    sourceName: '',
    sourceUrl: '',
    verificationDate: new Date().toISOString().split('T')[0],
    status: 'Published',
    description: '',
    dataSeries: [],
    imageUrl: '',
  });

  const [seriesList, setSeriesList] = useState<DataPoint[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (stat) {
      setFormData(stat);
      setSeriesList(stat.dataSeries || []);
    } else {
      setFormData({
        title: '',
        slug: '',
        category: 'iqtisodiyot',
        value: '',
        unit: '',
        change: '',
        isPositiveChange: true,
        chartType: 'line',
        sourceName: "O'zbekiston Respublikasi Statistika Agentligi (stat.uz)",
        sourceUrl: 'https://stat.uz',
        verificationDate: new Date().toISOString().split('T')[0],
        status: 'Published',
        description: '',
        imageUrl: '',
      });
      setSeriesList([
        { label: '2023', value: 100 },
        { label: '2024', value: 120 },
        { label: '2025', value: 135 },
        { label: '2026', value: 150 },
      ]);
    }
    setErrors({});
  }, [stat, isOpen]);

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .trim()
      .replace(/['`’]/g, '')
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-');
  };

  const handleTitleChange = (val: string) => {
    setFormData((prev) => ({
      ...prev,
      title: val,
      slug: !stat ? generateSlug(val) : prev.slug,
    }));
  };

  // Data Series helper
  const addSeriesPoint = () => {
    const nextYear = String(2020 + seriesList.length);
    setSeriesList([...seriesList, { label: nextYear, value: 0 }]);
  };

  const updateSeriesPoint = (index: number, field: keyof DataPoint, val: any) => {
    const updated = [...seriesList];
    updated[index] = {
      ...updated[index],
      [field]: field === 'value' ? Number(val) || 0 : val,
    };
    setSeriesList(updated);
  };

  const removeSeriesPoint = (index: number) => {
    setSeriesList(seriesList.filter((_, i) => i !== index));
  };

  // Form validation based on strict schema
  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.title?.trim()) {
      newErrors.title = "Sarlavha kiritilishi shart";
    }
    if (!formData.slug?.trim()) {
      newErrors.slug = "Slug (URL identifikatori) shart";
    }
    if (!formData.value?.trim()) {
      newErrors.value = "Asosiy qiymat (masalan: 37.6 mln) shart";
    }
    if (!formData.unit?.trim()) {
      newErrors.unit = "O'lchov birligi shart (masalan: % yoki so'm)";
    }
    if (!formData.sourceName?.trim()) {
      newErrors.sourceName = "Rasmiy manba nomi shart";
    }
    if (!formData.sourceUrl?.trim() || !formData.sourceUrl.startsWith('http')) {
      newErrors.sourceUrl = "Ishonchlilik uchun to'g'ri URL manzil (http:// yoki https://) majburiy!";
    }
    if (!formData.verificationDate) {
      newErrors.verificationDate = "Tekshirilgan sana ko'rsatilishi shart";
    }
    if (seriesList.length === 0) {
      newErrors.series = "Kamida bitta grafik nuqtasi (data series) kiritilishi shart";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    try {
      const dataToSave: Statistic = {
        id: stat?.id || `stat-${formData.slug || Date.now()}`,
        title: formData.title!,
        slug: formData.slug!,
        category: formData.category || 'iqtisodiyot',
        value: formData.value!,
        numericValue: Number(formData.value?.replace(/[^0-9.]/g, '')) || undefined,
        unit: formData.unit!,
        change: formData.change || '',
        isPositiveChange: formData.isPositiveChange ?? true,
        chartType: (formData.chartType as ChartType) || 'line',
        sourceName: formData.sourceName!,
        sourceUrl: formData.sourceUrl!,
        verificationDate: formData.verificationDate!,
        status: (formData.status as ContentStatus) || 'Published',
        description: formData.description || '',
        imageUrl: formData.imageUrl || '',
        dataSeries: seriesList,
        createdAt: stat?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await onSave(dataToSave);
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150">
      <div 
        className="w-full max-w-4xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold">
              <BarChart2 size={20} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                {stat ? "Statistikani Tahrirlash" : "Yangi Statistika Qo'shish"}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                O'zbekiston davlat va sohaviy ma'lumotlarini kiritish va yangilash
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto text-xs">
          {/* Top Row: Title & Slug */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Ko'rsatkich Nomi *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => handleTitleChange(e.target.value)}
                placeholder="Masalan: Yalpi Ichki Mahsulot (YaIM) Hajmi"
                className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border ${
                  errors.title ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                } text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-teal-500/20`}
              />
              {errors.title && <p className="text-rose-500 text-[10px] mt-1">{errors.title}</p>}
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Slug (URL identifikatori) *
              </label>
              <input
                type="text"
                value={formData.slug}
                onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                placeholder="yaim-hajmi"
                className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border ${
                  errors.slug ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                } text-slate-900 dark:text-white focus:outline-hidden font-mono`}
              />
              {errors.slug && <p className="text-rose-500 text-[10px] mt-1">{errors.slug}</p>}
            </div>
          </div>

          {/* Category & Status & ChartType */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Soha (Kategoriya) *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-medium"
              >
                {INITIAL_CATEGORIES.map((c) => (
                  <option key={c.id} value={c.slug}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Grafik Turi *
              </label>
              <select
                value={formData.chartType}
                onChange={(e) => setFormData({ ...formData, chartType: e.target.value as ChartType })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-medium"
              >
                <option value="line">Chiziqli (Line)</option>
                <option value="area">Sohaviy (Area)</option>
                <option value="bar">Ustunli (Bar)</option>
                <option value="donut">Doiraviy (Donut)</option>
                <option value="table">Faqat Jadval (Table)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Holati (Status) *
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as ContentStatus })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
              >
                <option value="Published">Chop etilgan (Published)</option>
                <option value="Draft">Qoralama (Draft)</option>
                <option value="Unpublished">Yashiringan (Unpublished)</option>
              </select>
            </div>
          </div>

          {/* Value, Unit, Change */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Asosiy Qiymat *
              </label>
              <input
                type="text"
                value={formData.value}
                onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                placeholder="37.6 mln"
                className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border ${
                  errors.value ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                } text-slate-900 dark:text-white font-mono font-bold`}
              />
              {errors.value && <p className="text-rose-500 text-[10px] mt-1">{errors.value}</p>}
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                O'lchov Birligi *
              </label>
              <input
                type="text"
                value={formData.unit}
                onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                placeholder="mln kishi, mlrd dollar, %"
                className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border ${
                  errors.unit ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                } text-slate-900 dark:text-white`}
              />
              {errors.unit && <p className="text-rose-500 text-[10px] mt-1">{errors.unit}</p>}
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Dinamika (O'zgarish)
              </label>
              <input
                type="text"
                value={formData.change}
                onChange={(e) => setFormData({ ...formData, change: e.target.value })}
                placeholder="+2.1% (yillik)"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Source Information (MANDATORY FOR CREDIBILITY) */}
          <div className="p-4 rounded-2xl bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200/60 dark:border-teal-900/50 space-y-4">
            <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
              <span>Rasmiy Manba va Ishonchlilik Ma'lumotlari</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-1">
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Manba Tashkilot Nomi *
                </label>
                <input
                  type="text"
                  value={formData.sourceName}
                  onChange={(e) => setFormData({ ...formData, sourceName: e.target.value })}
                  placeholder="Statistika Agentligi (stat.uz)"
                  className={`w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border ${
                    errors.sourceName ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  } text-slate-900 dark:text-white`}
                />
                {errors.sourceName && <p className="text-rose-500 text-[10px] mt-1">{errors.sourceName}</p>}
              </div>

              <div className="sm:col-span-1">
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Birlamchi Manba URL manzili *
                </label>
                <input
                  type="url"
                  value={formData.sourceUrl}
                  onChange={(e) => setFormData({ ...formData, sourceUrl: e.target.value })}
                  placeholder="https://stat.uz/uz/..."
                  className={`w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border ${
                    errors.sourceUrl ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  } text-slate-900 dark:text-white font-mono`}
                />
                {errors.sourceUrl && <p className="text-rose-500 text-[10px] mt-1">{errors.sourceUrl}</p>}
              </div>

              <div className="sm:col-span-1">
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Tekshiruv Sanasi *
                </label>
                <input
                  type="date"
                  value={formData.verificationDate}
                  onChange={(e) => setFormData({ ...formData, verificationDate: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Tahliliy Sharh / Izoh
            </label>
            <textarea
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Ko'rsatkichning mohiyati, o'sish sabablari va metodologiya haqida ma'lumot..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-hidden"
            />
          </div>

          {/* Dynamic Data Series Editor */}
          <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-4 bg-slate-50/50 dark:bg-slate-900/50">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white text-xs">
                  Grafik Nuqtalari (Data Series)
                </h4>
                <p className="text-[11px] text-slate-400">
                  Vaqt oralig'i (yil/oy) va mos raqamli qiymatlarni kiritish
                </p>
              </div>
              <button
                type="button"
                onClick={addSeriesPoint}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-semibold transition"
              >
                <Plus size={13} />
                <span>Nuqta Qo'shish</span>
              </button>
            </div>

            {errors.series && <p className="text-rose-500 text-[10px] mb-2">{errors.series}</p>}

            <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
              {seriesList.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={item.label}
                    onChange={(e) => updateSeriesPoint(idx, 'label', e.target.value)}
                    placeholder="2024"
                    className="w-24 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono"
                  />
                  <input
                    type="number"
                    step="any"
                    value={item.value}
                    onChange={(e) => updateSeriesPoint(idx, 'value', e.target.value)}
                    placeholder="120"
                    className="w-28 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono font-bold"
                  />
                  <input
                    type="text"
                    value={item.note || ''}
                    onChange={(e) => updateSeriesPoint(idx, 'note', e.target.value)}
                    placeholder="Ixtiyoriy izoh (masalan: Pandemiya)"
                    className="flex-1 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-[11px]"
                  />
                  <button
                    type="button"
                    onClick={() => removeSeriesPoint(idx)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>

            {/* Live Chart Preview */}
            {seriesList.length > 1 && (
              <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
                <p className="text-[10px] uppercase font-bold text-slate-400 mb-2">
                  Jonli Grafik Ko'rinishi (Preview)
                </p>
                <div className="h-40 bg-white dark:bg-slate-900 rounded-xl p-2 border border-slate-100 dark:border-slate-800">
                  <DataChart
                    data={seriesList}
                    type={(formData.chartType as ChartType) || 'line'}
                    unit={formData.unit}
                    height={150}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition font-semibold"
            >
              Bekor qilish
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold transition flex items-center gap-2 shadow-md disabled:opacity-50"
            >
              {submitting ? (
                <span>Saqlanmoqda...</span>
              ) : (
                <>
                  <Save size={15} />
                  <span>Saqlash</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
