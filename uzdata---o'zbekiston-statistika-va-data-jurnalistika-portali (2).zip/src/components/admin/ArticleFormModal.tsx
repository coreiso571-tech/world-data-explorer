import React, { useState, useEffect } from 'react';
import { X, Save, BookOpen } from 'lucide-react';
import { Article, ContentStatus } from '../../types';
import { INITIAL_CATEGORIES } from '../../data/seedData';

interface ArticleFormModalProps {
  isOpen: boolean;
  article: Article | null;
  onClose: () => void;
  onSave: (art: Article) => Promise<void>;
}

export const ArticleFormModal: React.FC<ArticleFormModalProps> = ({
  isOpen,
  article,
  onClose,
  onSave,
}) => {
  const [formData, setFormData] = useState<Partial<Article>>({
    title: '',
    slug: '',
    category: 'iqtisodiyot',
    excerpt: '',
    content: '',
    author: 'UZDATA Tahliliy Guruhi',
    tags: [],
    readingTime: '5 daqiqa',
    imageUrl: '',
    status: 'Published',
  });

  const [tagsInput, setTagsInput] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (article) {
      setFormData(article);
      setTagsInput(article.tags?.join(', ') || '');
    } else {
      setFormData({
        title: '',
        slug: '',
        category: 'iqtisodiyot',
        excerpt: '',
        content: '',
        author: 'UZDATA Tahliliy Guruhi',
        tags: [],
        readingTime: '5 daqiqa',
        imageUrl: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=1200&q=80',
        status: 'Published',
      });
      setTagsInput('Iqtisodiyot, Tahlil, O\'zbekiston');
    }
    setErrors({});
  }, [article, isOpen]);

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .trim()
      .replace(/['`’]/g, '')
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-');
  };

  const handleTitleChange = (val: string) => {
    setFormData((prev) => ({
      ...prev,
      title: val,
      slug: !article ? generateSlug(val) : prev.slug,
    }));
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (!formData.title?.trim()) newErrors.title = "Maqola sarlavhasi kiritilishi shart";
    if (!formData.slug?.trim()) newErrors.slug = "Slug shart";
    if (!formData.content?.trim()) newErrors.content = "Maqola matni kiritilishi shart";
    if (!formData.author?.trim()) newErrors.author = "Muallif kiritilishi shart";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    try {
      const parsedTags = tagsInput
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);

      const toSave: Article = {
        id: article?.id || `art-${formData.slug || Date.now()}`,
        title: formData.title!,
        slug: formData.slug!,
        category: formData.category || 'iqtisodiyot',
        excerpt: formData.excerpt || '',
        content: formData.content!,
        author: formData.author!,
        tags: parsedTags,
        readingTime: formData.readingTime || '5 daqiqa',
        imageUrl: formData.imageUrl || '',
        status: (formData.status as ContentStatus) || 'Published',
        createdAt: article?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await onSave(toSave);
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150">
      <div 
        className="w-full max-w-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
              <BookOpen size={20} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                {article ? "Maqolani Tahrirlash" : "Yangi Data Jurnalistika Maqolasi"}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Tahliliy hikoyalar, ekspert xulosalari va reportajlar
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Maqola Sarlavhasi *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => handleTitleChange(e.target.value)}
                placeholder="Masalan: Raqamli iqtisodiyot va IT eksporti o'sishi"
                className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border ${
                  errors.title ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                } text-slate-900 dark:text-white`}
              />
              {errors.title && <p className="text-rose-500 text-[10px] mt-1">{errors.title}</p>}
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Slug (URL identifikatori) *
              </label>
              <input
                type="text"
                value={formData.slug}
                onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                placeholder="raqamli-iqtisodiyot-eksport"
                className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border ${
                  errors.slug ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                } text-slate-900 dark:text-white font-mono`}
              />
              {errors.slug && <p className="text-rose-500 text-[10px] mt-1">{errors.slug}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Soha (Kategoriya)
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-medium"
              >
                {INITIAL_CATEGORIES.map((c) => (
                  <option key={c.id} value={c.slug}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Muallif *
              </label>
              <input
                type="text"
                value={formData.author}
                onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                placeholder="UZDATA Tahliliy Guruhi"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Holati (Status) *
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as ContentStatus })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
              >
                <option value="Published">Chop etilgan (Published)</option>
                <option value="Draft">Qoralama (Draft)</option>
                <option value="Unpublished">Yashiringan (Unpublished)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Rasm URL manzili
              </label>
              <input
                type="url"
                value={formData.imageUrl}
                onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                placeholder="https://images.unsplash.com/..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-[11px]"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Teglar (vergul bilan)
              </label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="Demografiya, YaIM, O'sish"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Qisqacha mazmun (Excerpt)
            </label>
            <textarea
              rows={2}
              value={formData.excerpt}
              onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
              placeholder="Maqola kartochkasida ko'rinadigan 1-2 jumlali xulosa..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              To'liq Matn (Content) *
            </label>
            <textarea
              rows={8}
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              placeholder="Maqola matni, asosiy tahliliy xulosalar, statistik ma'lumotlar tahlili..."
              className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border ${
                errors.content ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
              } text-slate-900 dark:text-white leading-relaxed font-sans`}
            />
            {errors.content && <p className="text-rose-500 text-[10px] mt-1">{errors.content}</p>}
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition font-semibold"
            >
              Bekor qilish
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold transition flex items-center gap-2 shadow-md disabled:opacity-50"
            >
              {submitting ? (
                <span>Saqlanmoqda...</span>
              ) : (
                <>
                  <Save size={15} />
                  <span>Maqolani Saqlash</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
