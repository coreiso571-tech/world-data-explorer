import React, { useState, useEffect, useMemo } from 'react';
import {
  Trophy,
  Award,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ArrowRight,
  RotateCcw,
  Share2,
  Sparkles,
  Flame,
  Clock,
  Target,
  ExternalLink,
  ChevronRight,
  Send,
  BookOpen,
  Check
} from 'lucide-react';
import { QUIZ_QUESTIONS, QuizQuestion } from '../../data/quizData';

interface QuizAppProps {
  onBackToHome?: () => void;
}

export const QuizApp: React.FC<QuizAppProps> = ({ onBackToHome }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);
  const [answersHistory, setAnswersHistory] = useState<{
    questionId: string;
    questionText: string;
    selected: number;
    correct: number;
    isCorrect: boolean;
    explanation: string;
    source: string;
  }[]>([]);
  const [isCompleted, setIsCompleted] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);

  // Initialize and shuffle questions based on selected category
  const initQuiz = (category: string = selectedCategory) => {
    let pool = [...QUIZ_QUESTIONS];
    if (category !== 'all') {
      pool = pool.filter((q) => q.category === category);
    }
    // Shuffle pool
    const shuffled = pool.sort(() => 0.5 - Math.random());
    // Take max 10 questions for an engaging session
    const selected = shuffled.slice(0, 10);
    setQuestions(selected);
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setStreak(0);
    setMaxStreak(0);
    setAnswersHistory([]);
    setIsCompleted(false);
    setCopiedShare(false);
  };

  useEffect(() => {
    initQuiz(selectedCategory);
  }, [selectedCategory]);

  const currentQuestion = questions[currentIndex];

  const handleSelectOption = (idx: number) => {
    if (isAnswered || !currentQuestion) return;

    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQuestion.correctIndex;
    const newStreak = isCorrect ? streak + 1 : 0;
    const pointsGained = isCorrect ? 100 + streak * 20 : 0; // Streak bonus

    if (isCorrect) {
      setScore((prev) => prev + pointsGained);
      setStreak(newStreak);
      if (newStreak > maxStreak) setMaxStreak(newStreak);
    } else {
      setStreak(0);
    }

    setAnswersHistory((prev) => [
      ...prev,
      {
        questionId: currentQuestion.id,
        questionText: currentQuestion.question,
        selected: idx,
        correct: currentQuestion.correctIndex,
        isCorrect,
        explanation: currentQuestion.explanation,
        source: currentQuestion.source,
      },
    ]);
  };

  const handleNext = () => {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setIsCompleted(true);
    }
  };

  const correctAnswersCount = answersHistory.filter((a) => a.isCorrect).length;
  const percentage = questions.length > 0 ? Math.round((correctAnswersCount / questions.length) * 100) : 0;

  // Rank determination
  const rank = useMemo(() => {
    if (percentage >= 90) {
      return {
        title: "Statistika Bosh Eksperti",
        badge: '🏆',
        color: 'from-amber-400 via-lime-400 to-emerald-400',
        textColor: 'text-lime-400',
        message: "Aql bovar qilmas natija! Siz O'zbekistonning ijtimoiy-iqtisodiy raqamlari va davlat statistikasini mukammal bilasiz.",
      };
    }
    if (percentage >= 70) {
      return {
        title: "Milliy Tahlilchi",
        badge: '🌟',
        color: 'from-teal-400 to-cyan-400',
        textColor: 'text-teal-400',
        message: "Ajoyib bilim! Siz O'zbekiston rivojlanish ko'rsatkichlari bo'yicha yuqori xabardorlikka egasiz.",
      };
    }
    if (percentage >= 50) {
      return {
        title: "Statistika Bilimdoni",
        badge: '📈',
        color: 'from-blue-400 to-teal-400',
        textColor: 'text-cyan-400',
        message: "Yaxshi natija! Ko'rsatkichlarning asosiy qismini bilasiz. Portaldagi boshqa tahlillarni o'qib bilimingizni yanada boyiting.",
      };
    }
    return {
      title: "Boshlang'ich Kuzatuvchi",
      badge: '📚',
      color: 'from-slate-400 to-teal-400',
      textColor: 'text-slate-300',
      message: "Yaxshi boshlanish! UZDATA portalida rasmiy raqamlar bilan tanishib, o'z bilimingizni oshiring va qayta sinab ko'ring.",
    };
  }, [percentage]);

  const shareText = `🇺🇿 Men UZDATA statistika viktorinasida ${questions.length} tadan ${correctAnswersCount} ta to'g'ri javob (${percentage}%) to'pladim!\nUnvonim: ${rank.badge} ${rank.title} (${score} ball)\nO'zingizni sinab ko'ring: ${window.location.origin}/#quiz`;

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "UZDATA Statistika Viktorinasi Natijasi",
          text: shareText,
          url: `${window.location.origin}/#quiz`,
        });
        return;
      } catch {
        // User cancelled or unsupported, fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(shareText);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 3000);
    } catch {
      // Fallback
    }
  };

  const handleTelegramShare = () => {
    const tgUrl = `https://t.me/share/url?url=${encodeURIComponent(
      window.location.origin + '/#quiz'
    )}&text=${encodeURIComponent(shareText)}`;
    window.open(tgUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-12 animate-in fade-in duration-300">
      {/* Top Banner & Title */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-500/10 dark:bg-lime-500/10 border border-teal-500/20 dark:border-lime-500/30 text-teal-800 dark:text-lime-300 text-xs font-semibold mb-3">
          <Sparkles size={14} className="text-teal-600 dark:text-lime-400" />
          <span>Interaktiv Viktorina & Bilimni Sinash</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          O'zbekiston Statistika Viktorinasi
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-xl mx-auto mt-2">
          Rasmiy davlat reestrlari, aholi, YaIM, IT va viloyatlar bo'yicha qanchalik xabardorsiz? Bilimingizni sinang va darajangizni bilib oling!
        </p>

        {/* Category Filter Pills */}
        <div className="flex items-center justify-center gap-2 mt-5 flex-wrap">
          {[
            { id: 'all', label: 'Barcha Sohalar' },
            { id: 'demografiya', label: 'Demografiya' },
            { id: 'iqtisodiyot', label: 'Iqtisodiyot' },
            { id: 'it-biznes', label: 'IT & Innovatsiya' },
            { id: 'hududlar', label: 'Hududlar' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-teal-600 dark:bg-lime-400 text-white dark:text-slate-950 shadow-sm'
                  : 'bg-white dark:bg-slate-900/80 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:border-teal-500'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {!isCompleted ? (
        /* Quiz Active Screen */
        <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800/80 rounded-3xl p-5 sm:p-8 shadow-xl relative overflow-hidden">
          {/* Top Decorative accent line */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-teal-500 via-lime-400 to-cyan-500" />

          {/* Live Score Tracker Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 mb-6 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/60 dark:border-slate-800/60 text-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold">
                <Target size={16} />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400">Savol</span>
                <p className="font-mono font-bold text-slate-900 dark:text-white">
                  {currentIndex + 1} / {questions.length}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center font-bold">
                <Trophy size={16} />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400">Ball</span>
                <p className="font-mono font-bold text-slate-900 dark:text-white">
                  {score}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center font-bold">
                <Flame size={16} />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400">Ketma-ket (Streak)</span>
                <p className="font-mono font-bold text-slate-900 dark:text-white">
                  {streak > 1 ? `🔥 ${streak}x` : `${streak}`}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-lime-500/10 text-lime-600 dark:text-lime-400 flex items-center justify-center font-bold">
                <CheckCircle2 size={16} />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400">To'g'ri javoblar</span>
                <p className="font-mono font-bold text-slate-900 dark:text-white">
                  {correctAnswersCount} ta
                </p>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full mb-6 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-teal-500 to-lime-400 transition-all duration-300 rounded-full"
              style={{
                width: `${((currentIndex + 1) / questions.length) * 100}%`,
              }}
            />
          </div>

          {currentQuestion && (
            <div>
              {/* Question Header & Badge */}
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300">
                  {currentQuestion.categoryLabel}
                </span>
                <span className="text-[11px] font-medium text-slate-400">
                  Qiyinligi: <span className="text-slate-600 dark:text-slate-300 font-semibold">{currentQuestion.difficulty}</span>
                </span>
              </div>

              {/* Question Title */}
              <h2 className="text-lg sm:text-2xl font-bold text-slate-900 dark:text-white mb-6 leading-snug">
                {currentQuestion.question}
              </h2>

              {/* Multiple Choice Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                {currentQuestion.options.map((option, idx) => {
                  const letter = String.fromCharCode(65 + idx); // A, B, C, D
                  const isSelected = selectedOption === idx;
                  const isCorrect = idx === currentQuestion.correctIndex;

                  let buttonStyles =
                    'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-teal-500/60 dark:hover:border-lime-500/60 text-slate-800 dark:text-slate-200';

                  if (isAnswered) {
                    if (isCorrect) {
                      buttonStyles =
                        'border-lime-500 bg-lime-500/10 text-emerald-800 dark:text-lime-300 shadow-md ring-2 ring-lime-400/40';
                    } else if (isSelected && !isCorrect) {
                      buttonStyles =
                        'border-rose-500 bg-rose-500/10 text-rose-800 dark:text-rose-300 shadow-sm ring-1 ring-rose-400/30';
                    } else {
                      buttonStyles =
                        'border-slate-200/50 dark:border-slate-800/40 bg-slate-50/50 dark:bg-slate-900/40 text-slate-400 opacity-60';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      disabled={isAnswered}
                      onClick={() => handleSelectOption(idx)}
                      className={`w-full p-4 rounded-2xl border text-left transition-all duration-200 flex items-center justify-between group cursor-pointer ${buttonStyles}`}
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className={`w-8 h-8 rounded-xl font-mono text-xs font-bold flex items-center justify-center shrink-0 transition ${
                            isAnswered && isCorrect
                              ? 'bg-lime-500 text-slate-950'
                              : isAnswered && isSelected && !isCorrect
                              ? 'bg-rose-500 text-white'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 group-hover:bg-teal-500 group-hover:text-white dark:group-hover:bg-lime-400 dark:group-hover:text-slate-950'
                          }`}
                        >
                          {letter}
                        </span>
                        <span className="text-xs sm:text-sm font-semibold">{option}</span>
                      </div>

                      {isAnswered && isCorrect && (
                        <CheckCircle2 size={18} className="text-lime-500 shrink-0" />
                      )}
                      {isAnswered && isSelected && !isCorrect && (
                        <XCircle size={18} className="text-rose-500 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Instant Explanation Feedback Card */}
              {isAnswered && (
                <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-50 to-teal-50/30 dark:from-slate-950 dark:to-teal-950/20 border border-teal-500/30 dark:border-lime-500/30 mb-6 animate-in fade-in slide-in-from-bottom-2 duration-200">
                  <div className="flex items-center gap-2 mb-2">
                    {selectedOption === currentQuestion.correctIndex ? (
                      <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-lime-400">
                        <CheckCircle2 size={16} />
                        <span>To'g'ri javob! (+100 ball)</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 text-xs font-bold text-rose-500">
                        <XCircle size={16} />
                        <span>Noto'g'ri. To'g'ri variant: {String.fromCharCode(65 + currentQuestion.correctIndex)}</span>
                      </div>
                    )}
                  </div>

                  <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed mb-3">
                    {currentQuestion.explanation}
                  </p>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-200/60 dark:border-slate-800/60">
                    <span className="flex items-center gap-1.5 font-medium">
                      <BookOpen size={12} className="text-teal-500" />
                      Manba: {currentQuestion.source}
                    </span>
                  </div>
                </div>
              )}

              {/* Next Question Button */}
              {isAnswered && (
                <div className="flex justify-end">
                  <button
                    onClick={handleNext}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-teal-500 via-teal-600 to-lime-500 hover:from-teal-600 hover:to-lime-600 text-white font-bold text-sm shadow-lg shadow-teal-500/20 transition cursor-pointer group"
                  >
                    <span>
                      {currentIndex + 1 < questions.length ? "Keyingi Savol" : "Natijalarni Ko'rish"}
                    </span>
                    <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        /* Final Result Card */
        <div className="bg-white/85 dark:bg-slate-900/85 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800/80 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-200">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-teal-400 via-lime-400 to-emerald-400" />

          {/* Celebratory Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center text-5xl mb-3 animate-bounce">
              {rank.badge}
            </div>
            <div className="inline-block px-3 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider bg-lime-500/10 text-lime-600 dark:text-lime-400 border border-lime-500/30 mb-2">
              Viktorina Yakunlandi
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
              {rank.title}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-2">
              {rank.message}
            </p>
          </div>

          {/* Metrics summary cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-8">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/60 dark:border-slate-800/60 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Jami Ball</span>
              <p className="text-2xl sm:text-3xl font-mono font-extrabold text-teal-600 dark:text-lime-400 mt-1">
                {score}
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/60 dark:border-slate-800/60 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">To'g'ri Javob</span>
              <p className="text-2xl sm:text-3xl font-mono font-extrabold text-slate-900 dark:text-white mt-1">
                {correctAnswersCount} / {questions.length}
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/60 dark:border-slate-800/60 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Aniqlik</span>
              <p className="text-2xl sm:text-3xl font-mono font-extrabold text-slate-900 dark:text-white mt-1">
                {percentage}%
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/60 dark:border-slate-800/60 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Maks. Streak</span>
              <p className="text-2xl sm:text-3xl font-mono font-extrabold text-amber-500 mt-1">
                🔥 {maxStreak}x
              </p>
            </div>
          </div>

          {/* Action Buttons: Share, Telegram, Restart */}
          <div className="flex flex-wrap items-center justify-center gap-3 mb-10">
            {/* Share Button */}
            <button
              onClick={handleShare}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-teal-500 via-lime-500 to-emerald-500 hover:opacity-95 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition cursor-pointer"
            >
              {copiedShare ? (
                <>
                  <Check size={16} className="text-slate-950" />
                  <span>Nusxalandi!</span>
                </>
              ) : (
                <>
                  <Share2 size={16} />
                  <span>Natijani Ulashish</span>
                </>
              )}
            </button>

            {/* Telegram Share */}
            <button
              onClick={handleTelegramShare}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-sky-500 hover:bg-sky-600 text-white font-semibold text-xs sm:text-sm shadow-sm transition cursor-pointer"
            >
              <Send size={15} />
              <span>Telegramda ulashish</span>
            </button>

            {/* Play Again */}
            <button
              onClick={() => initQuiz(selectedCategory)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-xs sm:text-sm transition cursor-pointer"
            >
              <RotateCcw size={15} />
              <span>Qayta o'ynash</span>
            </button>

            {/* Back to Home if provided */}
            {onBackToHome && (
              <button
                onClick={onBackToHome}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-slate-500 hover:text-slate-900 dark:hover:text-white text-xs sm:text-sm transition"
              >
                <span>Bosh sahifaga qaytish</span>
              </button>
            )}
          </div>

          {/* Question Breakdown List */}
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
              <CheckCircle2 size={16} className="text-teal-500" />
              <span>Savollar Tahlili va Natijalar ({answersHistory.length})</span>
            </h3>

            <div className="space-y-2">
              {answersHistory.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl bg-slate-50/80 dark:bg-slate-950/40 border border-slate-200/60 dark:border-slate-800/60 text-xs"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <span className="mt-0.5">
                        {item.isCorrect ? (
                          <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
                        ) : (
                          <XCircle size={16} className="text-rose-500 shrink-0" />
                        )}
                      </span>
                      <div>
                        <p className="font-semibold text-slate-900 dark:text-white mb-1">
                          {idx + 1}. {item.questionText}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          {item.explanation}
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-200/60 dark:bg-slate-800 text-slate-600 dark:text-slate-300 shrink-0">
                      {item.isCorrect ? '+100 ball' : '0 ball'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
