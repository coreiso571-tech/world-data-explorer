import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import {
  BarChart3,
  LineChart as LineIcon,
  PieChart as PieIcon,
  AreaChart as AreaIcon,
  Download,
  Filter,
  Layers,
  Sparkles,
  TrendingUp,
  MapPin,
  Calendar,
  Check,
  ChevronDown,
  FileSpreadsheet,
  Image as ImageIcon,
  CheckSquare,
  Square,
  Info,
  Maximize2
} from 'lucide-react';
import { Statistic, Category, DataPoint, RegionData } from '../../types';
import { REGIONS_DATA } from '../../data/seedData';
import { useTheme } from '../../context/ThemeContext';

interface InteractiveStudioProps {
  statistics: Statistic[];
  categories: Category[];
  onSelectStat?: (stat: Statistic) => void;
}

const COLORS = [
  '#0d9488', // teal-600
  '#a3e635', // lime-400
  '#06b6d4', // cyan-500
  '#6366f1', // indigo-500
  '#f59e0b', // amber-500
  '#ec4899', // pink-500
  '#8b5cf6', // purple-500
  '#10b981', // emerald-500
  '#3b82f6', // blue-500
  '#f97316', // orange-500
];

export const InteractiveStudio: React.FC<InteractiveStudioProps> = ({
  statistics,
  categories,
}) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  // Filters state
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [selectedStatId, setSelectedStatId] = useState<string>('');
  const [chartType, setChartType] = useState<'bar' | 'line' | 'pie' | 'area'>('bar');

  // Active data points toggle state (map of label -> boolean)
  const [activePointsMap, setActivePointsMap] = useState<Record<string, boolean>>({});

  // Export dropdown state
  const [exportOpen, setExportOpen] = useState(false);
  const [exportStatus, setExportStatus] = useState<string | null>(null);

  const chartRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setExportOpen(false);
      }
    };
    if (exportOpen) document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, [exportOpen]);

  // Filter available statistics by category
  const filteredStatistics = useMemo(() => {
    return statistics.filter((stat) => {
      if (selectedCategory !== 'all' && stat.category !== selectedCategory) {
        return false;
      }
      return true;
    });
  }, [statistics, selectedCategory]);

  // Set default selected stat if current is not in list
  useEffect(() => {
    if (filteredStatistics.length > 0) {
      if (!selectedStatId || !filteredStatistics.some((s) => s.id === selectedStatId)) {
        setSelectedStatId(filteredStatistics[0].id);
      }
    }
  }, [filteredStatistics, selectedStatId]);

  // Current selected statistic object
  const currentStat = useMemo(() => {
    return (
      statistics.find((s) => s.id === selectedStatId) ||
      statistics[0] ||
      null
    );
  }, [statistics, selectedStatId]);

  // Base raw data points
  const rawDataSeries: DataPoint[] = useMemo(() => {
    if (selectedRegion !== 'all') {
      // If a specific region is selected, construct regional perspective
      const reg = REGIONS_DATA.find((r) => r.id === selectedRegion);
      if (reg) {
        return [
          { label: 'Aholi (ming)', value: reg.population, note: reg.populationStr },
          { label: "O'rtacha oylik (ming so'm)", value: Math.round(reg.avgSalary / 1000), note: reg.avgSalaryStr },
          { label: 'YaIM ulushi (%)', value: reg.gdpShare, note: `${reg.gdpShare}%` },
          { label: 'Maydon (ming kv.km)', value: Math.round(reg.areaKm2 / 1000), note: `${reg.areaKm2} kv.km` },
        ];
      }
    }

    if (!currentStat || !currentStat.dataSeries) return [];
    return currentStat.dataSeries;
  }, [currentStat, selectedRegion]);

  // Initialize all points to active whenever dataset changes
  useEffect(() => {
    const initialMap: Record<string, boolean> = {};
    rawDataSeries.forEach((pt) => {
      initialMap[pt.label] = true;
    });
    setActivePointsMap(initialMap);
  }, [currentStat?.id, selectedRegion, rawDataSeries]);

  // Filtered active data points
  const activeDataPoints = useMemo(() => {
    return rawDataSeries.filter((pt) => activePointsMap[pt.label] !== false);
  }, [rawDataSeries, activePointsMap]);

  // Toggle single point
  const togglePoint = (label: string) => {
    setActivePointsMap((prev) => ({
      ...prev,
      [label]: prev[label] === false ? true : false,
    }));
  };

  // Toggle all points ON
  const enableAllPoints = () => {
    const nextMap: Record<string, boolean> = {};
    rawDataSeries.forEach((pt) => {
      nextMap[pt.label] = true;
    });
    setActivePointsMap(nextMap);
  };

  // Toggle all points OFF (keep at least first one so chart doesn't crash)
  const disableAllPoints = () => {
    const nextMap: Record<string, boolean> = {};
    rawDataSeries.forEach((pt, idx) => {
      nextMap[pt.label] = idx === 0;
    });
    setActivePointsMap(nextMap);
  };

  // Select last 5 years / items
  const selectRecentFive = () => {
    const nextMap: Record<string, boolean> = {};
    const total = rawDataSeries.length;
    rawDataSeries.forEach((pt, idx) => {
      nextMap[pt.label] = idx >= total - 5;
    });
    setActivePointsMap(nextMap);
  };

  // Dynamic calculations for active data points
  const statsSummary = useMemo(() => {
    if (activeDataPoints.length === 0) {
      return { count: 0, min: 0, max: 0, avg: 0, sum: 0, growth: 0 };
    }
    const values = activeDataPoints.map((d) => d.value);
    const sum = values.reduce((acc, v) => acc + v, 0);
    const avg = sum / values.length;
    const min = Math.min(...values);
    const max = Math.max(...values);

    let growth = 0;
    if (values.length >= 2) {
      const first = values[0];
      const last = values[values.length - 1];
      if (first !== 0) {
        growth = ((last - first) / first) * 100;
      }
    }

    return {
      count: activeDataPoints.length,
      min: Number(min.toFixed(2)),
      max: Number(max.toFixed(2)),
      avg: Number(avg.toFixed(2)),
      sum: Number(sum.toFixed(2)),
      growth: Number(growth.toFixed(1)),
    };
  }, [activeDataPoints]);

  // CSV Export
  const exportCSV = () => {
    if (activeDataPoints.length === 0) return;
    setExportStatus('csv_success');
    setExportOpen(false);

    const headers = ['Davr / Ko\'rsatkich', `Qiymat (${currentStat?.unit || 'Birlik'})`, 'Izoh'];
    const rows = activeDataPoints.map((d) => [
      `"${String(d.label).replace(/"/g, '""')}"`,
      d.value,
      `"${String(d.note || '').replace(/"/g, '""')}"`,
    ]);
    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${(currentStat?.slug || 'interaktiv-statistika')}-uzdata.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setTimeout(() => setExportStatus(null), 2500);
  };

  // PNG Export via Canvas
  const exportPNG = async () => {
    if (activeDataPoints.length === 0) return;
    setExportStatus('png_loading');
    setExportOpen(false);

    try {
      const svg = chartRef.current?.querySelector('.recharts-wrapper svg') as SVGElement | null;
      const canvasWidth = 960;
      const canvasHeight = 560;
      const canvas = document.createElement('canvas');
      canvas.width = canvasWidth * 2;
      canvas.height = canvasHeight * 2;
      const ctx = canvas.getContext('2d');

      if (!ctx) throw new Error('Canvas context unavailable');
      ctx.scale(2, 2);

      // Background
      ctx.fillStyle = isDark ? '#081225' : '#ffffff';
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

      // Gradient accent
      const grad = ctx.createLinearGradient(0, 0, canvasWidth, canvasHeight);
      grad.addColorStop(0, isDark ? 'rgba(13, 148, 136, 0.15)' : 'rgba(240, 253, 250, 0.8)');
      grad.addColorStop(1, isDark ? 'rgba(163, 230, 53, 0.08)' : 'rgba(255, 255, 255, 1)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

      // Top glowing banner
      const topBar = ctx.createLinearGradient(0, 0, canvasWidth, 0);
      topBar.addColorStop(0, '#0d9488');
      topBar.addColorStop(0.5, '#a3e635');
      topBar.addColorStop(1, '#10b981');
      ctx.fillStyle = topBar;
      ctx.fillRect(0, 0, canvasWidth, 6);

      // Title & Header
      ctx.font = 'bold 11px system-ui, sans-serif';
      ctx.fillStyle = isDark ? '#a3e635' : '#0d9488';
      ctx.fillText("UZDATA • INTERAKTIV STATISTIKA STUDIYASI", 40, 42);

      ctx.font = 'bold 22px system-ui, sans-serif';
      ctx.fillStyle = isDark ? '#ffffff' : '#0f172a';
      const cleanTitle = currentStat?.title || "Interaktiv Statistika Grafigi";
      ctx.fillText(cleanTitle.slice(0, 55), 40, 72);

      ctx.font = '12px system-ui, sans-serif';
      ctx.fillStyle = isDark ? '#94a3b8' : '#64748b';
      ctx.fillText(
        `Birlik: ${currentStat?.unit || "Qiymat"} • Faol nuqtalar: ${activeDataPoints.length} ta • Sana: ${new Date().toLocaleDateString('uz-UZ')}`,
        40,
        94
      );

      // Draw SVG chart into canvas
      if (svg) {
        const svgClone = svg.cloneNode(true) as SVGElement;
        svgClone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
        svgClone.setAttribute('width', `${canvasWidth - 80}`);
        svgClone.setAttribute('height', `${canvasHeight - 170}`);

        const textEls = svgClone.querySelectorAll('text');
        textEls.forEach((t) => {
          if (!t.getAttribute('fill') || t.getAttribute('fill') === 'currentColor') {
            t.setAttribute('fill', isDark ? '#cbd5e1' : '#475569');
          }
        });

        const svgData = new XMLSerializer().serializeToString(svgClone);
        const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
        const url = URL.createObjectURL(svgBlob);
        const img = new Image();

        img.onload = () => {
          ctx.drawImage(img, 40, 110, canvasWidth - 80, canvasHeight - 170);
          URL.revokeObjectURL(url);

          // Footer
          ctx.font = '10px system-ui, sans-serif';
          ctx.fillStyle = isDark ? '#64748b' : '#94a3b8';
          ctx.fillText("Manba: O'zbekiston rasmiy davlat reestrlari | uzdata.uz", 40, canvasHeight - 20);

          const pngUrl = canvas.toDataURL('image/png');
          const dl = document.createElement('a');
          dl.href = pngUrl;
          dl.download = `${(currentStat?.slug || 'interaktiv-grafik')}-hd.png`;
          document.body.appendChild(dl);
          dl.click();
          document.body.removeChild(dl);
          setExportStatus('png_success');
          setTimeout(() => setExportStatus(null), 2500);
        };
        img.src = url;
      }
    } catch {
      setExportStatus(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-500/10 dark:bg-lime-500/10 border border-teal-500/20 dark:border-lime-500/30 text-teal-800 dark:text-lime-300 text-xs font-semibold mb-3">
          <Sparkles size={14} className="text-teal-600 dark:text-lime-400" />
          <span>Dinamik Tahlil & Interaktiv Vizualizatsiya</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          Interaktiv Statistika Studiyasi
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-3xl mt-1 leading-relaxed">
          Ma'lumotlar bilan jonli ishlang: diagramma turini (Ustunli, Chiziqli, Doiraviy, Maydonli) almashtiring,
          soha va viloyatlar bo'yicha saralang hamda alohida yillar yoki nuqtalarni yoqib/o'chiring.
        </p>
      </div>

      {/* Main Studio Card */}
      <div className="bg-white/85 dark:bg-slate-900/85 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800/80 rounded-3xl p-5 sm:p-7 shadow-xl">
        {/* Controls Toolbar: Categories, Regions, Indicator Selector, Chart Types */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 pb-6 border-b border-slate-100 dark:border-slate-800/80">
          {/* 1. Category Dropdown */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Tarmoq / Soha
            </label>
            <div className="relative">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full appearance-none px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-hidden focus:border-teal-500 cursor-pointer"
              >
                <option value="all">Barcha Tarmoqlar ({statistics.length})</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.slug}>
                    {c.name}
                  </option>
                ))}
              </select>
              <ChevronDown
                size={14}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
              />
            </div>
          </div>

          {/* 2. Region Dropdown */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Hudud / Viloyat
            </label>
            <div className="relative">
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="w-full appearance-none px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-hidden focus:border-teal-500 cursor-pointer"
              >
                <option value="all">Respublika (Umumiy agregat)</option>
                {REGIONS_DATA.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
              <ChevronDown
                size={14}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
              />
            </div>
          </div>

          {/* 3. Indicator Selector */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Ko'rsatkich / Ko'rik
            </label>
            <div className="relative">
              <select
                value={selectedStatId}
                onChange={(e) => setSelectedStatId(e.target.value)}
                disabled={selectedRegion !== 'all'}
                className={`w-full appearance-none px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-hidden focus:border-teal-500 cursor-pointer ${
                  selectedRegion !== 'all' ? 'opacity-60 cursor-not-allowed' : ''
                }`}
              >
                {filteredStatistics.map((stat) => (
                  <option key={stat.id} value={stat.id}>
                    {stat.title}
                  </option>
                ))}
              </select>
              <ChevronDown
                size={14}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
              />
            </div>
          </div>

          {/* 4. Chart Type Selector */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Grafik Turi
            </label>
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-950/80 rounded-xl border border-slate-200/80 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setChartType('bar')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition cursor-pointer ${
                  chartType === 'bar'
                    ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-lime-400 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Ustunli diagramma"
              >
                <BarChart3 size={14} />
                <span className="hidden sm:inline">Ustun</span>
              </button>
              <button
                type="button"
                onClick={() => setChartType('line')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition cursor-pointer ${
                  chartType === 'line'
                    ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-lime-400 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Chiziqli grafik"
              >
                <LineIcon size={14} />
                <span className="hidden sm:inline">Chiziq</span>
              </button>
              <button
                type="button"
                onClick={() => setChartType('pie')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition cursor-pointer ${
                  chartType === 'pie'
                    ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-lime-400 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Doiraviy diagramma"
              >
                <PieIcon size={14} />
                <span className="hidden sm:inline">Doira</span>
              </button>
              <button
                type="button"
                onClick={() => setChartType('area')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition cursor-pointer ${
                  chartType === 'area'
                    ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-lime-400 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Sohali diagramma"
              >
                <AreaIcon size={14} />
                <span className="hidden sm:inline">Maydon</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dynamic Data Points Toggling Section */}
        <div className="py-4 border-b border-slate-100 dark:border-slate-800/80">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Layers size={14} className="text-teal-500 dark:text-lime-400" />
                <span>Nuqtalarni boshqarish:</span>
              </span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-700 dark:text-lime-400 font-semibold">
                {activeDataPoints.length} / {rawDataSeries.length} faol
              </span>
            </div>

            {/* Quick Toggle Presets */}
            <div className="flex items-center gap-2 text-[11px]">
              <button
                type="button"
                onClick={enableAllPoints}
                className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-medium transition cursor-pointer"
              >
                Barchasini yoqish
              </button>
              <button
                type="button"
                onClick={selectRecentFive}
                className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-medium transition cursor-pointer"
              >
                So'nggi 5 ta
              </button>
              <button
                type="button"
                onClick={disableAllPoints}
                className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-medium transition cursor-pointer"
              >
                Tozalash
              </button>
            </div>
          </div>

          {/* Individual Data Point Pills with interactive toggle */}
          <div className="flex flex-wrap items-center gap-2 max-h-36 overflow-y-auto p-1 scrollbar-none">
            {rawDataSeries.map((point) => {
              const isActive = activePointsMap[point.label] !== false;
              return (
                <button
                  key={point.label}
                  type="button"
                  onClick={() => togglePoint(point.label)}
                  className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all duration-150 cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-teal-500/15 to-lime-500/20 text-teal-800 dark:text-lime-300 border border-teal-500/40 dark:border-lime-500/40 shadow-xs'
                      : 'bg-slate-100/60 dark:bg-slate-900/40 text-slate-400 dark:text-slate-600 border border-slate-200/50 dark:border-slate-800/50 line-through'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      isActive ? 'bg-teal-500 dark:bg-lime-400 animate-pulse' : 'bg-slate-400'
                    }`}
                  />
                  <span>{point.label}</span>
                  <span className="font-mono text-[10px] opacity-80">
                    ({point.value} {currentStat?.unit?.split(' ')[0] || ''})
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dynamic Metric Statistics Cards calculated strictly on ACTIVE points */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 py-4 border-b border-slate-100 dark:border-slate-800/80">
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/50 dark:border-slate-800/50">
            <span className="text-[10px] uppercase font-bold text-slate-400">Faol Nuqtalar</span>
            <p className="text-lg font-mono font-extrabold text-slate-900 dark:text-white mt-0.5">
              {statsSummary.count} ta
            </p>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/50 dark:border-slate-800/50">
            <span className="text-[10px] uppercase font-bold text-slate-400">O'rtacha Qiymat</span>
            <p className="text-lg font-mono font-extrabold text-teal-600 dark:text-teal-400 mt-0.5">
              {statsSummary.avg}
            </p>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/50 dark:border-slate-800/50">
            <span className="text-[10px] uppercase font-bold text-slate-400">Maksimal</span>
            <p className="text-lg font-mono font-extrabold text-emerald-600 dark:text-lime-400 mt-0.5">
              {statsSummary.max}
            </p>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/50 dark:border-slate-800/50">
            <span className="text-[10px] uppercase font-bold text-slate-400">Minimal</span>
            <p className="text-lg font-mono font-extrabold text-slate-700 dark:text-slate-300 mt-0.5">
              {statsSummary.min}
            </p>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/50 dark:border-slate-800/50">
            <span className="text-[10px] uppercase font-bold text-slate-400">Dinamika (O'sish)</span>
            <p
              className={`text-lg font-mono font-extrabold mt-0.5 ${
                statsSummary.growth >= 0 ? 'text-emerald-500' : 'text-rose-500'
              }`}
            >
              {statsSummary.growth > 0 ? `+${statsSummary.growth}%` : `${statsSummary.growth}%`}
            </p>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/50 dark:border-slate-800/50">
            <span className="text-[10px] uppercase font-bold text-slate-400">Umumiy Jam</span>
            <p className="text-lg font-mono font-extrabold text-slate-900 dark:text-white mt-0.5">
              {statsSummary.sum}
            </p>
          </div>
        </div>

        {/* Chart Header Bar: Title, Source, and Export Options Dropdown */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-5 pb-2">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
              {currentStat?.title || 'Dinamik Grafik'}
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Birlik: {currentStat?.unit || 'Ko\'rsatkich'} • Manba: {currentStat?.sourceName || 'Rasmiy Davlat Reestri'}
            </p>
          </div>

          {/* Export Options Dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              type="button"
              onClick={() => setExportOpen(!exportOpen)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-semibold text-xs bg-gradient-to-r from-teal-500/15 via-lime-500/15 to-emerald-500/15 hover:from-teal-500/25 hover:to-lime-500/25 text-slate-800 dark:text-lime-300 border border-teal-500/30 dark:border-lime-500/40 transition shadow-xs cursor-pointer"
            >
              {exportStatus === 'png_loading' ? (
                <div className="w-3.5 h-3.5 border-2 border-lime-400 border-t-transparent rounded-full animate-spin" />
              ) : exportStatus?.endsWith('_success') ? (
                <Check size={14} className="text-lime-400" />
              ) : (
                <Download size={14} className="text-teal-600 dark:text-lime-400" />
              )}
              <span>Export Options</span>
              <ChevronDown
                size={13}
                className={`transition-transform duration-200 text-slate-500 ${
                  exportOpen ? 'rotate-180' : ''
                }`}
              />
            </button>

            {exportOpen && (
              <div className="absolute right-0 top-full mt-1.5 z-40 w-64 rounded-2xl bg-white/95 dark:bg-[#0b172d]/95 backdrop-blur-xl border border-slate-200 dark:border-teal-500/30 shadow-2xl overflow-hidden animate-in fade-in duration-150">
                <div className="h-1 w-full bg-gradient-to-r from-teal-400 via-lime-400 to-emerald-400" />
                <div className="p-3 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                    Eksport Parametrlari
                  </span>
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {activeDataPoints.length} ta faol nuqta
                  </p>
                </div>
                <div className="p-1.5 space-y-1">
                  <button
                    type="button"
                    onClick={exportCSV}
                    className="w-full flex items-start gap-2.5 p-2 rounded-xl text-left hover:bg-slate-100 dark:hover:bg-slate-800/80 transition cursor-pointer"
                  >
                    <div className="w-8 h-8 rounded-lg bg-teal-500/15 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0">
                      <FileSpreadsheet size={16} />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-slate-900 dark:text-white flex items-center justify-between">
                        <span>CSV yuklash</span>
                        <span className="text-[10px] font-mono text-teal-600 dark:text-teal-300">.csv</span>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Jadval tahlili va Excel uchun
                      </p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={exportPNG}
                    className="w-full flex items-start gap-2.5 p-2 rounded-xl text-left hover:bg-slate-100 dark:hover:bg-slate-800/80 transition cursor-pointer"
                  >
                    <div className="w-8 h-8 rounded-lg bg-lime-500/15 text-lime-600 dark:text-lime-400 flex items-center justify-center shrink-0">
                      <ImageIcon size={16} />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-slate-900 dark:text-white flex items-center justify-between">
                        <span>PNG tasvir yuklash</span>
                        <span className="text-[10px] font-mono text-lime-600 dark:text-lime-300">.png</span>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Yuqori aniqlikdagi HD rasm
                      </p>
                    </div>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Dynamic Chart Display Container */}
        <div ref={chartRef} className="h-[380px] w-full pt-4">
          {activeDataPoints.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 text-xs">
              <Info size={24} className="mb-2 text-teal-500" />
              <span>Nuqtalar o'chirilgan. Yuqoridagi paneldan nuqtalarni yoqing.</span>
              <button
                type="button"
                onClick={enableAllPoints}
                className="mt-2 text-teal-600 dark:text-lime-400 font-semibold underline"
              >
                Barchasini yoqish
              </button>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              {chartType === 'bar' ? (
                <BarChart data={activeDataPoints} margin={{ top: 15, right: 20, left: 0, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#1e293b' : '#f1f5f9'} />
                  <XAxis
                    dataKey="label"
                    stroke={isDark ? '#64748b' : '#94a3b8'}
                    fontSize={11}
                    tickLine={false}
                    interval={0}
                    angle={activeDataPoints.length > 7 ? -30 : 0}
                    textAnchor={activeDataPoints.length > 7 ? 'end' : 'middle'}
                  />
                  <YAxis stroke={isDark ? '#64748b' : '#94a3b8'} fontSize={11} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: isDark ? '#0b172d' : '#ffffff',
                      borderColor: isDark ? '#0d9488' : '#e2e8f0',
                      borderRadius: '16px',
                      boxShadow: '0 10px 25px -5px rgba(0,0,0,0.3)',
                    }}
                    labelStyle={{ fontWeight: 'bold', color: isDark ? '#ffffff' : '#0f172a' }}
                    formatter={(val: any) => [`${val} ${currentStat?.unit || ''}`, "Qiymat"]}
                  />
                  <Bar dataKey="value" fill="#0d9488" radius={[8, 8, 0, 0]}>
                    {activeDataPoints.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={index === activeDataPoints.length - 1 ? '#a3e635' : COLORS[index % COLORS.length]}
                      />
                    ))}
                  </Bar>
                </BarChart>
              ) : chartType === 'line' ? (
                <LineChart data={activeDataPoints} margin={{ top: 15, right: 20, left: 0, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#1e293b' : '#f1f5f9'} />
                  <XAxis
                    dataKey="label"
                    stroke={isDark ? '#64748b' : '#94a3b8'}
                    fontSize={11}
                    tickLine={false}
                    angle={activeDataPoints.length > 7 ? -30 : 0}
                    textAnchor={activeDataPoints.length > 7 ? 'end' : 'middle'}
                  />
                  <YAxis stroke={isDark ? '#64748b' : '#94a3b8'} fontSize={11} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: isDark ? '#0b172d' : '#ffffff',
                      borderColor: isDark ? '#0d9488' : '#e2e8f0',
                      borderRadius: '16px',
                      boxShadow: '0 10px 25px -5px rgba(0,0,0,0.3)',
                    }}
                    labelStyle={{ fontWeight: 'bold', color: isDark ? '#ffffff' : '#0f172a' }}
                    formatter={(val: any) => [`${val} ${currentStat?.unit || ''}`, "Qiymat"]}
                  />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="#0d9488"
                    strokeWidth={3}
                    dot={{ fill: '#a3e635', stroke: '#0d9488', strokeWidth: 2, r: 5 }}
                    activeDot={{ r: 8, fill: '#a3e635' }}
                  />
                </LineChart>
              ) : chartType === 'area' ? (
                <AreaChart data={activeDataPoints} margin={{ top: 15, right: 20, left: 0, bottom: 25 }}>
                  <defs>
                    <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0d9488" stopOpacity={0.6} />
                      <stop offset="95%" stopColor="#a3e635" stopOpacity={0.05} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#1e293b' : '#f1f5f9'} />
                  <XAxis
                    dataKey="label"
                    stroke={isDark ? '#64748b' : '#94a3b8'}
                    fontSize={11}
                    tickLine={false}
                    angle={activeDataPoints.length > 7 ? -30 : 0}
                    textAnchor={activeDataPoints.length > 7 ? 'end' : 'middle'}
                  />
                  <YAxis stroke={isDark ? '#64748b' : '#94a3b8'} fontSize={11} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: isDark ? '#0b172d' : '#ffffff',
                      borderColor: isDark ? '#0d9488' : '#e2e8f0',
                      borderRadius: '16px',
                    }}
                    formatter={(val: any) => [`${val} ${currentStat?.unit || ''}`, "Qiymat"]}
                  />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="#0d9488"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#areaGradient)"
                  />
                </AreaChart>
              ) : (
                <PieChart margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: isDark ? '#0b172d' : '#ffffff',
                      borderColor: isDark ? '#0d9488' : '#e2e8f0',
                      borderRadius: '16px',
                    }}
                    formatter={(val: any) => [`${val} ${currentStat?.unit || ''}`, "Qiymat"]}
                  />
                  <Pie
                    data={activeDataPoints}
                    dataKey="value"
                    nameKey="label"
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={125}
                    paddingAngle={3}
                    label={({ name, percent }: any) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  >
                    {activeDataPoints.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                </PieChart>
              )}
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
};
