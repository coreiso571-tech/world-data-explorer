import React, { useState, useEffect } from 'react';
import { 
  X,
  User, 
  Mail, 
  GraduationCap, 
  ExternalLink, 
  Check, 
  Copy, 
  Sparkles, 
  Code2, 
  ShieldCheck, 
  Award,
  Layers,
  MapPin,
  Cpu
} from 'lucide-react';

// Custom crisp Telegram paper plane icon
const TelegramIcon: React.FC<{ className?: string; size?: number }> = ({ className = '', size = 18 }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className}
    aria-hidden="true"
  >
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.19-.08-.05-.19-.02-.27 0-.12.03-1.99 1.27-5.61 3.72-.53.36-1.01.54-1.44.53-.47-.01-1.38-.27-2.06-.49-.83-.27-1.49-.42-1.43-.88.03-.24.38-.49 1.03-.75 4.04-1.76 6.74-2.92 8.09-3.49 3.85-1.6 4.65-1.88 5.17-1.89.11 0 .37.03.54.17.14.12.18.28.2.45-.02.07-.02.21-.04.38z"/>
  </svg>
);

interface DeveloperModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DeveloperModal: React.FC<DeveloperModalProps> = ({ isOpen, onClose }) => {
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Close on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/75 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="developer-modal-title"
    >
      {/* Modal Dialog Card with Navy/Lime Glassmorphism */}
      <div 
        className="relative w-full max-w-3xl my-auto rounded-3xl bg-slate-900/95 dark:bg-[#081225]/95 border border-slate-700/70 dark:border-slate-800/80 shadow-2xl backdrop-blur-2xl text-white overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top glowing lime-to-teal strip */}
        <div className="h-1.5 w-full bg-gradient-to-r from-teal-400 via-lime-400 to-emerald-400" />

        {/* Ambient inner gradients */}
        <div className="absolute -top-24 -right-24 w-80 h-80 bg-teal-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-80 h-80 bg-lime-400/15 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Close 'X' Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-slate-800/80 hover:bg-slate-700 border border-slate-700/70 text-slate-400 hover:text-white transition shadow-md group"
          aria-label="Yopish"
          title="Yopish (Esc)"
        >
          <X size={18} className="group-hover:rotate-90 transition-transform duration-200 text-slate-300 group-hover:text-lime-400" />
        </button>

        <div className="p-5 sm:p-8 max-h-[88vh] overflow-y-auto relative z-10 custom-scrollbar">
          {/* Top row: Avatar + Identity badges */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5 pb-6 border-b border-slate-800/90 pr-8">
            <div className="flex items-center gap-4 sm:gap-5">
              {/* Visual Avatar with Lime Glow */}
              <div className="relative shrink-0">
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-lime-400 via-teal-400 to-emerald-500 p-0.5 shadow-xl shadow-lime-500/15">
                  <div className="w-full h-full rounded-2xl bg-slate-900 flex flex-col items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-900 to-teal-950/60" />
                    <span className="relative z-10 font-mono text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-lime-300 via-teal-200 to-white">
                      MA
                    </span>
                    <div className="relative z-10 flex items-center gap-1 text-[8px] sm:text-[9px] font-mono text-lime-400 font-bold uppercase tracking-widest mt-0.5">
                      <Code2 size={10} /> Dev
                    </div>
                  </div>
                </div>
                {/* Verified Founder Pip */}
                <div 
                  className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-lime-400 text-slate-950 flex items-center justify-center shadow-md ring-2 ring-slate-900 font-bold"
                  title="Rasmiy Muallif"
                >
                  <ShieldCheck size={13} />
                </div>
              </div>

              {/* Name & Title */}
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-lime-950/80 text-lime-300 border border-lime-800/60 flex items-center gap-1">
                    <Award size={11} className="text-lime-400" />
                    Platform Founder &amp; Architect
                  </span>
                </div>
                <h2 id="developer-modal-title" className="text-xl sm:text-2xl font-black text-white tracking-tight mt-1 flex items-center gap-2">
                  <span>Muhammadiso Akbarov</span>
                  <Sparkles size={16} className="text-lime-400 shrink-0" />
                </h2>
                <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs text-slate-300 mt-1 font-medium">
                  <span className="flex items-center gap-1 text-teal-300">
                    <MapPin size={12} className="text-teal-400" />
                    Toshkent, O'zbekiston
                  </span>
                  <span className="text-slate-600 hidden sm:inline">•</span>
                  <span className="flex items-center gap-1 text-slate-300">
                    <Layers size={12} className="text-lime-400" />
                    UZDATA Bosh Muhandisi
                  </span>
                </div>
              </div>
            </div>

            {/* Status Badge */}
            <div className="shrink-0">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700/60 text-xs font-semibold backdrop-blur-md">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-lime-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-lime-400"></span>
                </span>
                <span className="text-lime-300 font-mono text-[11px]">Faol / Aloqada</span>
              </div>
            </div>
          </div>

          {/* Core Required Details: 4 Profile Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 my-6">
            {/* 1. Name */}
            <div className="p-4 rounded-2xl bg-slate-800/60 hover:bg-slate-800/90 border border-slate-700/60 hover:border-lime-500/40 transition duration-200 group/item">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
                  <div className="w-6 h-6 rounded-lg bg-teal-500/15 text-teal-400 flex items-center justify-center">
                    <User size={14} />
                  </div>
                  <span className="uppercase tracking-wider font-mono text-[10px] text-slate-300">
                    To'liq Ism (Name)
                  </span>
                </div>
                <button
                  onClick={() => copyToClipboard('Muhammadiso Akbarov', 'name')}
                  className="opacity-0 group-hover/item:opacity-100 text-slate-400 hover:text-white transition p-1"
                  title="Nusxa olish"
                >
                  {copiedField === 'name' ? <Check size={13} className="text-lime-400" /> : <Copy size={13} />}
                </button>
              </div>
              <div className="text-base font-bold text-white tracking-wide font-mono mt-0.5">
                Name: Muhammadiso Akbarov
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Loyihalashtiruvchi, ma'lumotlar tahlilchisi va dasturchi
              </div>
            </div>

            {/* 2. Email */}
            <div className="p-4 rounded-2xl bg-slate-800/60 hover:bg-slate-800/90 border border-slate-700/60 hover:border-lime-500/40 transition duration-200 group/item">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
                  <div className="w-6 h-6 rounded-lg bg-lime-500/15 text-lime-400 flex items-center justify-center">
                    <Mail size={14} />
                  </div>
                  <span className="uppercase tracking-wider font-mono text-[10px] text-slate-300">
                    Elektron Pochta (Email)
                  </span>
                </div>
                <button
                  onClick={() => copyToClipboard('@coreiso571', 'email')}
                  className="opacity-0 group-hover/item:opacity-100 text-slate-400 hover:text-white transition p-1"
                  title="Nusxa olish"
                >
                  {copiedField === 'email' ? <Check size={13} className="text-lime-400" /> : <Copy size={13} />}
                </button>
              </div>
              <div className="text-base font-bold text-lime-300 tracking-wide font-mono mt-0.5">
                Email: @coreiso571
              </div>
              <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5">
                <a 
                  href="mailto:coreiso571@gmail.com" 
                  className="text-teal-400 hover:text-teal-300 underline underline-offset-2 flex items-center gap-1"
                >
                  <span>Xabar yuborish (coreiso571@gmail.com)</span>
                  <ExternalLink size={10} />
                </a>
              </div>
            </div>

            {/* 3. Education */}
            <div className="p-4 rounded-2xl bg-slate-800/60 hover:bg-slate-800/90 border border-slate-700/60 hover:border-lime-500/40 transition duration-200 group/item">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
                  <div className="w-6 h-6 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
                    <GraduationCap size={14} />
                  </div>
                  <span className="uppercase tracking-wider font-mono text-[10px] text-slate-300">
                    Ta'lim Muassasasi (Education)
                  </span>
                </div>
                <button
                  onClick={() => copyToClipboard('School of Engineering named after Mirzo Ulugbek', 'edu')}
                  className="opacity-0 group-hover/item:opacity-100 text-slate-400 hover:text-white transition p-1"
                  title="Nusxa olish"
                >
                  {copiedField === 'edu' ? <Check size={13} className="text-lime-400" /> : <Copy size={13} />}
                </button>
              </div>
              <div className="text-base font-bold text-emerald-300 tracking-tight mt-0.5">
                Education: School of Engineering named after Mirzo Ulugbek
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Dasturiy injiniring va axborot texnologiyalari ta'limi
              </div>
            </div>

            {/* 4. Telegram */}
            <div className="p-4 rounded-2xl bg-slate-800/60 hover:bg-slate-800/90 border border-slate-700/60 hover:border-lime-500/40 transition duration-200 group/item">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
                  <div className="w-6 h-6 rounded-lg bg-sky-500/15 text-sky-400 flex items-center justify-center">
                    <TelegramIcon size={14} />
                  </div>
                  <span className="uppercase tracking-wider font-mono text-[10px] text-slate-300">
                    Telegram Aloqa (Telegram)
                  </span>
                </div>
                <button
                  onClick={() => copyToClipboard('@coreiso571', 'telegram')}
                  className="opacity-0 group-hover/item:opacity-100 text-slate-400 hover:text-white transition p-1"
                  title="Nusxa olish"
                >
                  {copiedField === 'telegram' ? <Check size={13} className="text-lime-400" /> : <Copy size={13} />}
                </button>
              </div>
              <div className="text-base font-bold text-sky-300 tracking-wide font-mono mt-0.5">
                Telegram: @coreiso571
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                <a 
                  href="https://t.me/coreiso571" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-sky-400 hover:text-sky-300 underline underline-offset-2 flex items-center gap-1"
                >
                  <span>t.me/coreiso571 orqali chat ochish</span>
                  <ExternalLink size={10} />
                </a>
              </div>
            </div>
          </div>

          {/* Bottom Actions & Tech Skills Banner */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-5 border-t border-slate-800">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-mono uppercase text-slate-400 flex items-center gap-1 mr-1">
                <Cpu size={12} className="text-teal-400" /> Texnologiyalar:
              </span>
              {['React / Vite', 'TypeScript', 'Tailwind CSS', 'Firebase Cloud', 'Recharts'].map((tech) => (
                <span 
                  key={tech} 
                  className="px-2 py-0.5 rounded-lg bg-slate-800/80 text-[11px] font-mono text-slate-300 border border-slate-700/60"
                >
                  {tech}
                </span>
              ))}
            </div>

            <div className="flex items-center gap-2.5 w-full sm:w-auto">
              <a
                href="https://t.me/coreiso571"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-teal-500 to-lime-500 hover:from-teal-600 hover:to-lime-600 text-slate-950 font-bold text-xs shadow-lg shadow-lime-500/20 transition-all cursor-pointer"
              >
                <TelegramIcon size={14} />
                <span>Telegramda Bog'lanish</span>
              </a>
              <a
                href="mailto:coreiso571@gmail.com"
                className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs border border-slate-700 transition"
                title="Email orqali yozish"
              >
                <Mail size={13} className="text-lime-400" />
                <span>Email</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
