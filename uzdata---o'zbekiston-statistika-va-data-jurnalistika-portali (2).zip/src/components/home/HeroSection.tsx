import React from 'react';
import { Search, TrendingUp, ShieldCheck, Database, ArrowUpRight, Sparkles } from 'lucide-react';
import { Statistic } from '../../types';

interface HeroSectionProps {
  onOpenSearch: () => void;
  featuredStats: Statistic[];
  onSelectStat: (stat: Statistic) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenSearch,
  featuredStats,
  onSelectStat,
}) => {
  return (
    <section className="relative pt-8 pb-12 sm:pt-14 sm:pb-16 overflow-hidden">
      {/* Decorative gradient blur */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-teal-500/10 via-cyan-500/10 to-indigo-500/10 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-4xl mx-auto text-center mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/5 dark:bg-slate-100/10 border border-slate-200/80 dark:border-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 mb-6">
          <span className="w-2 h-2 rounded-full bg-teal-500 animate-pulse"></span>
          <span>O'zbekiston Milliy Ma'lumotlar & Tahliliy Statistika Portali</span>
        </div>

        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-950 dark:text-white tracking-tight leading-[1.15] mb-6">
          O'zbekiston raqamlarda: <br className="hidden sm:inline" />
          <span className="bg-gradient-to-r from-teal-600 via-teal-500 to-cyan-500 bg-clip-text text-transparent">
            Ma'lumotlarga asoslangan
          </span>{' '}
          haqiqat.
        </h1>

        <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed mb-8">
          Rasmiy davlat reestrlari, Markaziy Bank va xalqaro moliya institutlarining tasdiqlangan statistikasi. Data jurnalistika va chuqur dinamik tahlillar.
        </p>

        {/* Global Search Bar in Hero */}
        <div className="max-w-xl mx-auto">
          <div
            onClick={onOpenSearch}
            className="flex items-center justify-between px-5 py-3.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 hover:border-teal-500 dark:hover:border-teal-400 rounded-2xl shadow-lg shadow-slate-200/50 dark:shadow-none cursor-pointer transition-all duration-200 group"
          >
            <div className="flex items-center gap-3 text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300">
              <Search size={18} className="text-teal-600 dark:text-teal-400" />
              <span className="text-sm font-medium">
                Ko'rsatkich, soha yoki viloyat nomini kiriting...
              </span>
            </div>
            <kbd className="hidden sm:inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-mono font-medium text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
              ⌘K
            </kbd>
          </div>

          {/* Quick tags */}
          <div className="flex items-center justify-center gap-2 mt-3 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
            <span className="font-semibold text-slate-400">Ommabop:</span>
            {['YaIM hajmi', 'Aholi soni', 'IT eksport', 'Inflyatsiya', 'O\'rtacha oylik'].map((tag) => (
              <button
                key={tag}
                onClick={onOpenSearch}
                className="hover:text-teal-600 dark:hover:text-teal-400 transition underline underline-offset-2 decoration-slate-300 dark:decoration-slate-700"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 4 Key Featured Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 max-w-6xl mx-auto mt-6">
        {featuredStats.slice(0, 4).map((stat) => (
          <div
            key={stat.id}
            onClick={() => onSelectStat(stat)}
            className="group relative bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs hover:shadow-lg hover:border-teal-500/60 transition-all duration-200 cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
                <span className="uppercase tracking-wider font-semibold text-[10px] truncate max-w-[120px]">
                  {stat.category}
                </span>
                <ArrowUpRight
                  size={15}
                  className="text-slate-400 group-hover:text-teal-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform"
                />
              </div>

              <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white line-clamp-1 mb-2">
                {stat.title}
              </h3>

              <div className="text-2xl sm:text-3xl font-extrabold font-mono text-slate-950 dark:text-white tracking-tight mb-1">
                {stat.value}
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800/80 mt-2 text-[11px]">
              <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                {stat.change || 'Barqaror'}
              </span>
              <span className="text-slate-400 font-mono text-[10px]">{stat.unit}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Trust banner */}
      <div className="flex items-center justify-center gap-6 mt-10 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
        <span className="flex items-center gap-1.5">
          <ShieldCheck size={14} className="text-teal-600" />
          Davlat Reyestri Tekshiruvi
        </span>
        <span>•</span>
        <span className="flex items-center gap-1.5">
          <Database size={14} className="text-teal-600" />
          Ochiq Ma'lumotlar Standarti
        </span>
        <span>•</span>
        <span className="flex items-center gap-1.5">
          <Sparkles size={14} className="text-teal-600" />
          Kunlik Yangilanish
        </span>
      </div>
    </section>
  );
};
