import React, { useState } from 'react';
import {
  TrendingUp,
  Eye,
  Flame,
  Sparkles,
  Clock,
  ArrowRight,
  Bookmark,
  Award,
  ChevronRight
} from 'lucide-react';
import { Statistic, Article } from '../../types';
import { userService } from '../../services/userService';

interface TrendingRankingsSectionProps {
  statistics: Statistic[];
  articles: Article[];
  onSelectStat: (stat: Statistic) => void;
  onSelectArticle: (article: Article) => void;
}

export const TrendingRankingsSection: React.FC<TrendingRankingsSectionProps> = ({
  statistics,
  articles,
  onSelectStat,
  onSelectArticle,
}) => {
  const [activeTab, setActiveTab] = useState<'viewed' | 'popular' | 'new'>('viewed');

  // Most Viewed items mock enriched with real items
  const mostViewed = [
    {
      id: 'stat-aholi-soni',
      title: "O'zbekiston Doimiy Aholisi Soni",
      value: '37.6 mln',
      unit: 'mln kishi',
      category: 'demografiya',
      views: '184.2 ming',
      change: '+2.1%',
      type: 'stat' as const,
    },
    {
      id: 'stat-yaim-hajmi',
      title: 'Yalpi Ichki Mahsulot (YaIM)',
      value: '$112.5 mlrd',
      unit: 'mlrd dollar',
      category: 'iqtisodiyot',
      views: '142.8 ming',
      change: '+6.4%',
      type: 'stat' as const,
    },
    {
      id: 'stat-ortacha-oylik-ish-haqi',
      title: "O'rtacha Oylik Nominal Ish Haqi",
      value: "5.45 mln so'm",
      unit: "so'm",
      category: 'iqtisodiyot',
      views: '129.5 ming',
      change: '+17.2%',
      type: 'stat' as const,
    },
    {
      id: 'stat-it-eksport',
      title: 'IT Xizmatlar Eksporti Hajmi',
      value: '$550 mln',
      unit: 'mln dollar',
      category: 'it-biznes',
      views: '115.1 ming',
      change: '+38%',
      type: 'stat' as const,
    },
    {
      id: 'art-it-eksporti-yol',
      title: "O'zbekiston IT-xizmatlari eksporti: $550 mln tahlili",
      value: 'Tahliliy maqola',
      unit: '6 daqiqa',
      category: 'it-biznes',
      views: '94.3 ming',
      type: 'article' as const,
    },
  ];

  // Popular items
  const popular = [
    {
      id: 'stat-it-eksport',
      title: 'IT Xizmatlar Eksporti Hajmi',
      value: '$550 mln',
      unit: 'mln dollar',
      category: 'it-biznes',
      popularity: '98% qiziqish',
      change: '+38% yillik',
      type: 'stat' as const,
    },
    {
      id: 'stat-sayyohlar-oqimi',
      title: "O'zbekistonga Tashrif Buyurgan Xorijiy Sayyohlar",
      value: '7.8 mln',
      unit: 'sayyoh',
      category: 'turizm',
      popularity: '94% qiziqish',
      change: '+18.2%',
      type: 'stat' as const,
    },
    {
      id: 'stat-inflyatsiya',
      title: "Yillik Inflyatsiya Ko'rsatkichi",
      value: '8.4%',
      unit: '%',
      category: 'narxlar',
      popularity: '91% qiziqish',
      change: '-0.4% pasayish',
      type: 'stat' as const,
    },
    {
      id: 'art-urbanizatsiya-va-aglomeratsiya',
      title: "Urbanizatsiya va Toshkent: Poytaxt aglomeratsiyasi",
      value: 'Tahliliy maqola',
      unit: '4 daqiqa',
      category: 'hududlar',
      popularity: '88% qiziqish',
      type: 'article' as const,
    },
    {
      id: 'stat-talim-qamrovi',
      title: "Oliy Ta'lim Qamrovi Darajasi",
      value: '42.5%',
      unit: '%',
      category: 'talim',
      popularity: '85% qiziqish',
      change: '+4.7x',
      type: 'stat' as const,
    },
  ];

  // Newly Added items
  const newlyAdded = [
    {
      id: 'stat-hududlar-yaim-ulushi',
      title: "YaIM Shakllanishida Hududlarning Salmog'i",
      value: '14 ta hudud',
      unit: 'ulush %',
      category: 'hududlar',
      addedDate: '2026-10-18',
      type: 'stat' as const,
    },
    {
      id: 'stat-ortacha-oylik-ish-haqi',
      title: "O'rtacha Oylik Nominal Ish Haqi (2026 Yangilanishi)",
      value: "5.45 mln so'm",
      unit: "so'm",
      category: 'iqtisodiyot',
      addedDate: '2026-10-16',
      type: 'stat' as const,
    },
    {
      id: 'art-urbanizatsiya-va-aglomeratsiya',
      title: "Urbanizatsiya va Toshkent Aglomeratsiyasi",
      value: 'Maxsus hisobot',
      unit: 'Data Jurnalistika',
      category: 'hududlar',
      addedDate: '2026-10-17',
      type: 'article' as const,
    },
    {
      id: 'stat-sayyohlar-oqimi',
      title: "Sayyohlar Oqimi Yillik Hisoboti",
      value: '7.8 mln',
      unit: 'nafar',
      category: 'turizm',
      addedDate: '2026-10-15',
      type: 'stat' as const,
    },
  ];

  const handleClickItem = (item: any) => {
    if (item.type === 'stat') {
      const found = statistics.find((s) => s.id === item.id || s.slug === item.id);
      if (found) onSelectStat(found);
    } else {
      const found = articles.find((a) => a.id === item.id || a.slug === item.id);
      if (found) onSelectArticle(found);
    }
  };

  const handleToggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    userService.toggleBookmark(id);
  };

  return (
    <section className="my-14">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 text-xs font-semibold uppercase tracking-wider mb-2 border border-amber-500/20">
            <Flame size={13} className="text-amber-500" />
            <span>Trendlar & Milliy Reytinglar</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Eng Ommabop va Qiziqarli Ma'lumotlar
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Foydalanuvchilar tomonidan eng ko'p o'qilayotgan, izlanayotgan va yangi joylangan materiallar.
          </p>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('viewed')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl transition cursor-pointer ${
              activeTab === 'viewed'
                ? 'bg-white dark:bg-slate-800 text-teal-700 dark:text-lime-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Eye size={13} />
            <span>Eng ko'p ko'rilgan</span>
          </button>
          <button
            onClick={() => setActiveTab('popular')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl transition cursor-pointer ${
              activeTab === 'popular'
                ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Flame size={13} />
            <span>Ommabop</span>
          </button>
          <button
            onClick={() => setActiveTab('new')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl transition cursor-pointer ${
              activeTab === 'new'
                ? 'bg-white dark:bg-slate-800 text-sky-600 dark:text-sky-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Sparkles size={13} />
            <span>Yangi qo'shilgan</span>
          </button>
        </div>
      </div>

      {/* Rankings List Container */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {(activeTab === 'viewed' ? mostViewed : activeTab === 'popular' ? popular : newlyAdded).map(
          (item: any, idx: number) => {
            const isBookmarked = userService.isBookmarked(item.id);
            const rankMedals = ['🥇', '🥈', '🥉'];

            return (
              <div
                key={item.id + idx}
                onClick={() => handleClickItem(item)}
                className="group p-4 sm:p-5 rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800/80 hover:border-teal-500/50 dark:hover:border-lime-500/40 shadow-xs hover:shadow-xl transition-all duration-200 cursor-pointer flex flex-col justify-between"
              >
                <div>
                  {/* Top Bar: Ranking badge & Category */}
                  <div className="flex items-center justify-between gap-2 mb-2.5">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-slate-100 dark:bg-slate-800 font-mono font-bold text-xs flex items-center justify-center text-slate-700 dark:text-slate-300">
                        {rankMedals[idx] || `#${idx + 1}`}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-lime-300">
                        {item.category}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => handleToggleBookmark(item.id, e)}
                      className="p-1 rounded-md text-slate-400 hover:text-amber-500 transition cursor-pointer"
                      title={isBookmarked ? "Saqlangan" : "Saqlash"}
                    >
                      <Bookmark size={14} className={isBookmarked ? "fill-amber-400 text-amber-400" : ""} />
                    </button>
                  </div>

                  {/* Title */}
                  <h3 className="font-bold text-slate-900 dark:text-white text-xs sm:text-sm line-clamp-2 group-hover:text-teal-600 dark:group-hover:text-lime-400 transition leading-snug">
                    {item.title}
                  </h3>

                  {/* Value */}
                  <div className="text-xl sm:text-2xl font-black font-mono text-slate-950 dark:text-white mt-2">
                    {item.value}
                  </div>
                </div>

                {/* Footer details */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 mt-3">
                  <div className="flex items-center gap-2">
                    {item.views && (
                      <span className="flex items-center gap-1 font-mono text-slate-500 dark:text-slate-400">
                        <Eye size={12} />
                        {item.views}
                      </span>
                    )}
                    {item.popularity && (
                      <span className="text-amber-500 font-semibold">{item.popularity}</span>
                    )}
                    {item.addedDate && (
                      <span className="flex items-center gap-1">
                        <Clock size={11} />
                        {item.addedDate}
                      </span>
                    )}
                  </div>

                  <span className="text-teal-600 dark:text-lime-400 font-bold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                    Ochish <ChevronRight size={13} />
                  </span>
                </div>
              </div>
            );
          }
        )}
      </div>
    </section>
  );
};
