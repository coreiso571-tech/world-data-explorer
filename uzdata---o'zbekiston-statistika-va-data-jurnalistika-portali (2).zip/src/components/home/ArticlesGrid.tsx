import React from 'react';
import { Clock, ArrowRight, BookOpen } from 'lucide-react';
import { Article } from '../../types';
import { ArticleSkeleton } from '../common/SkeletonLoader';

interface ArticlesGridProps {
  articles: Article[];
  onSelectArticle: (article: Article) => void;
  loading?: boolean;
}

export const ArticlesGrid: React.FC<ArticlesGridProps> = ({
  articles,
  onSelectArticle,
  loading = false,
}) => {
  return (
    <section id="maqolalar" className="my-16">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <BookOpen size={13} />
            Data Jurnalistika
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Tahliliy Maqolalar va Maxsus Hisobotlar
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Raqamlar ortidagi tendensiyalar: chuqur tahlillar, ekspert xulosalari va vizual hikoyalar.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <ArticleSkeleton />
          <ArticleSkeleton />
          <ArticleSkeleton />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((article) => (
            <div
              key={article.id}
              onClick={() => onSelectArticle(article)}
              className="group bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs hover:shadow-xl hover:border-teal-500/50 transition-all duration-300 cursor-pointer flex flex-col justify-between"
            >
              <div>
                {article.imageUrl ? (
                  <div className="h-48 w-full overflow-hidden bg-slate-100 dark:bg-slate-800 relative">
                    <img
                      src={article.imageUrl}
                      alt={article.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-3 left-3">
                      <span className="px-2.5 py-1 text-[11px] font-bold uppercase rounded-md bg-slate-900/80 backdrop-blur-md text-white">
                        {article.category}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="p-5 pb-0">
                    <span className="px-2.5 py-1 text-[11px] font-bold uppercase rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300">
                      {article.category}
                    </span>
                  </div>
                )}

                <div className="p-5">
                  <div className="flex items-center gap-3 text-xs text-slate-400 mb-2">
                    <span className="flex items-center gap-1">
                      <Clock size={12} />
                      {article.readingTime}
                    </span>
                    <span>•</span>
                    <span>{article.author}</span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors line-clamp-2 leading-snug mb-3">
                    {article.title}
                  </h3>

                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-3 leading-relaxed mb-4">
                    {article.excerpt}
                  </p>
                </div>
              </div>

              <div className="p-5 pt-0 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs font-semibold text-teal-600 dark:text-teal-400 pt-3">
                <span className="group-hover:underline">To'liq o'qish</span>
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
