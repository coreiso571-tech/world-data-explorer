import React, { useState, useEffect } from 'react';
import { 
  Moon, 
  Sun, 
  Sunrise, 
  SunMedium, 
  SunDim, 
  Sunset, 
  Clock, 
  MapPin, 
  RefreshCw, 
  Sparkles, 
  CheckCircle2, 
  Timer,
  ChevronDown,
  Calendar,
  Volume2,
  VolumeX,
  Compass
} from 'lucide-react';
import { 
  essentialsService, 
  PrayerTimesData, 
  PrayerRegion, 
  UZBEKISTAN_PRAYER_REGIONS,
  PrayerTimeItem
} from '../../services/essentialsService';

interface PrayerTimesCardProps {
  initialRegionId?: string;
  className?: string;
}

export const PrayerTimesCard: React.FC<PrayerTimesCardProps> = ({ 
  initialRegionId = 'Tashkent',
  className = ''
}) => {
  const [selectedRegion, setSelectedRegion] = useState<PrayerRegion>(() => {
    return UZBEKISTAN_PRAYER_REGIONS.find((r) => r.id === initialRegionId) || UZBEKISTAN_PRAYER_REGIONS[0];
  });

  const [prayerData, setPrayerData] = useState<PrayerTimesData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [dropdownOpen, setDropdownOpen] = useState(false);

  // Live clock ticker (every second)
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Fetch prayer data whenever selected region changes
  const loadData = async (regionId: string) => {
    setLoading(true);
    try {
      const data = await essentialsService.fetchPrayerTimes(regionId);
      setPrayerData(data);
    } catch (err) {
      console.error('Error fetching prayer times:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData(selectedRegion.id);
  }, [selectedRegion]);

  // Recalculate which prayer is next every minute
  const currentMinutes = currentTime.getHours() * 60 + currentTime.getMinutes();

  // Helper to get Lucide icon and color styling for each prayer
  const getPrayerIconAndStyle = (id: string, isNext: boolean) => {
    switch (id) {
      case 'fajr':
        return {
          icon: <Sunrise size={18} className={isNext ? 'text-teal-400 animate-pulse' : 'text-teal-500/80'} />,
          gradient: 'from-cyan-500/10 to-teal-500/5',
        };
      case 'sunrise':
        return {
          icon: <Sun size={18} className={isNext ? 'text-amber-400' : 'text-amber-500/80'} />,
          gradient: 'from-amber-500/10 to-yellow-500/5',
        };
      case 'dhuhr':
        return {
          icon: <SunMedium size={18} className={isNext ? 'text-lime-400 animate-pulse' : 'text-lime-500/80'} />,
          gradient: 'from-lime-500/10 to-emerald-500/5',
        };
      case 'asr':
        return {
          icon: <SunDim size={18} className={isNext ? 'text-amber-400 animate-pulse' : 'text-amber-500/80'} />,
          gradient: 'from-amber-500/10 to-orange-500/5',
        };
      case 'maghrib':
        return {
          icon: <Sunset size={18} className={isNext ? 'text-rose-400 animate-pulse' : 'text-rose-500/80'} />,
          gradient: 'from-rose-500/10 to-orange-500/5',
        };
      case 'isha':
        return {
          icon: <Moon size={18} className={isNext ? 'text-indigo-400 animate-pulse' : 'text-indigo-400/80'} />,
          gradient: 'from-indigo-500/10 to-teal-500/5',
        };
      default:
        return {
          icon: <Clock size={18} className="text-teal-400" />,
          gradient: 'from-teal-500/10 to-transparent',
        };
    }
  };

  // Live calculation of next prayer from items
  const evaluatedItems: PrayerTimeItem[] = (prayerData?.items || []).map((item) => {
    const [h, m] = item.time.split(':').map(Number);
    const itemMinutes = h * 60 + m;
    const isPassed = itemMinutes <= currentMinutes;
    return {
      ...item,
      isPassed,
    };
  });

  // Determine which is next
  let activeNextId: string | null = null;
  let remainingText = '';

  for (const item of evaluatedItems) {
    if (item.id === 'sunrise') continue; // typically sunrise is reference
    const [h, m] = item.time.split(':').map(Number);
    const itemMinutes = h * 60 + m;
    if (itemMinutes > currentMinutes) {
      activeNextId = item.id;
      const diffMin = itemMinutes - currentMinutes;
      const hours = Math.floor(diffMin / 60);
      const mins = diffMin % 60;
      remainingText = hours > 0 ? `${hours} soat ${mins} daqiqa qoldi` : `${mins} daqiqa qoldi`;
      break;
    }
  }

  // If past Xufton, next is tomorrow's Bomdod
  if (!activeNextId && evaluatedItems.length > 0) {
    const fajr = evaluatedItems.find((i) => i.id === 'fajr');
    if (fajr) {
      activeNextId = 'fajr';
      const [h, m] = fajr.time.split(':').map(Number);
      const diffMin = (24 * 60 - currentMinutes) + (h * 60 + m);
      const hours = Math.floor(diffMin / 60);
      const mins = diffMin % 60;
      remainingText = hours > 0 ? `${hours} soat ${mins} daqiqa qoldi` : `${mins} daqiqa qoldi`;
    }
  }

  const activeNextItem = evaluatedItems.find((i) => i.id === activeNextId);

  return (
    <div className={`relative bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 text-white border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl overflow-hidden flex flex-col justify-between backdrop-blur-md ${className}`}>
      {/* Decorative ambient backdrop */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-lime-500/5 rounded-full blur-3xl pointer-events-none" />

      <div>
        {/* Header: Title, Live Clock, and Region Dropdown */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-4 border-b border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/10 border border-teal-500/30 text-teal-400 flex items-center justify-center font-bold shadow-inner">
              <Moon size={20} className="text-teal-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-white tracking-tight">
                  Namoz Vaqtlari
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 flex items-center gap-1 font-mono">
                  <span className="relative flex h-1.5 w-1.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-teal-500" />
                  </span>
                  <span>Jonli</span>
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                {prayerData?.hijriDate || 'Hijriy sana'} • {currentTime.toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </p>
            </div>
          </div>

          {/* Region Dropdown Menu */}
          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center justify-between gap-2 px-3.5 py-2 bg-slate-800/90 hover:bg-slate-800 border border-slate-700/80 hover:border-teal-500/50 rounded-xl text-xs font-semibold text-slate-200 shadow-sm transition w-full sm:w-auto cursor-pointer"
              title="Hududni tanlash"
            >
              <div className="flex items-center gap-1.5 truncate">
                <MapPin size={14} className="text-teal-400 shrink-0" />
                <span className="truncate">{selectedRegion.name}</span>
              </div>
              <ChevronDown size={14} className={`text-slate-400 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {/* Custom Dropdown Modal Menu */}
            {dropdownOpen && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setDropdownOpen(false)} 
                />
                <div className="absolute right-0 mt-2 w-64 max-h-72 overflow-y-auto bg-slate-900/95 border border-slate-700 rounded-2xl shadow-2xl p-1.5 z-50 backdrop-blur-xl divide-y divide-slate-800/50">
                  <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-teal-400">
                    O'zbekiston Hududlari (14)
                  </div>
                  <div className="py-1">
                    {UZBEKISTAN_PRAYER_REGIONS.map((region) => {
                      const isSelected = selectedRegion.id === region.id;
                      return (
                        <button
                          key={region.id}
                          onClick={() => {
                            setSelectedRegion(region);
                            setDropdownOpen(false);
                          }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium transition flex items-center justify-between cursor-pointer ${
                            isSelected
                              ? 'bg-teal-500/20 text-teal-300 font-bold border border-teal-500/40'
                              : 'text-slate-300 hover:bg-slate-800/70 hover:text-white'
                          }`}
                        >
                          <div>
                            <p>{region.name}</p>
                            <p className="text-[10px] text-slate-500">{region.region}</p>
                          </div>
                          {isSelected && <CheckCircle2 size={14} className="text-teal-400" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Dynamic Next Prayer Countdown Highlight Banner */}
        {activeNextItem && (
          <div className="mb-4 p-3.5 rounded-2xl bg-gradient-to-r from-teal-500/20 via-teal-900/30 to-emerald-900/20 border border-teal-500/40 shadow-lg flex items-center justify-between text-xs relative overflow-hidden group">
            <div className="flex items-center gap-2.5">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-80" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-teal-400 shadow-md" />
              </span>
              <div>
                <p className="font-extrabold text-white text-xs tracking-wide">
                  Navbatdagi namoz: <span className="text-teal-300 uppercase tracking-wider font-mono">{activeNextItem.name}</span>
                </p>
                <p className="text-[11px] text-teal-200/80 font-mono mt-0.5">
                  {remainingText ? `⏳ ${remainingText}` : activeNextItem.periodName}
                </p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xl font-black font-mono text-teal-300 tracking-tight drop-shadow-sm">
                {activeNextItem.time}
              </span>
            </div>
          </div>
        )}

        {/* Prayer Times Grid */}
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 py-2 animate-pulse">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-24 bg-slate-800/60 rounded-2xl border border-slate-700/40" />
            ))}
          </div>
        ) : prayerData ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {evaluatedItems.map((item) => {
              const isNext = item.id === activeNextId;
              const { icon, gradient } = getPrayerIconAndStyle(item.id, isNext);

              return (
                <div
                  key={item.id}
                  className={`relative p-3 rounded-2xl border transition-all duration-300 flex flex-col justify-between overflow-hidden ${
                    isNext
                      ? 'bg-gradient-to-b from-teal-500/25 via-teal-900/40 to-slate-900 border-teal-400 shadow-[0_0_20px_rgba(20,184,166,0.35)] scale-[1.02] ring-1 ring-teal-400/50'
                      : item.isPassed
                      ? 'bg-slate-800/40 border-slate-800/70 text-slate-400 opacity-75 hover:opacity-100'
                      : 'bg-slate-800/60 border-slate-700/60 hover:border-slate-600'
                  }`}
                >
                  {/* Subtle top indicator for next prayer */}
                  {isNext && (
                    <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-teal-400 via-lime-400 to-teal-400 animate-pulse" />
                  )}

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="p-1.5 rounded-xl bg-slate-900/70 border border-slate-700/60 shadow-inner">
                        {icon}
                      </div>
                      <span className="text-[10px] font-mono text-slate-400 opacity-60">
                        {item.arabicName}
                      </span>
                    </div>

                    <p className={`text-xs font-bold leading-tight ${isNext ? 'text-teal-200 font-extrabold' : 'text-slate-200'}`}>
                      {item.name}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate">
                      {item.periodName}
                    </p>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-800 flex items-baseline justify-between">
                    <span className={`text-base font-black font-mono tracking-tight ${isNext ? 'text-teal-300 text-lg' : 'text-white'}`}>
                      {item.time}
                    </span>
                    {isNext ? (
                      <span className="text-[9px] font-bold uppercase tracking-wider text-teal-400 bg-teal-950/80 px-1.5 py-0.5 rounded border border-teal-500/40">
                        Kutilmoqda
                      </span>
                    ) : item.isPassed ? (
                      <span className="text-[9px] text-slate-500 flex items-center gap-0.5">
                        <CheckCircle2 size={10} className="text-slate-600" />
                        <span>O'tdi</span>
                      </span>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>
        ) : null}
      </div>

      {/* Card Footer: Source attribution and methodology note */}
      <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-[10px] text-slate-400">
        <div className="flex items-center gap-1.5">
          <Compass size={12} className="text-teal-400" />
          <span>O'zbekiston Musulmonlari Idorasi va Aladhan hisob-kitob uslubi</span>
        </div>
        <div className="flex items-center gap-2">
          <span>{selectedRegion.name} ({selectedRegion.region})</span>
          <span>•</span>
          <button
            onClick={() => loadData(selectedRegion.id)}
            disabled={loading}
            className="text-teal-400 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw size={11} className={loading ? 'animate-spin' : ''} />
            <span>Yangilash</span>
          </button>
        </div>
      </div>
    </div>
  );
};
