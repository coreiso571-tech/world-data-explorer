import React, { useState, useEffect } from 'react';
import { 
  Coins, 
  ArrowUpRight, 
  ArrowDownRight, 
  Clock, 
  Wind, 
  RefreshCw, 
  MapPin, 
  Sparkles, 
  ShieldCheck, 
  AlertCircle,
  Calculator,
  Compass,
  HeartPulse,
  Sun,
  Moon,
  ChevronRight
} from 'lucide-react';
import { 
  essentialsService, 
  CurrencyData, 
  AirQualityData 
} from '../../services/essentialsService';
import { PrayerTimesCard } from './PrayerTimesCard';

const CITIES = [
  { id: 'Tashkent', name: 'Toshkent shahri', lat: 41.2995, lon: 69.2401 },
  { id: 'Samarkand', name: 'Samarqand', lat: 39.6542, lon: 66.9597 },
  { id: 'Bukhara', name: 'Buxoro', lat: 39.7747, lon: 64.4286 },
  { id: 'Andijan', name: 'Andijon', lat: 40.7821, lon: 72.3442 },
  { id: 'Namangan', name: 'Namangan', lat: 40.9983, lon: 71.6726 },
  { id: 'Fergana', name: "Farg'ona", lat: 40.3842, lon: 71.7843 },
  { id: 'Qarshi', name: 'Qarshi', lat: 38.8606, lon: 65.7891 },
  { id: 'Nukus', name: 'Nukus', lat: 42.4619, lon: 59.6166 },
];

export const DailyEssentials: React.FC = () => {
  // Data states
  const [currency, setCurrency] = useState<CurrencyData | null>(null);
  const [aqi, setAqi] = useState<AirQualityData | null>(null);

  // Loading & refresh states
  const [loadingCurrency, setLoadingCurrency] = useState(true);
  const [loadingAqi, setLoadingAqi] = useState(true);

  // Selected city for AQI
  const [selectedCity, setSelectedCity] = useState(CITIES[0]);

  // Interactive currency calculator state
  const [calcAmount, setCalcAmount] = useState<number>(100);
  const [calcCurrency, setCalcCurrency] = useState<'USD' | 'EUR' | 'RUB'>('USD');
  const [showConverter, setShowConverter] = useState(false);

  // Fetch Currency
  const loadCurrency = async () => {
    setLoadingCurrency(true);
    try {
      const data = await essentialsService.fetchCurrencyRates();
      setCurrency(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingCurrency(false);
    }
  };

  // Fetch Air Quality
  const loadAqi = async (lat: number, lon: number, cityName: string) => {
    setLoadingAqi(true);
    try {
      const data = await essentialsService.fetchAirQuality(lat, lon, cityName);
      setAqi(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingAqi(false);
    }
  };

  useEffect(() => {
    loadCurrency();
  }, []);

  useEffect(() => {
    loadAqi(selectedCity.lat, selectedCity.lon, selectedCity.name);
  }, [selectedCity]);

  // Calculated converted UZS
  const activeRateObj = currency?.rates.find((r) => r.code === calcCurrency);
  const convertedUZS = activeRateObj ? Math.round(calcAmount * activeRateObj.rate) : 0;

  return (
    <section id="daily-essentials" className="my-8">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 text-xs font-semibold uppercase tracking-wider mb-1.5">
            <Sparkles size={13} className="text-teal-500" />
            <span>Kundalik Muhim Ma'lumotlar (Daily Essentials)</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            Valyuta, Namoz Vaqtlari va Havo Sifati
          </h2>
        </div>

        {/* Global city quick select */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400 hidden sm:inline">Hudud:</span>
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs font-semibold text-slate-800 dark:text-slate-200">
            <MapPin size={14} className="text-teal-600 dark:text-teal-400" />
            <select
              aria-label="Hududni tanlang"
              value={selectedCity.id}
              onChange={(e) => {
                const found = CITIES.find((c) => c.id === e.target.value);
                if (found) setSelectedCity(found);
              }}
              className="bg-transparent text-slate-900 dark:text-white font-bold cursor-pointer focus:outline-hidden"
            >
              {CITIES.map((c) => (
                <option key={c.id} value={c.id} className="dark:bg-slate-900 text-slate-900 dark:text-white">
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* 3 Interactive Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* CARD 1: VALYUTA KURSLARI (CURRENCY RATES) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xs flex flex-col justify-between relative overflow-hidden transition-all duration-200 hover:border-teal-500/50">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                  <Coins size={18} />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">Valyuta Kurslari</h3>
                  <p className="text-[10px] text-slate-400 font-mono">MB rasmiy kursi (UZS)</p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setShowConverter(!showConverter)}
                  className={`p-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1 ${
                    showConverter 
                      ? 'bg-teal-600 text-white' 
                      : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                  title="Valyuta konvertori"
                >
                  <Calculator size={14} />
                  <span className="hidden sm:inline text-[11px]">Kalkulyator</span>
                </button>
                <button
                  onClick={loadCurrency}
                  disabled={loadingCurrency}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                  title="Yangilash"
                >
                  <RefreshCw size={13} className={loadingCurrency ? 'animate-spin text-teal-500' : ''} />
                </button>
              </div>
            </div>

            {/* Currency Rates List */}
            {loadingCurrency ? (
              <div className="space-y-3 py-2 animate-pulse">
                <div className="h-12 bg-slate-100 dark:bg-slate-800/60 rounded-xl" />
                <div className="h-12 bg-slate-100 dark:bg-slate-800/60 rounded-xl" />
                <div className="h-12 bg-slate-100 dark:bg-slate-800/60 rounded-xl" />
              </div>
            ) : currency ? (
              <div className="space-y-2.5">
                {currency.rates.map((rate) => (
                  <div
                    key={rate.code}
                    className="p-3 rounded-2xl bg-slate-50/70 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800/80 flex items-center justify-between transition hover:border-slate-300 dark:hover:border-slate-700"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex items-center justify-center font-bold text-xs font-mono text-slate-900 dark:text-white shadow-xs">
                        {rate.symbol}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-extrabold text-xs text-slate-900 dark:text-white font-mono">
                            1 {rate.code}
                          </span>
                          <span className="text-[10px] text-slate-400 hidden sm:inline">({rate.name})</span>
                        </div>
                        <p className="text-[10px] text-slate-400 font-mono">O'zbekiston so'miga</p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-extrabold font-mono text-slate-900 dark:text-white block">
                        {rate.rateFormatted}
                      </span>
                      {rate.diffFormatted && (
                        <span
                          className={`inline-flex items-center text-[10px] font-semibold font-mono ${
                            rate.isPositive
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-rose-500 dark:text-rose-400'
                          }`}
                        >
                          {rate.isPositive ? <ArrowUpRight size={11} /> : <ArrowDownRight size={11} />}
                          {rate.diffFormatted} so'm
                        </span>
                      )}
                    </div>
                  </div>
                ))}

                {/* Interactive Currency Converter Modal/Drawer inside card */}
                {showConverter && (
                  <div className="mt-3 p-3.5 rounded-2xl bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200/80 dark:border-teal-900/60 animate-in fade-in duration-150">
                    <p className="text-[11px] font-bold text-teal-900 dark:text-teal-200 mb-2 flex items-center justify-between">
                      <span>Tezkor hisob-kitob (Kalkulyator)</span>
                      <span className="font-mono text-[10px] text-teal-600 dark:text-teal-400">Jonli kurs</span>
                    </p>
                    <div className="flex items-center gap-2 mb-2">
                      <input
                        type="number"
                        min="1"
                        value={calcAmount}
                        onChange={(e) => setCalcAmount(Math.max(0, Number(e.target.value)))}
                        className="w-24 px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-teal-300 dark:border-teal-800 rounded-xl text-xs font-mono font-bold text-slate-900 dark:text-white"
                      />
                      <select
                        aria-label="Valyutani tanlang"
                        value={calcCurrency}
                        onChange={(e) => setCalcCurrency(e.target.value as any)}
                        className="px-2 py-1.5 bg-white dark:bg-slate-900 border border-teal-300 dark:border-teal-800 rounded-xl text-xs font-bold text-slate-900 dark:text-white"
                      >
                        <option value="USD">USD ($)</option>
                        <option value="EUR">EUR (€)</option>
                        <option value="RUB">RUB (₽)</option>
                      </select>
                      <span className="text-slate-400 font-bold">=</span>
                      <div className="flex-1 text-right font-mono font-black text-sm text-teal-700 dark:text-teal-300 truncate">
                        {convertedUZS.toLocaleString('uz-UZ')} <span className="text-[10px] font-normal">so'm</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : null}
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 mt-4 flex items-center justify-between text-[10px] text-slate-400">
            <span>Manba: Markaziy Bank (cbu.uz)</span>
            <span>{currency?.date || 'Bugun'}</span>
          </div>
        </div>

        {/* CARD 2: NAMOZ VAQTLARI (UPGRADED PRAYER TIMES WIDGET) */}
        <PrayerTimesCard initialRegionId={selectedCity.id} />

        {/* CARD 3: HAVO SIFATI (AIR QUALITY INDEX - AQI) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xs flex flex-col justify-between relative overflow-hidden transition-all duration-200 hover:border-teal-500/50">
          <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center font-bold">
                  <Wind size={18} />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">Havo Sifati Indeksi (AQI)</h3>
                  <p className="text-[10px] text-slate-400">{aqi?.city || selectedCity.name}</p>
                </div>
              </div>

              <button
                onClick={() => loadAqi(selectedCity.lat, selectedCity.lon, selectedCity.name)}
                disabled={loadingAqi}
                className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                title="Yangilash"
              >
                <RefreshCw size={13} className={loadingAqi ? 'animate-spin text-teal-500' : ''} />
              </button>
            </div>

            {loadingAqi ? (
              <div className="space-y-3 py-2 animate-pulse">
                <div className="h-20 bg-slate-100 dark:bg-slate-800/60 rounded-xl" />
                <div className="grid grid-cols-2 gap-2">
                  <div className="h-12 bg-slate-100 dark:bg-slate-800/60 rounded-xl" />
                  <div className="h-12 bg-slate-100 dark:bg-slate-800/60 rounded-xl" />
                </div>
              </div>
            ) : aqi ? (
              <div>
                {/* Large AQI Level Banner */}
                <div className={`p-4 rounded-2xl border mb-3 flex items-center justify-between ${aqi.level.badgeBg}`}>
                  <div>
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <HeartPulse size={14} className={aqi.level.colorClass} />
                      <span className={`text-xs font-bold uppercase tracking-wider ${aqi.level.colorClass}`}>
                        {aqi.level.text}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
                      {aqi.level.advice}
                    </p>
                  </div>

                  <div className="text-right pl-3">
                    <span className="text-3xl font-black font-mono tracking-tight text-slate-900 dark:text-white">
                      {aqi.aqi}
                    </span>
                    <span className="block text-[9px] uppercase font-bold text-slate-400">AQI</span>
                  </div>
                </div>

                {/* Pollutants Breakdown (PM2.5, PM10) */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2.5 rounded-xl bg-slate-50/70 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs">
                    <span className="text-[10px] text-slate-400 font-medium block">Mayda zarralar PM2.5</span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="font-mono font-bold text-slate-900 dark:text-white text-sm">{aqi.pm25}</span>
                      <span className="text-[10px] text-slate-400 font-mono">μg/m³</span>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50/70 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs">
                    <span className="text-[10px] text-slate-400 font-medium block">Chang zarralari PM10</span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="font-mono font-bold text-slate-900 dark:text-white text-sm">{aqi.pm10}</span>
                      <span className="text-[10px] text-slate-400 font-mono">μg/m³</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 mt-4 flex items-center justify-between text-[10px] text-slate-400">
            <span>Manba: Global Air Quality Sensor Network</span>
            <span>Yangilandi: {aqi?.updatedAt || 'Hozir'}</span>
          </div>
        </div>

      </div>
    </section>
  );
};
