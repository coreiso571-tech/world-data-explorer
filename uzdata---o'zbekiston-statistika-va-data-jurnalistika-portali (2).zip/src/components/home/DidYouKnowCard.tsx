import React, { useState, useEffect } from 'react';
import {
  Lightbulb,
  Sparkles,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  RotateCw,
  ExternalLink,
  Share2,
  Check
} from 'lucide-react';

interface FactItem {
  id: string;
  category: string;
  fact: string;
  source: string;
  relatedHash?: string;
}

const FACTS: FactItem[] = [
  {
    id: 'f1',
    category: 'Demografiya',
    fact: "O'zbekistonda aholining 60% dan ortig'ini yoshlar tashkil etadi — bu mamlakatni Markaziy Osiyo mintaqasidagi eng ulkan yosh demografik salohiyatga ega davlatga aylantiradi.",
    source: "Statistika Agentligi (stat.uz)",
    relatedHash: "#statistika/aholi-soni",
  },
  {
    id: 'f2',
    category: 'Hududlar',
    fact: "Qoraqalpog'iston Respublikasi 166 600 kv.km maydonga ega bo'lib, butun O'zbekiston hududining 37% dan ortig'ini egallaydi. Ikkinchi o'rinda Navoiy viloyati (110 800 kv.km).",
    source: "Davlat Kadastrlari Palatasi",
    relatedHash: "#hududlar",
  },
  {
    id: 'f3',
    category: 'IT & Innovatsiya',
    fact: "O'zbekiston IT-xizmatlari eksporti so'nggi 6 yilda 12 million dollardan 550 million dollargacha, ya'ni 45 barobardan ziyodga o'sdi.",
    source: "IT Park Uzbekistan",
    relatedHash: "#statistika/it-xizmatlar-eksporti",
  },
  {
    id: 'f4',
    category: 'Aholi',
    fact: "Samarqand viloyati 4.2 milliondan ortiq doimiy aholi bilan respublikada eng ko'p sonli hudud hisoblanadi (undan keyin Farg'ona 4.05 mln).",
    source: "Demografik ko'rsatkichlar",
    relatedHash: "#hududlar",
  },
  {
    id: 'f5',
    category: "Ta'lim",
    fact: "Bitiruvchilarning oliy ta'lim bilan qamrov darajasi 2017-yildagi 9% dan 42.5% ga oshirildi — bu qariyb 4.7 barobar sakrash demakdir.",
    source: "Oliy Ta'lim Vazirligi",
    relatedHash: "#statistika/oliy-talim-qamrovi",
  },
  {
    id: 'f6',
    category: 'Iqtisodiyot',
    fact: "O'zbekistonning rasmiy oltin-valyuta xalqaro zaxiralari 40 milliard dollardan ortiq darajani tashkil etmoqda.",
    source: "Markaziy Bank",
    relatedHash: "#statistika/yaim-hajmi",
  },
  {
    id: 'f7',
    category: 'Turizm',
    fact: "Yillik xorijiy sayyohlar soni 7.8 million kishiga yetdi. Sayyohlarning 80 foizdan ziyodi Samarqand va Buxoro tarixiy shaharlariga tashrif buyurgan.",
    source: "Turizm Qo'mitasi",
    relatedHash: "#statistika/xorijiy-sayyohlar-oqimi",
  },
  {
    id: 'f8',
    category: 'Energetika',
    fact: "2030-yilga kelib O'zbekiston elektr energiyasi balansida qayta tiklanuvchi quyosh va shamol energiyasi ulushini 40 foizga yetkazish rejalashtirilgan.",
    source: "Energetika Vazirligi",
    relatedHash: "#statistika/yaim-hajmi",
  },
];

export const DidYouKnowCard: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [copied, setCopied] = useState(false);

  const currentFact = FACTS[currentIndex];

  const handleNext = () => {
    setIsAnimating(true);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % FACTS.length);
      setIsAnimating(false);
    }, 150);
  };

  const handlePrev = () => {
    setIsAnimating(true);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev - 1 + FACTS.length) % FACTS.length);
      setIsAnimating(false);
    }, 150);
  };

  // Auto rotate every 8 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      handleNext();
    }, 8500);
    return () => clearInterval(timer);
  }, [currentIndex]);

  const handleShareFact = () => {
    const text = `💡 Bilarmidingiz?\n\n"${currentFact.fact}"\n\nManba: ${currentFact.source} | uzdata.uz`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="relative my-8 sm:my-10 max-w-6xl mx-auto">
      {/* Eye-catching glassmorphism highlight container */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-teal-900/90 via-slate-900/95 to-slate-950 text-white p-5 sm:p-7 shadow-2xl border border-teal-500/30 dark:border-lime-500/30">
        {/* Glow blur background */}
        <div className="absolute top-0 right-1/4 w-72 h-72 bg-lime-400/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 left-10 w-60 h-60 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Top bar with category & nav */}
        <div className="flex items-center justify-between gap-3 mb-4 relative z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-teal-500 to-lime-400 text-slate-950 flex items-center justify-center font-bold shadow-md shrink-0">
              <Lightbulb size={17} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xs uppercase tracking-wider text-lime-400 font-mono">
                  Bilarmidingiz?
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-lime-400 animate-ping" />
              </div>
              <p className="text-[10px] text-slate-400">
                O'zbekiston qiziqarli statistik faktlari
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-[11px] font-mono text-slate-400 mr-1 hidden sm:inline">
              {currentIndex + 1} / {FACTS.length}
            </span>

            <button
              onClick={handleShareFact}
              className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 transition"
              title="Faktni nusxalash"
            >
              {copied ? <Check size={14} className="text-lime-400" /> : <Share2 size={14} />}
            </button>

            <button
              onClick={handlePrev}
              className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 transition cursor-pointer"
              title="Oldingi fakt"
            >
              <ChevronLeft size={16} />
            </button>

            <button
              onClick={handleNext}
              className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 transition cursor-pointer"
              title="Keyingi fakt"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

        {/* Fact Content (Smooth Animated) */}
        <div
          className={`relative z-10 transition-all duration-200 ${
            isAnimating ? 'opacity-0 translate-y-1' : 'opacity-100 translate-y-0'
          }`}
        >
          <div className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-teal-500/20 text-teal-300 border border-teal-500/30 mb-2">
            {currentFact.category}
          </div>

          <blockquote className="text-sm sm:text-lg font-semibold text-slate-100 leading-relaxed mb-4">
            "{currentFact.fact}"
          </blockquote>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-3 border-t border-slate-800 text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5 font-medium">
              <Sparkles size={12} className="text-lime-400 shrink-0" />
              <span>Manba: {currentFact.source}</span>
            </span>

            {currentFact.relatedHash && (
              <a
                href={currentFact.relatedHash}
                className="inline-flex items-center gap-1 text-lime-400 hover:text-lime-300 font-bold transition self-start sm:self-auto"
              >
                <span>Batafsil statistikani ko'rish</span>
                <ArrowRight size={12} />
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
