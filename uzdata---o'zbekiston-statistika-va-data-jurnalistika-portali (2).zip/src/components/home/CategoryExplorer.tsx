import React from 'react';
import { 
  Users, 
  TrendingUp, 
  GraduationCap, 
  Cpu, 
  Compass, 
  Coins, 
  MapPin, 
  LayoutGrid 
} from 'lucide-react';
import { Category, Statistic } from '../../types';
import { StatCard } from '../common/StatCard';
import { StatCardSkeleton } from '../common/SkeletonLoader';

interface CategoryExplorerProps {
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (slug: string) => void;
  statistics: Statistic[];
  onSelectStat: (stat: Statistic) => void;
  loading?: boolean;
}

const ICON_MAP: Record<string, React.ReactNode> = {
  Users: <Users size={18} />,
  TrendingUp: <TrendingUp size={18} />,
  GraduationCap: <GraduationCap size={18} />,
  Cpu: <Cpu size={18} />,
  Compass: <Compass size={18} />,
  Coins: <Coins size={18} />,
  MapPin: <MapPin size={18} />,
};

export const CategoryExplorer: React.FC<CategoryExplorerProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  statistics,
  onSelectStat,
  loading = false,
}) => {
  const filteredStats = selectedCategory === 'all'
    ? statistics
    : statistics.filter((s) => s.category === selectedCategory);

  return (
    <section id="kategoriyalar" className="my-16">
      <div className="mb-8">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          Sohalar Bo'yicha Statistika
        </h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          O'zbekistonning asosiy ijtimoiy-iqtisodiy tarmoqlari bo'yicha tasdiqlangan davlat ko'rsatkichlari.
        </p>
      </div>

      {/* Category Pills / Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-8 scrollbar-none">
        <button
          onClick={() => onSelectCategory('all')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
            selectedCategory === 'all'
              ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:border-teal-500'
          }`}
        >
          <LayoutGrid size={16} />
          <span>Barcha Ko'rsatkichlar ({statistics.length})</span>
        </button>

        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.slug;
          const count = statistics.filter((s) => s.category === cat.slug).length;

          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.slug)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                isSelected
                  ? 'bg-teal-600 text-white shadow-md'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:border-teal-500'
              }`}
            >
              <span className={isSelected ? 'text-white' : 'text-teal-600 dark:text-teal-400'}>
                {ICON_MAP[cat.icon] || <TrendingUp size={16} />}
              </span>
              <span>{cat.name}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Grid of StatCards */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <StatCardSkeleton />
          <StatCardSkeleton />
          <StatCardSkeleton />
        </div>
      ) : filteredStats.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStats.map((stat) => (
            <StatCard
              key={stat.id}
              stat={stat}
              onSelect={onSelectStat}
              categoryName={categories.find((c) => c.slug === stat.category)?.name}
            />
          ))}
        </div>
      ) : (
        <div className="p-12 text-center rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-400">
          <p className="font-medium text-sm">Ushbu sohada hozircha ochiq statistika chop etilmagan</p>
          <button
            onClick={() => onSelectCategory('all')}
            className="mt-3 text-xs text-teal-600 font-semibold hover:underline"
          >
            Barcha sohalarni ko'rish
          </button>
        </div>
      )}
    </section>
  );
};
