import React from 'react';
import { Globe, ArrowRight, Scale, TrendingUp, Sparkles, ShieldCheck } from 'lucide-react';
import { FlagVector } from '../international/FlagVector';

interface InternationalTeaserProps {
  onNavigateToInternational: () => void;
}

export const InternationalTeaserSection: React.FC<InternationalTeaserProps> = ({
  onNavigateToInternational,
}) => {
  const teaserCountries = [
    {
      code: 'IND' as const,
      name: 'Hindiston',
      flagCode: 'IND' as const,
      keyStat: '1.43 mlrd',
      statLabel: 'Aholi soni',
      focus: 'Global IT & Demografiya',
      badge: '№1 Aholi',
    },
    {
      code: 'CHN' as const,
      name: 'Xitoy',
      flagCode: 'CHN' as const,
      keyStat: '$18.53 trln',
      statLabel: 'Yalpi Ichki Mahsulot',
      focus: 'Eksport & Yashil Energiya',
      badge: '№1 Hamkor',
    },
    {
      code: 'RUS' as const,
      name: 'Rossiya',
      flagCode: 'RUS' as const,
      keyStat: '17.1 mln km²',
      statLabel: 'Yer maydoni',
      focus: 'Energetika & Xomashyo',
      badge: '№1 Maydon',
    },
    {
      code: 'USA' as const,
      name: 'AQSh',
      flagCode: 'USA' as const,
      keyStat: '$28.78 trln',
      statLabel: 'Nominal YaIM',
      focus: 'Sun\'iy Intellekt & Moliya',
      badge: '№1 Iqtisodiyot',
    },
  ];

  return (
    <section className="my-14 relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-teal-950 border border-slate-800 p-6 sm:p-8 shadow-xl">
      {/* Decorative ambient light */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-72 h-72 bg-lime-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-8">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/20 text-lime-300 text-xs font-mono font-bold uppercase tracking-wider mb-2 border border-teal-500/30">
              <Globe size={13} className="text-lime-400" />
              <span>Xalqaro Maydon & Taqqoslash</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              O'zbekiston Global Statistik Kontekstda
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
              Respublikamizning 14 ta hududi milliy taraqqiyot asosi bo'lsa, jahon yetakchilari (Hindiston, Xitoy, Rossiya, AQSh) bilan solishtirma tahlil global eksport va raqamli istiqbollarni ko'rsatib beradi.
            </p>
          </div>

          <button
            onClick={onNavigateToInternational}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-teal-500 to-lime-400 hover:from-teal-400 hover:to-lime-300 text-slate-950 font-bold text-xs sm:text-sm transition shadow-lg shadow-teal-500/20 shrink-0 self-start lg:self-auto cursor-pointer"
          >
            <Scale size={16} />
            <span>Xalqaro Hub va Taqqoslash</span>
            <ArrowRight size={16} />
          </button>
        </div>

        {/* 4 Teaser Country Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {teaserCountries.map((item) => (
            <div
              key={item.code}
              onClick={onNavigateToInternational}
              className="p-4 rounded-2xl bg-slate-900/80 backdrop-blur-sm border border-slate-800 hover:border-teal-500/50 hover:bg-slate-800/80 transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <FlagVector countryCode={item.flagCode} size="sm" />
                    <span className="font-bold text-sm text-white group-hover:text-lime-300 transition-colors">
                      {item.name}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-teal-400 border border-slate-700">
                    {item.badge}
                  </span>
                </div>

                <div className="mb-2">
                  <div className="text-[11px] text-slate-400">{item.statLabel}</div>
                  <div className="text-xl font-black font-mono text-white mt-0.5 group-hover:text-lime-400 transition-colors">
                    {item.keyStat}
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                <span>{item.focus}</span>
                <span className="text-teal-400 group-hover:translate-x-1 transition-transform">→</span>
              </div>
            </div>
          ))}
        </div>

        {/* Credibility footer note */}
        <div className="mt-5 flex flex-wrap items-center justify-between gap-2 pt-4 border-t border-slate-800/80 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck size={14} className="text-teal-400" />
            <span>Manba: Jahon Banki (World Bank Open Data) rasmiy ko'rsatkichlari asosida avtomatik yangilanadi.</span>
          </div>
          <div className="text-slate-400 font-mono">
            O'zbekiston bilan yuzma-yuz solishtiring
          </div>
        </div>
      </div>
    </section>
  );
};
