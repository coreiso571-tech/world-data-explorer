import React, { useState } from 'react';
import {
  Search,
  Filter,
  X,
  Calendar,
  MapPin,
  Tag,
  RotateCcw,
  SlidersHorizontal,
  ChevronDown,
  TrendingUp,
  BookOpen,
  Sparkles
} from 'lucide-react';
import { Category } from '../../types';
import { REGIONS_DATA } from '../../data/seedData';

export interface SearchFilterState {
  searchQuery: string;
  category: string;
  datePeriod: string;
  region: string;
  contentType: 'all' | 'stats' | 'articles';
}

interface AdvancedSearchFilterBarProps {
  filters: SearchFilterState;
  onFilterChange: (filters: SearchFilterState) => void;
  categories: Category[];
  totalResultsCount: number;
  statsCount: number;
  articlesCount: number;
  onOpenFullModal?: () => void;
}

export const AdvancedSearchFilterBar: React.FC<AdvancedSearchFilterBarProps> = ({
  filters,
  onFilterChange,
  categories,
  totalResultsCount,
  statsCount,
  articlesCount,
  onOpenFullModal,
}) => {
  const [showFiltersMobile, setShowFiltersMobile] = useState(false);

  const hasActiveFilters =
    filters.searchQuery.trim() !== '' ||
    filters.category !== 'all' ||
    filters.datePeriod !== 'all' ||
    filters.region !== 'all' ||
    filters.contentType !== 'all';

  const resetFilters = () => {
    onFilterChange({
      searchQuery: '',
      category: 'all',
      datePeriod: 'all',
      region: 'all',
      contentType: 'all',
    });
  };

  return (
    <div className="relative z-20 my-6 sm:my-10 max-w-6xl mx-auto">
      {/* Container with Glassmorphic Navy/Lime Aesthetic */}
      <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border border-slate-200/90 dark:border-teal-500/25 rounded-3xl p-4 sm:p-5 shadow-xl shadow-slate-200/40 dark:shadow-none">
        {/* Main Search Input Row */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Input Box */}
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <Search size={18} className="text-teal-600 dark:text-lime-400" />
            </div>
            <input
              type="text"
              value={filters.searchQuery}
              onChange={(e) =>
                onFilterChange({ ...filters, searchQuery: e.target.value })
              }
              placeholder="Qidiruv: Ko'rsatkich, soha, viloyat, YaIM, aholi yoki maqola nomi..."
              className="w-full pl-11 pr-10 py-3 rounded-2xl bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 text-xs sm:text-sm font-medium text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:border-teal-500 dark:focus:border-lime-400 transition"
            />
            {filters.searchQuery && (
              <button
                type="button"
                onClick={() => onFilterChange({ ...filters, searchQuery: '' })}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X size={16} />
              </button>
            )}
          </div>

          {/* Mobile Filter Toggle */}
          <div className="flex items-center gap-2 sm:hidden">
            <button
              type="button"
              onClick={() => setShowFiltersMobile(!showFiltersMobile)}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700"
            >
              <SlidersHorizontal size={14} />
              <span>Filtrlar</span>
              {hasActiveFilters && (
                <span className="w-2 h-2 rounded-full bg-teal-500" />
              )}
            </button>
            {hasActiveFilters && (
              <button
                type="button"
                onClick={resetFilters}
                className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800"
                title="Tozalash"
              >
                <RotateCcw size={14} />
              </button>
            )}
          </div>
        </div>

        {/* Advanced Filter Dropdowns: Category, Date, Region, Content Type */}
        <div
          className={`${
            showFiltersMobile ? 'block' : 'hidden'
          } sm:grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-4 pt-4 border-t border-slate-100 dark:border-slate-800/80 text-xs`}
        >
          {/* 1. Category Filter Dropdown */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1.5">
              <Tag size={12} className="text-teal-500" />
              <span>Soha / Kategoriya</span>
            </label>
            <div className="relative">
              <select
                value={filters.category}
                onChange={(e) =>
                  onFilterChange({ ...filters, category: e.target.value })
                }
                className="w-full appearance-none px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-hidden focus:border-teal-500 cursor-pointer"
              >
                <option value="all">Barcha Sohalar</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.slug}>
                    {c.name}
                  </option>
                ))}
              </select>
              <ChevronDown
                size={14}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
              />
            </div>
          </div>

          {/* 2. Date / Period Filter Dropdown */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1.5">
              <Calendar size={12} className="text-teal-500" />
              <span>Davr / Yillar</span>
            </label>
            <div className="relative">
              <select
                value={filters.datePeriod}
                onChange={(e) =>
                  onFilterChange({ ...filters, datePeriod: e.target.value })
                }
                className="w-full appearance-none px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-hidden focus:border-teal-500 cursor-pointer"
              >
                <option value="all">Barcha Davrlar</option>
                <option value="2026">2026-yil (Eng so'nggi)</option>
                <option value="2025">2025-yil</option>
                <option value="2024">2024-yil</option>
                <option value="recent5">So'nggi 5 yil (2020-2026)</option>
                <option value="historical">Tarixiy davr (1991-2019)</option>
              </select>
              <ChevronDown
                size={14}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
              />
            </div>
          </div>

          {/* 3. Region Filter Dropdown */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1.5">
              <MapPin size={12} className="text-teal-500" />
              <span>Hudud / Viloyat</span>
            </label>
            <div className="relative">
              <select
                value={filters.region}
                onChange={(e) =>
                  onFilterChange({ ...filters, region: e.target.value })
                }
                className="w-full appearance-none px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-hidden focus:border-teal-500 cursor-pointer"
              >
                <option value="all">Barcha Hududlar (14 ta)</option>
                {REGIONS_DATA.map((r) => (
                  <option key={r.id} value={r.name}>
                    {r.name}
                  </option>
                ))}
              </select>
              <ChevronDown
                size={14}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
              />
            </div>
          </div>

          {/* 4. Content Type Toggle */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1.5">
              <SlidersHorizontal size={12} className="text-teal-500" />
              <span>Ma'lumot Turi</span>
            </label>
            <div className="flex items-center gap-1 p-0.5 bg-slate-100 dark:bg-slate-950/80 rounded-xl border border-slate-200/80 dark:border-slate-800">
              <button
                type="button"
                onClick={() =>
                  onFilterChange({ ...filters, contentType: 'all' })
                }
                className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-semibold transition cursor-pointer ${
                  filters.contentType === 'all'
                    ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-lime-400 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                Hammasi
              </button>
              <button
                type="button"
                onClick={() =>
                  onFilterChange({ ...filters, contentType: 'stats' })
                }
                className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1 transition cursor-pointer ${
                  filters.contentType === 'stats'
                    ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-lime-400 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Faqat statistika"
              >
                <TrendingUp size={11} />
                <span>Stat</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  onFilterChange({ ...filters, contentType: 'articles' })
                }
                className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1 transition cursor-pointer ${
                  filters.contentType === 'articles'
                    ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-lime-400 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Faqat maqolalar"
              >
                <BookOpen size={11} />
                <span>Maqola</span>
              </button>
            </div>
          </div>
        </div>

        {/* Active Filters Bar & Reset */}
        {hasActiveFilters && (
          <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[11px] font-semibold text-slate-400 mr-1">
                Topildi: {totalResultsCount} ta ({statsCount} stat, {articlesCount} maqola)
              </span>

              {filters.searchQuery && (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-700 dark:text-lime-400 text-[11px] font-medium border border-teal-500/20">
                  <span>Matn: "{filters.searchQuery}"</span>
                  <button
                    type="button"
                    onClick={() => onFilterChange({ ...filters, searchQuery: '' })}
                    className="hover:opacity-75"
                  >
                    <X size={12} />
                  </button>
                </span>
              )}

              {filters.category !== 'all' && (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-700 dark:text-lime-400 text-[11px] font-medium border border-teal-500/20">
                  <span>Soha: {categories.find((c) => c.slug === filters.category)?.name || filters.category}</span>
                  <button
                    type="button"
                    onClick={() => onFilterChange({ ...filters, category: 'all' })}
                    className="hover:opacity-75"
                  >
                    <X size={12} />
                  </button>
                </span>
              )}

              {filters.datePeriod !== 'all' && (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-700 dark:text-lime-400 text-[11px] font-medium border border-teal-500/20">
                  <span>Davr: {filters.datePeriod}</span>
                  <button
                    type="button"
                    onClick={() => onFilterChange({ ...filters, datePeriod: 'all' })}
                    className="hover:opacity-75"
                  >
                    <X size={12} />
                  </button>
                </span>
              )}

              {filters.region !== 'all' && (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-700 dark:text-lime-400 text-[11px] font-medium border border-teal-500/20">
                  <span>Hudud: {filters.region}</span>
                  <button
                    type="button"
                    onClick={() => onFilterChange({ ...filters, region: 'all' })}
                    className="hover:opacity-75"
                  >
                    <X size={12} />
                  </button>
                </span>
              )}
            </div>

            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-500 hover:text-rose-600 transition cursor-pointer"
            >
              <RotateCcw size={12} />
              <span>Barcha filtrlarni tozalash</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
