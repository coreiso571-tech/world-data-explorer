import React, { useState } from 'react';
import { MapPin, Users, Wallet, TrendingUp, Building2, Globe } from 'lucide-react';
import { REGIONS_DATA } from '../../data/seedData';
import { RegionData } from '../../types';

export const RegionalMapSection: React.FC = () => {
  const [metric, setMetric] = useState<'salary' | 'population' | 'gdp'>('salary');
  const [selectedRegion, setSelectedRegion] = useState<RegionData>(REGIONS_DATA[0]);

  const sortedRegions = [...REGIONS_DATA].sort((a, b) => {
    if (metric === 'salary') return b.avgSalary - a.avgSalary;
    if (metric === 'population') return b.population - a.population;
    return b.gdpShare - a.gdpShare;
  });

  const maxValue = sortedRegions[0] ? (
    metric === 'salary' ? sortedRegions[0].avgSalary :
    metric === 'population' ? sortedRegions[0].population :
    sortedRegions[0].gdpShare
  ) : 1;

  return (
    <section id="hududlar" className="my-16">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Globe size={13} />
            Hududiy Tahlil
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            14 Ta Ma'muriy Hudud Ko'rsatkichlari
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
            Toshkent shahri, Qoraqalpog'iston Respublikasi va 12 ta viloyat bo'yicha daromadlar, demografik yuklama va iqtisodiy faollik qiyosiy darajasi.
          </p>
        </div>

        {/* Metric Switcher */}
        <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 self-start md:self-auto text-xs font-semibold">
          <button
            onClick={() => setMetric('salary')}
            className={`px-3 py-1.5 rounded-lg transition ${
              metric === 'salary'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            O'rtacha Maosh
          </button>
          <button
            onClick={() => setMetric('population')}
            className={`px-3 py-1.5 rounded-lg transition ${
              metric === 'population'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Aholi Soni
          </button>
          <button
            onClick={() => setMetric('gdp')}
            className={`px-3 py-1.5 rounded-lg transition ${
              metric === 'gdp'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            YaIMdagi Ulush (%)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Ranked Comparison Chart */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center justify-between">
            <span>Reyting bo'yicha taqsimot</span>
            <span className="text-xs text-slate-400 font-normal">
              {metric === 'salary' ? "Oylik ish haqi (so'm)" : metric === 'population' ? 'Aholi (ming kishi)' : 'Ulush (%)'}
            </span>
          </h3>

          <div className="space-y-3">
            {sortedRegions.map((region, idx) => {
              const currentVal = metric === 'salary' ? region.avgSalary : metric === 'population' ? region.population : region.gdpShare;
              const percent = Math.max(8, Math.round((currentVal / maxValue) * 100));
              const isSelected = selectedRegion.id === region.id;

              return (
                <div
                  key={region.id}
                  onClick={() => setSelectedRegion(region)}
                  className={`p-2.5 rounded-xl cursor-pointer transition flex items-center gap-3 ${
                    isSelected
                      ? 'bg-teal-50/70 dark:bg-teal-950/40 border border-teal-500/30'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <span className={`w-5 text-center text-xs font-mono font-bold ${idx < 3 ? 'text-teal-600 dark:text-teal-400' : 'text-slate-400'}`}>
                    {idx + 1}
                  </span>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between text-xs font-medium mb-1">
                      <span className="text-slate-900 dark:text-white truncate">{region.name}</span>
                      <span className="font-mono font-bold text-slate-800 dark:text-slate-200 shrink-0">
                        {metric === 'salary' ? `${region.avgSalaryStr} so'm` : metric === 'population' ? region.populationStr : `${region.gdpShare}%`}
                      </span>
                    </div>

                    <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          idx === 0
                            ? 'bg-teal-500'
                            : idx < 3
                            ? 'bg-teal-600'
                            : 'bg-slate-400 dark:bg-slate-600'
                        }`}
                        style={{ width: `${percent}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Selected Region Spotlight Card */}
        <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-2xl p-6 sm:p-7 shadow-xl border border-slate-800 sticky top-24">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs uppercase tracking-widest font-mono text-teal-400 font-semibold">
              Tanlangan Hudud Pasporti
            </span>
            <MapPin className="text-teal-400" size={18} />
          </div>

          <h3 className="text-2xl font-black mb-1">{selectedRegion.name}</h3>
          <p className="text-xs text-slate-400 mb-6 flex items-center gap-1">
            <Building2 size={13} />
            Ma'muriy markazi: <span className="text-slate-200 font-medium">{selectedRegion.center}</span>
          </p>

          <div className="grid grid-cols-2 gap-3 mb-6">
            <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3.5">
              <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
                <Users size={14} className="text-teal-400" />
                <span>Doimiy Aholisi</span>
              </div>
              <p className="text-xl font-bold font-mono text-white">{selectedRegion.populationStr}</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Respublikadagi ulushi yuqori</p>
            </div>

            <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3.5">
              <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
                <Wallet size={14} className="text-emerald-400" />
                <span>O'rtacha Oylik</span>
              </div>
              <p className="text-xl font-bold font-mono text-white">{selectedRegion.avgSalaryStr} <span className="text-xs font-normal">so'm</span></p>
              <p className="text-[10px] text-slate-400 mt-0.5">Nominal hisoblangan</p>
            </div>

            <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3.5">
              <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
                <TrendingUp size={14} className="text-cyan-400" />
                <span>YaIMdagi Salmog'i</span>
              </div>
              <p className="text-xl font-bold font-mono text-white">{selectedRegion.gdpShare}%</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Respublika bo'yicha</p>
            </div>

            <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3.5">
              <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
                <Globe size={14} className="text-amber-400" />
                <span>Hududi</span>
              </div>
              <p className="text-xl font-bold font-mono text-white">
                {selectedRegion.areaKm2.toLocaleString('uz-UZ')} <span className="text-xs font-normal">km²</span>
              </p>
              <p className="text-[10px] text-slate-400 mt-0.5">Umumiy yer maydoni</p>
            </div>
          </div>

          <div className="text-xs text-slate-400 leading-relaxed bg-slate-800/40 p-3 rounded-xl border border-slate-800">
            💡 <strong className="text-slate-300">Tahliliy xulosa:</strong> {selectedRegion.name} hududi iqtisodiyoti {selectedRegion.gdpShare >= 7 ? "respublika bo'yicha yetakchi drayverlardan biri" : "rivojlanayotgan sanoat va xizmat ko'rsatish tarmoqlari"} hisoblanadi.
          </div>
        </div>
      </div>
    </section>
  );
};
