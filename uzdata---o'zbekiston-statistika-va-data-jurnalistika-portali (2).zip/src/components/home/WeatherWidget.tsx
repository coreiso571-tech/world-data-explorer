import React, { useState, useEffect } from 'react';
import { 
  Sun, 
  CloudSun, 
  Cloud, 
  CloudRain, 
  CloudDrizzle, 
  CloudSnow, 
  CloudLightning, 
  Wind, 
  Droplets, 
  Gauge, 
  MapPin, 
  RefreshCw, 
  Thermometer, 
  Umbrella,
  CalendarDays,
  Sparkles
} from 'lucide-react';
import { 
  WeatherLocation, 
  WeatherData, 
  UZBEKISTAN_WEATHER_LOCATIONS, 
  fetchWeatherData,
  getWeatherConditionInfo 
} from '../../services/weatherService';

export const WeatherWidget: React.FC = () => {
  const [selectedLoc, setSelectedLoc] = useState<WeatherLocation>(UZBEKISTAN_WEATHER_LOCATIONS[0]);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadWeather = async (loc: WeatherLocation) => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchWeatherData(loc);
      setWeather(data);
    } catch (err: unknown) {
      console.error('Weather load error:', err);
      setError("Ob-havo ma'lumotlarini yuklashda xatolik yuz berdi. Qayta urinib ko'ring.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadWeather(selectedLoc);
  }, [selectedLoc]);

  const renderWeatherIcon = (code: number, size = 24, className = '', isDay = true) => {
    const { iconType } = getWeatherConditionInfo(code, isDay);
    switch (iconType) {
      case 'sun':
        return <Sun size={size} className={`text-amber-500 animate-spin-slow ${className}`} />;
      case 'cloud-sun':
        return <CloudSun size={size} className={`text-amber-500 ${className}`} />;
      case 'cloud':
        return <Cloud size={size} className={`text-slate-400 dark:text-slate-300 ${className}`} />;
      case 'drizzle':
        return <CloudDrizzle size={size} className={`text-cyan-400 ${className}`} />;
      case 'rain':
        return <CloudRain size={size} className={`text-blue-500 ${className}`} />;
      case 'snow':
        return <CloudSnow size={size} className={`text-sky-300 ${className}`} />;
      case 'storm':
        return <CloudLightning size={size} className={`text-amber-400 ${className}`} />;
      default:
        return <CloudSun size={size} className={`text-amber-500 ${className}`} />;
    }
  };

  return (
    <section id="ob-havo" className="my-12">
      <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs relative overflow-hidden transition-all duration-300">
        {/* Subtle background ambient glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-bl from-teal-500/10 via-cyan-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />

        {/* Header with Title and Region Selector */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-5 border-b border-slate-100 dark:border-slate-800">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 text-xs font-semibold uppercase tracking-wider mb-1.5">
              <Sun size={13} className="text-amber-500" />
              <span>Meteorologiya & Iqlim</span>
            </div>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <span>O'zbekiston Ob-havosi</span>
              <span className="text-sm font-semibold text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/50 px-2 py-0.5 rounded-md hidden sm:inline-block">
                Jonli
              </span>
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Region Dropdown */}
            <div className="relative flex-1 sm:flex-initial">
              <div className="flex items-center gap-2 px-3.5 py-2 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-200">
                <MapPin size={15} className="text-teal-600 dark:text-teal-400 shrink-0" />
                <select
                  aria-label="Hududni tanlang"
                  value={selectedLoc.id}
                  onChange={(e) => {
                    const found = UZBEKISTAN_WEATHER_LOCATIONS.find((l) => l.id === e.target.value);
                    if (found) setSelectedLoc(found);
                  }}
                  className="bg-transparent text-slate-900 dark:text-white font-bold cursor-pointer focus:outline-hidden pr-2"
                >
                  {UZBEKISTAN_WEATHER_LOCATIONS.map((loc) => (
                    <option key={loc.id} value={loc.id} className="dark:bg-slate-900 text-slate-900 dark:text-white">
                      {loc.name} ({loc.region})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Refresh button */}
            <button
              onClick={() => loadWeather(selectedLoc)}
              disabled={loading}
              title="Yangilash"
              className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-slate-100 dark:hover:bg-slate-700/80 transition disabled:opacity-50"
            >
              <RefreshCw size={15} className={loading ? 'animate-spin text-teal-500' : ''} />
            </button>
          </div>
        </div>

        {/* Quick Regional Pills for Top Cities */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-4 mb-6 scrollbar-none text-xs">
          {UZBEKISTAN_WEATHER_LOCATIONS.slice(0, 6).map((loc) => {
            const isSelected = selectedLoc.id === loc.id;
            return (
              <button
                key={loc.id}
                onClick={() => setSelectedLoc(loc)}
                className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-xs'
                    : 'bg-slate-100/80 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <span>{loc.name.replace(' shahri', '')}</span>
              </button>
            );
          })}
        </div>

        {/* Loading State */}
        {loading && !weather ? (
          <div className="animate-pulse space-y-6">
            <div className="h-32 bg-slate-100 dark:bg-slate-800/60 rounded-2xl w-full" />
            <div className="grid grid-cols-2 sm:grid-cols-7 gap-3">
              {[...Array(7)].map((_, i) => (
                <div key={i} className="h-28 bg-slate-100 dark:bg-slate-800/40 rounded-xl" />
              ))}
            </div>
          </div>
        ) : error ? (
          <div className="py-8 text-center text-slate-500 dark:text-slate-400">
            <p className="text-sm font-medium text-rose-500">{error}</p>
            <button
              onClick={() => loadWeather(selectedLoc)}
              className="mt-3 px-4 py-1.5 text-xs font-semibold rounded-lg bg-teal-600 text-white hover:bg-teal-700 transition"
            >
              Qayta yuklash
            </button>
          </div>
        ) : weather ? (
          <div>
            {/* CURRENT WEATHER HERO CARD */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 text-white shadow-lg border border-slate-800/90 mb-6">
              {/* Left Column: Big Temp & Condition */}
              <div className="lg:col-span-5 flex items-center gap-5">
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-slate-800/70 border border-slate-700/60 flex items-center justify-center shrink-0 shadow-inner">
                  {renderWeatherIcon(weather.current.weatherCode, 52, '', weather.current.isDay)}
                </div>
                <div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl sm:text-5xl font-black font-mono tracking-tight text-white">
                      {weather.current.temperature > 0 ? `+${weather.current.temperature}` : weather.current.temperature}°
                    </span>
                    <span className="text-teal-400 text-xl font-bold font-mono">C</span>
                  </div>
                  <p className="text-base font-bold text-slate-100 mt-0.5">
                    {weather.current.conditionText}
                  </p>
                  <p className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                    <span>{weather.location.name}</span> • <span>Yangilandi: {weather.updatedAt}</span>
                  </p>
                </div>
              </div>

              {/* Right Column: Key Meteorological Indicators */}
              <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-3">
                  <div className="flex items-center gap-1 text-slate-400 text-xs mb-1">
                    <Thermometer size={13} className="text-teal-400" />
                    <span>His qilinishi</span>
                  </div>
                  <p className="text-lg font-bold font-mono text-white">
                    {weather.current.apparentTemperature > 0 ? `+${weather.current.apparentTemperature}` : weather.current.apparentTemperature}°C
                  </p>
                  <p className="text-[10px] text-slate-400">Harorat hissi</p>
                </div>

                <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-3">
                  <div className="flex items-center gap-1 text-slate-400 text-xs mb-1">
                    <Droplets size={13} className="text-cyan-400" />
                    <span>Namlik</span>
                  </div>
                  <p className="text-lg font-bold font-mono text-white">
                    {weather.current.humidity}%
                  </p>
                  <p className="text-[10px] text-slate-400">Nisbiy namlik</p>
                </div>

                <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-3">
                  <div className="flex items-center gap-1 text-slate-400 text-xs mb-1">
                    <Wind size={13} className="text-emerald-400" />
                    <span>Shamol</span>
                  </div>
                  <p className="text-lg font-bold font-mono text-white">
                    {weather.current.windSpeed} <span className="text-xs font-normal">km/soat</span>
                  </p>
                  <p className="text-[10px] text-slate-400">Tezlik</p>
                </div>

                <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-3">
                  <div className="flex items-center gap-1 text-slate-400 text-xs mb-1">
                    <Gauge size={13} className="text-amber-400" />
                    <span>Atmosfera bosimi</span>
                  </div>
                  <p className="text-lg font-bold font-mono text-white">
                    {weather.current.pressure} <span className="text-xs font-normal">hPa</span>
                  </p>
                  <p className="text-[10px] text-slate-400">Barometr</p>
                </div>
              </div>
            </div>

            {/* 7-DAY FORECAST GRID */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <CalendarDays size={14} className="text-teal-600 dark:text-teal-400" />
                  <span>7 Kunlik Ob-havo Prognozi ({weather.location.name})</span>
                </h4>
                <span className="text-[11px] text-slate-400">
                  Kunduzgi / Tungi harorat
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5">
                {weather.daily.map((day, idx) => (
                  <div
                    key={day.date}
                    className={`p-3.5 rounded-2xl border text-center transition flex flex-col justify-between ${
                      idx === 0
                        ? 'bg-teal-50/60 dark:bg-teal-950/30 border-teal-500/40 shadow-xs'
                        : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200/70 dark:border-slate-800 hover:border-teal-500/30'
                    }`}
                  >
                    <div>
                      <p className={`text-xs font-bold ${idx === 0 ? 'text-teal-700 dark:text-teal-300' : 'text-slate-800 dark:text-slate-200'}`}>
                        {day.dayName}
                      </p>
                      <p className="text-[10px] text-slate-400 mb-2">
                        {day.date.split('-').slice(1).reverse().join('.')}
                      </p>
                    </div>

                    <div className="my-2 flex justify-center">
                      <div className="w-10 h-10 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex items-center justify-center shadow-xs">
                        {renderWeatherIcon(day.weatherCode, 22)}
                      </div>
                    </div>

                    <div>
                      <div className="flex items-baseline justify-center gap-1 font-mono text-xs">
                        <span className="font-bold text-slate-900 dark:text-white">
                          {day.maxTemp > 0 ? `+${day.maxTemp}` : day.maxTemp}°
                        </span>
                        <span className="text-slate-400 text-[10px]">
                          {day.minTemp > 0 ? `+${day.minTemp}` : day.minTemp}°
                        </span>
                      </div>

                      <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate mt-1">
                        {day.conditionText}
                      </p>

                      {day.precipitationProb > 20 && (
                        <div className="mt-1 inline-flex items-center gap-0.5 text-[9px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/50 px-1.5 py-0.2 rounded-md">
                          <Umbrella size={9} />
                          <span>{day.precipitationProb}%</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : null}

        {/* Footer info banner */}
        <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <Sparkles size={12} className="text-teal-500" />
            <span>O'zbekiston gidrometeorologiya va global ochiq iqlim modellari asosida</span>
          </div>
          <div className="flex items-center gap-2">
            <span>Manba: Open-Meteo Global Forecast Engine</span>
          </div>
        </div>
      </div>
    </section>
  );
};
