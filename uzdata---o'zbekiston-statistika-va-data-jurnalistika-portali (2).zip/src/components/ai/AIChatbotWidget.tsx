import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  X,
  Send,
  Sparkles,
  Bot,
  User,
  RotateCcw,
  Minimize2,
  ChevronRight,
  TrendingUp,
  ExternalLink,
  Copy,
  Check
} from 'lucide-react';
import { Statistic, Article } from '../../types';

interface Message {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  suggestions?: string[];
  links?: { title: string; hash: string }[];
}

interface AIChatbotWidgetProps {
  statistics?: Statistic[];
  articles?: Article[];
  onNavigateHash?: (hash: string) => void;
}

export const AIChatbotWidget: React.FC<AIChatbotWidgetProps> = ({
  statistics = [],
  articles = [],
  onNavigateHash,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const initialWelcomeMessage: Message = {
    id: 'welcome',
    sender: 'bot',
    text: "Assalomu alaykum! O'zbekiston statistikasi bo'yicha qanday savolingiz bor? Men sizga YaIM, aholi soni, inflyatsiya, IT eksporti, oylik maosh va hududlar bo'yicha rasmiy davlat ko'rsatkichlarini tushuntirib bera olaman.",
    timestamp: new Date().toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' }),
    suggestions: [
      "O'zbekiston aholisi soni qancha?",
      "YaIM hajmi va o'sishi qanday?",
      "IT eksporti qanday o'sdi?",
      "O'rtacha oylik ish haqi qancha?",
      "Aholisi eng ko'p viloyat qaysi?",
    ],
  };

  const [messages, setMessages] = useState<Message[]>([initialWelcomeMessage]);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isTyping, isOpen]);

  // Intelligent Context-Aware Response Engine in Uzbek
  const generateBotReply = (userQuery: string): { text: string; links?: { title: string; hash: string }[] } => {
    const q = userQuery.toLowerCase().trim();

    if (q.includes('aholi') || q.includes('demografiya') || q.includes('necha kishi')) {
      return {
        text: "🇺🇿 **O'zbekiston Doimiy Aholisi:**\n\n• **Jami aholi soni:** **37.6 million** nafardan oshdi (yillik o'sish +2.1%).\n• **Taqsimot:** 50.4% shahar joylarida, 49.6% qishloq joylarida istiqomat qiladi.\n• **Eng yirik hududlar:** Samarqand viloyati (4.2 mln), Farg'ona viloyati (4.05 mln), Toshkent shahri (3.1 mln).\n• **Aholi yoshi:** O'rtacha yosh ~29-30 yoshni tashkil etadi (Markaziy Osiyodagi eng yosh demografik salohiyat).",
        links: [
          { title: "Aholi statistikasi grafigi", hash: "#statistika/aholi-soni" },
          { title: "14 ta hudud xaritasi", hash: "#hududlar" },
        ],
      };
    }

    if (q.includes('yaim') || q.includes('iqtisodiyot') || q.includes('yalpi') || q.includes('gdp')) {
      return {
        text: "📈 **Yalpi Ichki Mahsulot (YaIM) Ko'rsatkichlari:**\n\n• **Joriy YaIM hajmi:** **$112.5 milliard** AQSH dollariga yetdi.\n• **Yillik real o'sish:** **+6.4%** darajasida barqaror davom etmoqda.\n• **Drayverlar:** Sanoat tarmoqlari, BPO va xizmatlar ko'rsatish hamda xorijiy to'g'ridan-to'g'ri investitsiyalar.\n• **Poytaxt ulushi:** Toshkent shahri respublika YaIMining 17.5% qismini shakllantiradi.",
        links: [
          { title: "YaIM dinamikasi grafigi", hash: "#statistika/yaim-hajmi" },
          { title: "Iqtisodiy tahlillar", hash: "#maqolalar" },
        ],
      };
    }

    if (q.includes('it') || q.includes('eksport') || q.includes('dastur') || q.includes('park') || q.includes('texnologiya')) {
      return {
        text: "💻 **IT Xizmatlar Eksporti & Raqamli Iqtisodiyot:**\n\n• **Eksport hajmi:** **$550 million** (2019-yildagi $12 mln dan 45 barobardan ziyod o'sish!).\n• **Rezidentlar:** IT Parkda 2400 dan ortiq korxona, ulardan 700+ tasi xorijiy kapital ishtirokida.\n• **Asosiy bozorlar:** AQSH (45%), Yevropa Ittifoqi (25%), Yaqin Sharq va MDH.\n• **Strategik maqsad:** 2030-yilgacha IT eksportini $5 milliardga yetkazish.",
        links: [
          { title: "IT eksport ko'rsatkichi", hash: "#statistika/it-xizmatlar-eksporti" },
          { title: "Maxsus tahliliy maqola", hash: "#maqola/it-xizmatlar-eksporti-tahlili" },
        ],
      };
    }

    if (q.includes('oylik') || q.includes('maosh') || q.includes('ish haqi') || q.includes('daromad')) {
      return {
        text: "💰 **O'rtacha Oylik Nominal Ish Haqi:**\n\n• **Respublika bo'yicha:** **5 450 000 so'm** (yillik nominal o'sish +17.2%).\n• **Hududlar yetakchisi:** Toshkent shahrida o'rtacha 8.9 million so'm.\n• **Sohalar bo'yicha:** Bank va moliya sohasida 14+ mln so'm, axborot va aloqa sohasida 12+ mln so'm.",
        links: [
          { title: "Oylik ish haqi jadvali", hash: "#statistika/ortacha-oylik-ish-haqi" },
        ],
      };
    }

    if (q.includes('inflyatsiya') || q.includes('narx') || q.includes('iste\'mol') || q.includes('qimmat')) {
      return {
        text: "📊 **Inflyatsiya va Narxlar Barqarorligi:**\n\n• **Yillik inflyatsiya ko'rsatkichi:** **8.4%** gacha pasaydi.\n• **Markaziy Bank maqsadi:** O'rta muddatda 5% targetiga erishish.\n• **Asosiy omillar:** Oziq-ovqat xavfsizligi va qat'iy pul-kredit siyosati.",
        links: [
          { title: "Inflyatsiya grafigi", hash: "#statistika/inflyatsiya-darajasi" },
        ],
      };
    }

    if (q.includes('sayyoh') || q.includes('turizm') || q.includes('mehmon') || q.includes('turist')) {
      return {
        text: "✈️ **Turizm va Sayyohlar Oqimi:**\n\n• **Yillik xorijiy sayyohlar:** **7.8 million** nafar (+18.2% o'sish).\n• **Mashhur manzillar:** Samarqand, Buxoro, Xiva va Toshkent shaharlari.\n• **Infratuzilma:** Yangi tezyurar poyezdlar, xalqaro aeroportlar va vizasiz rejim.",
        links: [
          { title: "Sayyohlar oqimi grafigi", hash: "#statistika/xorijiy-sayyohlar-oqimi" },
        ],
      };
    }

    if (q.includes('samarqand') || q.includes('viloyat') || q.includes('farg\'ona') || q.includes('hudud')) {
      return {
        text: "📍 **O'zbekiston Hududlari Statistikasi:**\n\n• **Eng ko'p aholi:** Samarqand viloyati (4.2 mln) va Farg'ona (4.05 mln).\n• **Eng katta yer maydoni:** Qoraqalpog'iston Respublikasi (166.6 ming kv.km).\n• **Eng yuqori iqtisodiy ulush:** Toshkent shahri (YaIMning 17.5% qismi).\n• **Sanoat markazi:** Navoiy viloyati (o'rtacha ish haqi 6.8 mln so'm).",
        links: [
          { title: "Hududlar interaktiv xaritasi", hash: "#hududlar" },
        ],
      };
    }

    if (
      q.includes('xalqaro') ||
      q.includes('xitoy') ||
      q.includes('hindiston') ||
      q.includes('rossiya') ||
      q.includes('aqsh') ||
      q.includes('amerika') ||
      q.includes('taqqos') ||
      q.includes('dunyo') ||
      q.includes('global')
    ) {
      return {
        text: "🌐 **Xalqaro Ma'lumotlar va Global Taqqoslash:**\n\n• **Hindiston:** 1.43 mlrd aholi, $3.94 trln YaIM, $200+ mlrd IT xizmatlari eksporti.\n• **Xitoy:** $18.53 trln YaIM, $3.38 trln eksport, jahon sanoatining 31.6% ulushi.\n• **Rossiya:** 17.1 mln km² yer maydoni (№1), Neft/gaz zaxiralari, 144.2 mln aholi.\n• **AQSh:** $28.78 trln YaIM (№1), $885 mlrd R&D/AI sarmoyasi, $85,370 jon boshiga YaIM.\n• **O'zbekiston:** 37.6 mln aholi, +6.2% o'sish sur'ati bilan mintaqada eng jadal rivojlanayotgan iqtisodiyotlardan biri.\n\nBarcha ko'rsatkichlar **Jahon Banki (World Bank Open Data API)** orqali avtomatik yangilanadi.",
        links: [
          { title: "Xalqaro Hub va Taqqoslash Asbobi", hash: "#xalqaro" },
          { title: "O'zbekiston YaIM ko'rsatkichi", hash: "#statistika/yaim-hajmi" },
        ],
      };
    }

    // Default intelligent recommendation
    return {
      text: `Savolingiz uchun tashakkur! O'zbekistonning rasmiy davlat statistikasi hamda global ma'lumotlar markazimizda batafsil tahlillar mavjud.\n\nSizni quyidagi mavzulardan qaysi biri ko'proq qiziqtiradi?`,
      links: [
        { title: "Xalqaro Ma'lumotlar & Taqqoslash", hash: "#xalqaro" },
        { title: "Aholi va Demografiya", hash: "#statistika/aholi-soni" },
        { title: "YaIM va Iqtisodiyot", hash: "#statistika/yaim-hajmi" },
        { title: "Interaktiv Statistika Studiyasi", hash: "#interaktiv" },
        { title: "Statistika Viktorinasi (Quiz)", hash: "#quiz" },
      ],
    };
  };

  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text) return;

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate AI thinking and typing response
    setTimeout(() => {
      const reply = generateBotReply(text);
      const botMsg: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: reply.text,
        timestamp: new Date().toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' }),
        links: reply.links,
      };
      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, 850);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleLinkClick = (hash: string) => {
    window.location.hash = hash;
    if (onNavigateHash) onNavigateHash(hash);
  };

  return (
    <>
      {/* Floating Trigger Button (Bottom Right) */}
      {!isOpen && (
        <div className="fixed bottom-6 right-6 z-50 animate-in zoom-in-95 duration-200">
          <button
            onClick={() => setIsOpen(true)}
            className="group relative flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-teal-500 via-teal-600 to-lime-500 hover:from-teal-600 hover:to-lime-600 text-slate-950 font-bold text-xs sm:text-sm shadow-2xl shadow-teal-500/40 border border-lime-300/60 hover:scale-105 transition-all duration-200 cursor-pointer"
            title="UzData AI Chatbot - Savol bering"
          >
            <div className="w-6 h-6 rounded-full bg-slate-950 text-lime-400 flex items-center justify-center shrink-0">
              <Sparkles size={14} className="animate-pulse" />
            </div>
            <span className="font-extrabold tracking-tight">UzData AI</span>
            <span className="w-2 h-2 rounded-full bg-lime-950 animate-ping absolute -top-0.5 -right-0.5" />
          </button>
        </div>
      )}

      {/* Modern Chat Dialog Modal (ChatGPT / Gemini style) */}
      {isOpen && (
        <div className="fixed bottom-4 sm:bottom-6 right-2 sm:right-6 z-50 w-[95vw] sm:w-[420px] max-h-[620px] h-[85vh] bg-white/95 dark:bg-[#071120]/95 backdrop-blur-2xl border border-teal-500/30 dark:border-lime-500/30 rounded-3xl shadow-2xl shadow-slate-950/40 flex flex-col overflow-hidden animate-in zoom-in-95 slide-in-from-bottom-4 duration-200">
          {/* Header Bar */}
          <div className="px-4 py-3.5 bg-gradient-to-r from-teal-900 via-slate-900 to-slate-950 text-white flex items-center justify-between border-b border-teal-500/30">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-teal-500 to-lime-400 p-0.5">
                <div className="w-full h-full rounded-[10px] bg-slate-950 flex items-center justify-center text-lime-400">
                  <Bot size={16} />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="font-bold text-xs sm:text-sm tracking-tight text-white">
                    UzData AI Yordamchi
                  </h3>
                  <span className="w-2 h-2 rounded-full bg-lime-400 animate-pulse" />
                </div>
                <p className="text-[10px] text-teal-300">
                  Rasmiy davlat statistikasi bazasi
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setMessages([initialWelcomeMessage])}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
                title="Chatni yangilash"
              >
                <RotateCcw size={14} />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
                title="Yopish"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'bot' && (
                  <div className="w-6 h-6 rounded-lg bg-teal-500/20 text-teal-600 dark:text-lime-400 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                    AI
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-3 sm:p-3.5 shadow-xs relative group ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-r from-teal-600 to-teal-500 text-white rounded-br-none'
                      : 'bg-slate-100 dark:bg-slate-900/90 text-slate-900 dark:text-slate-100 border border-slate-200/80 dark:border-slate-800 rounded-bl-none'
                  }`}
                >
                  <p className="whitespace-pre-line leading-relaxed text-[11px] sm:text-xs">
                    {msg.text}
                  </p>

                  {/* Suggestion Chips */}
                  {msg.suggestions && msg.suggestions.length > 0 && (
                    <div className="mt-3 pt-2 border-t border-slate-200/60 dark:border-slate-800/80 space-y-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                        Tezkor savollar:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {msg.suggestions.map((sug, sIdx) => (
                          <button
                            key={sIdx}
                            onClick={() => handleSendMessage(sug)}
                            className="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-800 hover:bg-teal-50 dark:hover:bg-slate-700 text-teal-700 dark:text-lime-300 border border-teal-500/30 text-[10px] font-semibold transition cursor-pointer text-left"
                          >
                            {sug}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Navigation Links */}
                  {msg.links && msg.links.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-slate-200/60 dark:border-slate-800/80 space-y-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                        Mavzuga oid sahifalar:
                      </span>
                      <div className="space-y-1">
                        {msg.links.map((link, lIdx) => (
                          <button
                            key={lIdx}
                            onClick={() => handleLinkClick(link.hash)}
                            className="w-full text-left flex items-center justify-between p-1.5 rounded-lg bg-teal-500/10 hover:bg-teal-500/20 text-teal-700 dark:text-lime-300 font-semibold text-[11px] transition"
                          >
                            <span>{link.title}</span>
                            <ExternalLink size={11} />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Timestamp & Copy */}
                  <div className="flex items-center justify-between text-[9px] text-slate-400 mt-1 pt-1 opacity-70">
                    <span>{msg.timestamp}</span>
                    <button
                      onClick={() => handleCopy(msg.id, msg.text)}
                      className="opacity-0 group-hover:opacity-100 transition hover:text-white"
                      title="Nusxalash"
                    >
                      {copiedId === msg.id ? <Check size={10} className="text-lime-400" /> : <Copy size={10} />}
                    </button>
                  </div>
                </div>

                {msg.sender === 'user' && (
                  <div className="w-6 h-6 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                    Siz
                  </div>
                )}
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex items-center gap-2 text-slate-400 text-xs pl-8">
                <div className="flex items-center gap-1 px-3 py-2 rounded-2xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-bounce" />
                  <span className="w-1.5 h-1.5 rounded-full bg-lime-400 animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-bounce [animation-delay:0.4s]" />
                </div>
                <span className="text-[10px] font-mono">Tahlil qilinmoqda...</span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Box Footer */}
          <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-950/80">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Savolingizni yozing (masalan: YaIM, aholi, oylik)..."
                className="flex-1 px-3.5 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:border-teal-500 transition"
              />
              <button
                type="submit"
                disabled={!inputMessage.trim() || isTyping}
                className="w-10 h-10 rounded-2xl bg-gradient-to-r from-teal-500 to-lime-500 hover:opacity-95 text-slate-950 flex items-center justify-center font-bold shadow-md transition disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer shrink-0"
              >
                <Send size={15} />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
