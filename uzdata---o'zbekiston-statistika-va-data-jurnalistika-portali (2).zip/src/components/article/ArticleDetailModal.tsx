import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, User, Tag, Share2, Check, Bookmark } from 'lucide-react';
import { Article } from '../../types';
import { CommentSection } from '../common/CommentSection';
import { userService } from '../../services/userService';

interface ArticleDetailModalProps {
  article: Article | null;
  onClose: () => void;
}

export const ArticleDetailModal: React.FC<ArticleDetailModalProps> = ({ article, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);

  useEffect(() => {
    if (article) {
      setIsBookmarked(userService.isBookmarked(article.id));
      // Record recently viewed
      userService.recordView({
        id: article.id,
        type: 'article',
        title: article.title,
        slug: article.slug,
        category: article.category,
      });
    }
  }, [article]);

  if (!article) return null;

  const handleToggleBookmark = () => {
    const next = userService.toggleBookmark(article.id);
    setIsBookmarked(next);
  };

  const handleCopyLink = () => {
    const url = `${window.location.origin}/#maqola/${article.slug}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {article.imageUrl && (
          <div className="relative h-64 sm:h-80 w-full overflow-hidden bg-slate-900">
            <img
              src={article.imageUrl}
              alt={article.title}
              className="w-full h-full object-cover opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent" />
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-900/60 text-white hover:bg-slate-900 transition backdrop-blur-md"
              aria-label="Yopish"
            >
              <X size={18} />
            </button>
          </div>
        )}

        <div className="p-6 sm:p-8 max-h-[75vh] overflow-y-auto">
          {!article.imageUrl && (
            <div className="flex justify-end mb-4">
              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                <X size={20} />
              </button>
            </div>
          )}

          {/* Metadata Bar */}
          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mb-3">
            <span className="px-2.5 py-0.5 rounded-md font-semibold uppercase bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300">
              {article.category}
            </span>
            <span className="flex items-center gap-1">
              <Clock size={13} />
              {article.readingTime}
            </span>
            <span className="flex items-center gap-1">
              <Calendar size={13} />
              {article.createdAt ? new Date(article.createdAt).toLocaleDateString('uz-UZ') : 'Yaqinda'}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mb-4 leading-tight">
            {article.title}
          </h1>

          <div className="flex items-center gap-2 pb-6 border-b border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300">
            <div className="w-7 h-7 rounded-full bg-teal-600 text-white flex items-center justify-center font-bold text-xs">
              <User size={14} />
            </div>
            <div>
              <p className="font-semibold text-slate-900 dark:text-white">{article.author}</p>
              <p className="text-[11px] text-slate-400">Data Jurnalistika Bo'limi</p>
            </div>
          </div>

          {/* Excerpt Lead */}
          {article.excerpt && (
            <div className="my-6 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border-l-4 border-teal-500 text-slate-700 dark:text-slate-300 text-sm font-medium italic">
              {article.excerpt}
            </div>
          )}

          {/* Article Body */}
          <div className="text-sm leading-relaxed text-slate-800 dark:text-slate-200 space-y-4 whitespace-pre-line font-sans">
            {article.content}
          </div>

          {/* Tags */}
          {article.tags && article.tags.length > 0 && (
            <div className="mt-8 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 flex-wrap">
              <Tag size={14} className="text-slate-400" />
              {article.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 text-xs rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}

          {/* Community & Comments */}
          <CommentSection targetId={article.id} targetTitle={article.title} />
        </div>

        {/* Footer actions */}
        <div className="flex items-center justify-between p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80">
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyLink}
              className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition"
            >
              {copied ? <Check size={14} className="text-emerald-500" /> : <Share2 size={14} />}
              <span>{copied ? "Nusxalandi!" : "Ulashish"}</span>
            </button>
            <button
              onClick={handleToggleBookmark}
              className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg transition border ${
                isBookmarked
                  ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30'
                  : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100'
              }`}
            >
              <Bookmark size={14} className={isBookmarked ? 'fill-amber-400 text-amber-400' : ''} />
              <span>{isBookmarked ? 'Saqlangan' : 'Saqlash'}</span>
            </button>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 transition"
          >
            Yopish
          </button>
        </div>
      </div>
    </div>
  );
};
