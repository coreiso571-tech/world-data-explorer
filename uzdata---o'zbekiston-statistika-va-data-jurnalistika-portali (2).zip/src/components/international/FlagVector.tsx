import React from 'react';
import { GlobalCountryCode } from '../../types/international';

interface FlagProps {
  countryCode: GlobalCountryCode;
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const FlagVector: React.FC<FlagProps> = ({
  countryCode,
  className = '',
  size = 'md',
}) => {
  const sizeClasses = {
    sm: 'w-6 h-4',
    md: 'w-8 h-5.5',
    lg: 'w-12 h-8',
    xl: 'w-16 h-11',
  };

  const containerClass = `relative inline-block rounded overflow-hidden shadow-xs border border-black/10 dark:border-white/10 shrink-0 ${sizeClasses[size]} ${className}`;

  switch (countryCode) {
    case 'IND':
      // Flag of India: Saffron, White, Green with Ashoka Chakra (24 spokes) in navy blue
      return (
        <div className={containerClass} title="Hindiston Davlat Bayrog'i">
          <svg viewBox="0 0 90 60" className="w-full h-full object-cover">
            <rect width="90" height="20" fill="#FF9933" />
            <rect y="20" width="90" height="20" fill="#FFFFFF" />
            <rect y="40" width="90" height="20" fill="#138808" />
            {/* Ashoka Chakra */}
            <circle cx="45" cy="30" r="8" fill="none" stroke="#000088" strokeWidth="1.2" />
            <circle cx="45" cy="30" r="1.5" fill="#000088" />
            {Array.from({ length: 24 }).map((_, i) => (
              <line
                key={i}
                x1="45"
                y1="30"
                x2={45 + 7.5 * Math.cos((i * 15 * Math.PI) / 180)}
                y2={30 + 7.5 * Math.sin((i * 15 * Math.PI) / 180)}
                stroke="#000088"
                strokeWidth="0.8"
              />
            ))}
          </svg>
        </div>
      );

    case 'CHN':
      // Flag of China: Red field with 5 yellow stars (1 large, 4 small arcs)
      return (
        <div className={containerClass} title="Xitoy Xalq Respublikasi Bayrog'i">
          <svg viewBox="0 0 90 60" className="w-full h-full object-cover">
            <rect width="90" height="60" fill="#DE2910" />
            {/* Large Star */}
            <polygon
              points="15,6 17.5,13.5 25,13.5 19,18 21.5,25.5 15,21 8.5,25.5 11,18 5,13.5 12.5,13.5"
              fill="#FFDE00"
            />
            {/* Small Stars */}
            <polygon
              points="30,4 30.8,6.5 33.3,6.5 31.3,8 32.1,10.5 30,9 27.9,10.5 28.7,8 26.7,6.5 29.2,6.5"
              fill="#FFDE00"
            />
            <polygon
              points="36,10 36.8,12.5 39.3,12.5 37.3,14 38.1,16.5 36,15 33.9,16.5 34.7,14 32.7,12.5 35.2,12.5"
              fill="#FFDE00"
            />
            <polygon
              points="36,20 36.8,22.5 39.3,22.5 37.3,24 38.1,26.5 36,25 33.9,26.5 34.7,24 32.7,22.5 35.2,22.5"
              fill="#FFDE00"
            />
            <polygon
              points="30,27 30.8,29.5 33.3,29.5 31.3,31 32.1,33.5 30,32 27.9,33.5 28.7,31 26.7,29.5 29.2,29.5"
              fill="#FFDE00"
            />
          </svg>
        </div>
      );

    case 'RUS':
      // Flag of Russia: White, Blue, Red horizontal tricolor
      return (
        <div className={containerClass} title="Rossiya Federatsiyasi Bayrog'i">
          <svg viewBox="0 0 90 60" className="w-full h-full object-cover">
            <rect width="90" height="20" fill="#FFFFFF" />
            <rect y="20" width="90" height="20" fill="#0039A6" />
            <rect y="40" width="90" height="20" fill="#D52B1E" />
          </svg>
        </div>
      );

    case 'USA':
      // Flag of USA: 13 stripes (Red & White), Blue canton with stars
      return (
        <div className={containerClass} title="AQSh (Amerika Qo'shma Shtatlari) Bayrog'i">
          <svg viewBox="0 0 90 60" className="w-full h-full object-cover">
            {/* 13 stripes */}
            {Array.from({ length: 13 }).map((_, i) => (
              <rect
                key={i}
                y={(i * 60) / 13}
                width="90"
                height={60 / 13}
                fill={i % 2 === 0 ? '#B22234' : '#FFFFFF'}
              />
            ))}
            {/* Blue Canton */}
            <rect width="36" height={(7 * 60) / 13} fill="#3C3B6E" />
            {/* White star grid representation */}
            <g fill="#FFFFFF">
              <circle cx="6" cy="6" r="1.2" />
              <circle cx="12" cy="6" r="1.2" />
              <circle cx="18" cy="6" r="1.2" />
              <circle cx="24" cy="6" r="1.2" />
              <circle cx="30" cy="6" r="1.2" />
              <circle cx="9" cy="12" r="1.2" />
              <circle cx="15" cy="12" r="1.2" />
              <circle cx="21" cy="12" r="1.2" />
              <circle cx="27" cy="12" r="1.2" />
              <circle cx="6" cy="18" r="1.2" />
              <circle cx="12" cy="18" r="1.2" />
              <circle cx="18" cy="18" r="1.2" />
              <circle cx="24" cy="18" r="1.2" />
              <circle cx="30" cy="18" r="1.2" />
              <circle cx="9" cy="24" r="1.2" />
              <circle cx="15" cy="24" r="1.2" />
              <circle cx="21" cy="24" r="1.2" />
              <circle cx="27" cy="24" r="1.2" />
            </g>
          </svg>
        </div>
      );

    case 'UZB':
    default:
      // Flag of Uzbekistan: Blue, Red margin, White, Red margin, Green, Crescent + 12 stars
      return (
        <div className={containerClass} title="O'zbekiston Respublikasi Bayrog'i">
          <svg viewBox="0 0 90 60" className="w-full h-full object-cover">
            <rect width="90" height="19" fill="#0099B5" />
            <rect y="19" width="90" height="2" fill="#CE1126" />
            <rect y="21" width="90" height="18" fill="#FFFFFF" />
            <rect y="39" width="90" height="2" fill="#CE1126" />
            <rect y="41" width="90" height="19" fill="#1EB53A" />
            {/* Crescent moon */}
            <circle cx="14" cy="9.5" r="5.5" fill="#FFFFFF" />
            <circle cx="16" cy="9.5" r="4.5" fill="#0099B5" />
            {/* 12 Stars (representation in 3 rows) */}
            <g fill="#FFFFFF">
              {/* Row 1 (3 stars) */}
              <circle cx="23" cy="5" r="0.8" />
              <circle cx="26" cy="5" r="0.8" />
              <circle cx="29" cy="5" r="0.8" />
              {/* Row 2 (4 stars) */}
              <circle cx="20" cy="9.5" r="0.8" />
              <circle cx="23" cy="9.5" r="0.8" />
              <circle cx="26" cy="9.5" r="0.8" />
              <circle cx="29" cy="9.5" r="0.8" />
              {/* Row 3 (5 stars) */}
              <circle cx="17" cy="14" r="0.8" />
              <circle cx="20" cy="14" r="0.8" />
              <circle cx="23" cy="14" r="0.8" />
              <circle cx="26" cy="14" r="0.8" />
              <circle cx="29" cy="14" r="0.8" />
            </g>
          </svg>
        </div>
      );
  }
};
