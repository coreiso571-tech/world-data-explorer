import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
  Legend,
} from 'recharts';
import {
  ArrowLeftRight,
  BarChart3,
  Table as TableIcon,
  TrendingUp,
  Globe2,
  Download,
  Info,
  Check,
  ChevronRight,
  Scale,
  Sparkles,
} from 'lucide-react';
import {
  CountryGlobalData,
  ComparisonMetricKey,
  ComparisonMetricDef,
  GlobalCountryCode,
} from '../../types/international';
import { COMPARISON_METRICS } from '../../data/internationalData';
import { FlagVector } from './FlagVector';

interface ComparisonToolProps {
  countries: CountryGlobalData[];
  selectedCompareCountryCode?: GlobalCountryCode;
}

export const InternationalComparisonTool: React.FC<ComparisonToolProps> = ({
  countries,
  selectedCompareCountryCode = 'IND',
}) => {
  // Modes: 'head-to-head' | 'chart' | 'matrix'
  const [viewMode, setViewMode] = useState<'head-to-head' | 'chart' | 'matrix'>('head-to-head');
  const [targetCountryCode, setTargetCountryCode] = useState<GlobalCountryCode>(
    selectedCompareCountryCode === 'UZB' ? 'IND' : selectedCompareCountryCode
  );
  const [activeMetricKey, setActiveMetricKey] = useState<ComparisonMetricKey>('population');

  const uzbCountry = useMemo(() => countries.find((c) => c.code === 'UZB') || countries[4], [countries]);
  const targetCountry = useMemo(
    () => countries.find((c) => c.code === targetCountryCode) || countries[0],
    [countries, targetCountryCode]
  );
  const activeMetricDef = useMemo(
    () => COMPARISON_METRICS.find((m) => m.key === activeMetricKey) || COMPARISON_METRICS[0],
    [activeMetricKey]
  );

  // Helper to extract numeric value by metric key
  const getMetricNumericValue = (c: CountryGlobalData, key: ComparisonMetricKey): number => {
    switch (key) {
      case 'population':
        return c.metrics.populationMillion;
      case 'gdpNominal':
        return c.metrics.gdpNominalBillion;
      case 'gdpPerCapita':
        return c.metrics.gdpPerCapitaUsd;
      case 'gdpGrowth':
        return c.metrics.gdpGrowthRate;
      case 'area':
        return c.metrics.areaThousandSqKm;
      case 'exports':
        return c.metrics.exportsBillion;
      case 'techScore':
        return c.metrics.techScore;
      default:
        return 0;
    }
  };

  // Chart data for all countries for the selected metric
  const chartData = useMemo(() => {
    return countries.map((c) => ({
      name: c.name,
      code: c.code,
      value: getMetricNumericValue(c, activeMetricKey),
      isUzb: c.code === 'UZB',
      accentColor: c.accentColor,
    }));
  }, [countries, activeMetricKey]);

  // Export comparison table to CSV
  const handleExportCSV = () => {
    const headers = ['Ko\'rsatkich', 'Birlik', ...countries.map((c) => c.name)];
    const rows = COMPARISON_METRICS.map((m) => {
      const row = [m.label, m.unit];
      countries.forEach((c) => {
        row.push(m.formatValue(getMetricNumericValue(c, m.key)));
      });
      return row.join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `UZDATA_Xalqaro_Taqqoslash_${activeMetricKey}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Compare ratio generator for head-to-head
  const getComparisonRatioInsight = (
    uzbVal: number,
    otherVal: number,
    metricDef: ComparisonMetricDef,
    otherName: string
  ) => {
    if (uzbVal === 0 || otherVal === 0) return null;

    if (metricDef.key === 'gdpGrowth') {
      const diff = (uzbVal - otherVal).toFixed(1);
      if (uzbVal > otherVal) {
        return `O'zbekiston o'sish sur'ati (+${uzbVal}%) ${otherName} (+${otherVal}%) dan ${diff}% ga yuqoriroq!`;
      }
      return `${otherName} o'sish sur'ati O'zbekistondan ${Math.abs(Number(diff))}% ga farq qiladi.`;
    }

    if (otherVal > uzbVal) {
      const ratio = (otherVal / uzbVal).toFixed(1);
      return `${otherName} ko'rsatkichi O'zbekistondan ${ratio} barobar ko'proq.`;
    } else {
      const ratio = (uzbVal / otherVal).toFixed(1);
      return `O'zbekiston ko'rsatkichi ${otherName}dan ${ratio} barobar yuqori.`;
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm">
      {/* Header bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-lime-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Scale size={14} className="text-teal-600 dark:text-lime-400" />
            Interaktiv Taqqoslash Markazi
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            O'zbekiston va Dunyo Yetakchilari
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
            Aholi, YaIM, yillik iqtisodiy o'sish, yer maydoni va yuqori texnologiyalar bo'yicha Hindiston, Xitoy, Rossiya va AQSh bilan qiyosiy tahlil.
          </p>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center bg-slate-100 dark:bg-slate-800/90 p-1 rounded-2xl border border-slate-200 dark:border-slate-700 self-start lg:self-auto text-xs font-semibold">
          <button
            onClick={() => setViewMode('head-to-head')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl transition ${
              viewMode === 'head-to-head'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-lime-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <ArrowLeftRight size={14} />
            <span>Yuzma-yuz Taqqoslash</span>
          </button>
          <button
            onClick={() => setViewMode('chart')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl transition ${
              viewMode === 'chart'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-lime-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <BarChart3 size={14} />
            <span>Grafik Tahlil</span>
          </button>
          <button
            onClick={() => setViewMode('matrix')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl transition ${
              viewMode === 'matrix'
                ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-lime-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <TableIcon size={14} />
            <span>To'liq Matritsa</span>
          </button>
        </div>
      </div>

      {/* MODE 1: HEAD-TO-HEAD COMPARISON */}
      {viewMode === 'head-to-head' && (
        <div className="mt-6 space-y-6">
          {/* Target Country Selector Tabs */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-wider">
              O'zbekiston bilan taqqoslash uchun davlatni tanlang:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
              {countries
                .filter((c) => c.code !== 'UZB')
                .map((c) => {
                  const isActive = targetCountryCode === c.code;
                  return (
                    <button
                      key={c.code}
                      onClick={() => setTargetCountryCode(c.code)}
                      className={`p-3 rounded-2xl border text-left transition flex items-center justify-between gap-2 ${
                        isActive
                          ? 'bg-teal-50/80 dark:bg-teal-950/40 border-teal-500 dark:border-lime-400/80 ring-2 ring-teal-500/20'
                          : 'bg-slate-50 dark:bg-slate-950/50 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <FlagVector countryCode={c.code} size="sm" />
                        <div>
                          <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                            {c.name}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            {c.metrics.populationStr}
                          </div>
                        </div>
                      </div>
                      {isActive && <Check size={16} className="text-teal-600 dark:text-lime-400 shrink-0" />}
                    </button>
                  );
                })}
            </div>
          </div>

          {/* Versus Header Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* O'zbekiston Side */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-teal-950/30 to-slate-900 border-2 border-teal-500/50 shadow-md">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <FlagVector countryCode="UZB" size="md" />
                  <div>
                    <h3 className="text-lg font-black text-white tracking-tight">O'zbekiston</h3>
                    <p className="text-xs text-teal-300 font-medium">Boshlang'ich Milliy Standart</p>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-teal-500/20 text-lime-300 border border-teal-500/30">
                  UZB
                </span>
              </div>
              <p className="text-xs text-slate-300 line-clamp-2">
                {uzbCountry.focusDescription}
              </p>
            </div>

            {/* Target Selected Country Side */}
            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <FlagVector countryCode={targetCountry.code} size="md" />
                  <div>
                    <h3 className="text-lg font-black text-slate-900 dark:text-white tracking-tight">
                      {targetCountry.name}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                      Poytaxt: {targetCountry.capital} ({targetCountry.englishName})
                    </p>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700">
                  {targetCountry.code}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                {targetCountry.focusDescription}
              </p>
            </div>
          </div>

          {/* Metric Comparison Table with Proportional Visual Bars */}
          <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden divide-y divide-slate-200 dark:divide-slate-800">
            {COMPARISON_METRICS.map((metric) => {
              const uzbVal = getMetricNumericValue(uzbCountry, metric.key);
              const targetVal = getMetricNumericValue(targetCountry, metric.key);
              const maxVal = Math.max(uzbVal, targetVal, 0.01);
              const uzbBarPercent = Math.min(100, Math.max(5, (uzbVal / maxVal) * 100));
              const targetBarPercent = Math.min(100, Math.max(5, (targetVal / maxVal) * 100));
              const insight = getComparisonRatioInsight(uzbVal, targetVal, metric, targetCountry.name);

              return (
                <div key={metric.key} className="p-4 sm:p-5 hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-2">
                    <div>
                      <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                        {metric.label}
                      </span>
                      <span className="text-[11px] text-slate-400 ml-2">({metric.unit})</span>
                    </div>
                    {insight && (
                      <span className="text-[11px] font-mono text-teal-600 dark:text-lime-400 font-medium">
                        {insight}
                      </span>
                    )}
                  </div>

                  {/* 2 Comparative Bars */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                    {/* Uzbekistan Value */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-teal-700 dark:text-teal-400 flex items-center gap-1.5">
                          <FlagVector countryCode="UZB" size="sm" />
                          <span>O'zbekiston</span>
                        </span>
                        <span className="font-mono font-extrabold text-slate-900 dark:text-white">
                          {metric.formatValue(uzbVal)}
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-teal-500 to-lime-400 h-full rounded-full transition-all duration-500"
                          style={{ width: `${uzbBarPercent}%` }}
                        />
                      </div>
                    </div>

                    {/* Target Country Value */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                          <FlagVector countryCode={targetCountry.code} size="sm" />
                          <span>{targetCountry.name}</span>
                        </span>
                        <span className="font-mono font-extrabold text-slate-900 dark:text-white">
                          {metric.formatValue(targetVal)}
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${targetBarPercent}%`,
                            backgroundColor: targetCountry.accentColor,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MODE 2: CHART COMPARISON */}
      {viewMode === 'chart' && (
        <div className="mt-6 space-y-6">
          {/* Metric Selector Pills */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-wider">
              Taqqoslash ko'rsatkichini tanlang:
            </label>
            <div className="flex flex-wrap gap-2">
              {COMPARISON_METRICS.map((metric) => (
                <button
                  key={metric.key}
                  onClick={() => setActiveMetricKey(metric.key)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                    activeMetricKey === metric.key
                      ? 'bg-teal-600 dark:bg-lime-400 text-white dark:text-slate-950 shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {metric.shortLabel}
                </button>
              ))}
            </div>
          </div>

          {/* Active Metric Description */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs">
              <Info size={15} className="text-teal-600 dark:text-lime-400 shrink-0" />
              <span className="font-medium text-slate-700 dark:text-slate-300">
                {activeMetricDef.label}: <span className="text-slate-500 dark:text-slate-400">{activeMetricDef.description}</span>
              </span>
            </div>
            <span className="text-xs font-mono font-bold text-teal-600 dark:text-lime-400">
              Birlik: {activeMetricDef.unit}
            </span>
          </div>

          {/* Recharts Bar Chart */}
          <div className="h-80 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 10, bottom: 25 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 12, fill: 'currentColor' }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: 'currentColor' }}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="p-3 bg-slate-900 text-white rounded-xl shadow-xl border border-slate-700 text-xs font-sans">
                          <div className="font-bold flex items-center gap-1.5 mb-1">
                            <FlagVector countryCode={data.code} size="sm" />
                            <span>{data.name}</span>
                            {data.isUzb && (
                              <span className="text-[10px] text-lime-400 font-mono">(O'zbekiston)</span>
                            )}
                          </div>
                          <div className="text-lime-300 font-mono font-bold text-sm">
                            {activeMetricDef.formatValue(data.value)}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.isUzb ? '#10b981' : entry.accentColor}
                      stroke={entry.isUzb ? '#a3e635' : 'none'}
                      strokeWidth={entry.isUzb ? 2 : 0}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Ranking summary list */}
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 pt-2">
            {[...chartData]
              .sort((a, b) => b.value - a.value)
              .map((item, idx) => (
                <div
                  key={item.code}
                  className={`p-3 rounded-xl border text-center ${
                    item.isUzb
                      ? 'bg-teal-50 dark:bg-teal-950/40 border-teal-500/70 text-teal-900 dark:text-lime-300'
                      : 'bg-slate-50 dark:bg-slate-950/40 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="text-[10px] font-mono text-slate-400 uppercase">
                    №{idx + 1}-o'rin
                  </div>
                  <div className="font-bold text-xs mt-0.5 flex items-center justify-center gap-1.5">
                    <FlagVector countryCode={item.code} size="sm" />
                    <span>{item.name}</span>
                  </div>
                  <div className="text-sm font-extrabold font-mono mt-1">
                    {activeMetricDef.formatValue(item.value)}
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* MODE 3: FULL COMPARATIVE MATRIX TABLE */}
      {viewMode === 'matrix' && (
        <div className="mt-6 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              Barcha 5 ta davlat ko'rsatkichlarining to'liq qiyosiy jadvali
            </span>
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition"
            >
              <Download size={13} />
              <span>CSV yuklab olish</span>
            </button>
          </div>

          <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-2xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 uppercase font-mono tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-bold">Ko'rsatkich</th>
                  <th className="py-3 px-4 font-bold">Birlik</th>
                  {countries.map((c) => (
                    <th
                      key={c.code}
                      className={`py-3 px-4 font-bold ${
                        c.code === 'UZB'
                          ? 'bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-lime-300'
                          : ''
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <FlagVector countryCode={c.code} size="sm" />
                        <span>{c.name}</span>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 font-medium">
                {COMPARISON_METRICS.map((metric) => (
                  <tr
                    key={metric.key}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">
                      {metric.label}
                    </td>
                    <td className="py-3 px-4 text-slate-400 font-mono">{metric.unit}</td>
                    {countries.map((c) => {
                      const val = getMetricNumericValue(c, metric.key);
                      const isUzb = c.code === 'UZB';
                      return (
                        <td
                          key={c.code}
                          className={`py-3 px-4 font-mono font-bold ${
                            isUzb
                              ? 'bg-teal-50/50 dark:bg-teal-950/30 text-teal-700 dark:text-lime-300'
                              : 'text-slate-700 dark:text-slate-200'
                          }`}
                        >
                          {metric.formatValue(val)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
