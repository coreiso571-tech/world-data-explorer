import React from 'react';
import {
  Users,
  TrendingUp,
  DollarSign,
  Cpu,
  MapPin,
  ArrowUpRight,
  Flame,
  Globe2,
  ExternalLink,
  Layers,
  Sparkles,
} from 'lucide-react';
import { CountryGlobalData, KeyStatItem } from '../../types/international';
import { FlagVector } from './FlagVector';

interface CountryCardProps {
  country: CountryGlobalData;
  isSelected?: boolean;
  onSelectForComparison?: (country: CountryGlobalData) => void;
  onViewDetails?: (country: CountryGlobalData) => void;
}

export const CountryCard: React.FC<CountryCardProps> = ({
  country,
  isSelected = false,
  onSelectForComparison,
  onViewDetails,
}) => {
  const getCategoryIcon = (category: KeyStatItem['category']) => {
    switch (category) {
      case 'demografiya':
        return <Users size={13} className="text-sky-500" />;
      case 'iqtisodiyot':
        return <DollarSign size={13} className="text-emerald-500" />;
      case 'texnologiya':
        return <Cpu size={13} className="text-purple-500" />;
      case 'hudud':
        return <MapPin size={13} className="text-amber-500" />;
      case 'eksport':
        return <TrendingUp size={13} className="text-blue-500" />;
      case 'energetika':
        return <Flame size={13} className="text-orange-500" />;
      default:
        return <Sparkles size={13} className="text-teal-500" />;
    }
  };

  const isUzbekistan = country.code === 'UZB';

  return (
    <div
      className={`group relative rounded-2xl transition-all duration-300 p-5 flex flex-col justify-between overflow-hidden ${
        isUzbekistan
          ? 'bg-gradient-to-b from-teal-950/40 via-slate-900 to-slate-900 border-2 border-teal-500/60 shadow-lg shadow-teal-500/10 dark:shadow-teal-950/50'
          : isSelected
          ? 'bg-white dark:bg-slate-900 border-2 border-lime-500 shadow-md shadow-lime-500/10'
          : 'bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm border border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 hover:shadow-md'
      }`}
    >
      {/* Background soft ambient gradient */}
      <div
        className={`absolute -top-24 -right-24 w-48 h-48 rounded-full blur-3xl opacity-20 pointer-events-none transition-opacity group-hover:opacity-35`}
        style={{ backgroundColor: country.accentColor }}
      />

      <div>
        {/* Card Header: Flag + Name + Code Badge */}
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <FlagVector countryCode={country.code} size="lg" />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-extrabold text-slate-900 dark:text-white tracking-tight">
                  {country.name}
                </h3>
                {isUzbekistan && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-600 dark:text-lime-300 font-bold border border-teal-500/30">
                    O'zbekiston (Baza)
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Poytaxt: <span className="text-slate-700 dark:text-slate-300">{country.capital}</span> ({country.englishName})
              </p>
            </div>
          </div>

          <span
            className="text-xs font-mono font-bold px-2 py-1 rounded-lg border bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"
            title={`ISO kodi: ${country.code}`}
          >
            {country.code}
          </span>
        </div>

        {/* Top 3 Key Statistics - Distinct Display */}
        <div className="mb-4">
          <div className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 flex items-center justify-between">
            <span>3 Ta Asosiy Ko'rsatkich</span>
            <span className="text-[10px] text-teal-600 dark:text-teal-400 font-mono">Rasmiy</span>
          </div>

          <div className="space-y-2">
            {country.top3Stats.map((stat) => (
              <div
                key={stat.id}
                className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/70 dark:border-slate-800/80 hover:bg-slate-100/70 dark:hover:bg-slate-800/50 transition-colors"
              >
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5 font-medium">
                    {getCategoryIcon(stat.category)}
                    {stat.label}
                  </span>
                  {stat.trend && (
                    <span
                      className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded ${
                        stat.isPositive
                          ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                          : 'bg-slate-500/10 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {stat.trend}
                    </span>
                  )}
                </div>

                <div className="flex items-baseline justify-between">
                  <span className="text-base font-extrabold font-mono text-slate-900 dark:text-white tracking-tight">
                    {stat.value}
                  </span>
                  <span className="text-[10px] text-slate-400 font-sans truncate max-w-[140px] text-right" title={stat.note}>
                    {stat.note}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Focus sector chips */}
        <div className="mb-4">
          <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1.5 line-clamp-2">
            {country.focusDescription}
          </p>
          <div className="flex flex-wrap gap-1 mt-2">
            {country.highlightSectors.slice(0, 3).map((sector, idx) => (
              <span
                key={idx}
                className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-medium"
              >
                {sector}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="pt-3 border-t border-slate-200/80 dark:border-slate-800 flex items-center gap-2">
        {onSelectForComparison && !isUzbekistan && (
          <button
            onClick={() => onSelectForComparison(country)}
            className={`flex-1 text-xs font-semibold py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
              isSelected
                ? 'bg-lime-500 text-slate-950 hover:bg-lime-400'
                : 'bg-teal-600/10 dark:bg-teal-500/15 text-teal-700 dark:text-lime-300 hover:bg-teal-600 hover:text-white dark:hover:bg-lime-400 dark:hover:text-slate-950'
            }`}
          >
            <TrendingUp size={13} />
            <span>{isSelected ? "Taqqoslanmoqda ✓" : "O'zbekiston bilan taqqoslash"}</span>
          </button>
        )}

        {isUzbekistan && (
          <div className="flex-1 py-1.5 text-center text-xs font-semibold text-teal-600 dark:text-lime-400 bg-teal-500/10 rounded-xl">
            Asosiy Qiyosiy Baza
          </div>
        )}

        {onViewDetails && (
          <button
            onClick={() => onViewDetails(country)}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title="Batafsil ma'lumot"
          >
            <ExternalLink size={15} />
          </button>
        )}
      </div>
    </div>
  );
};
