import React, { useState, useEffect } from 'react';
import {
  Globe,
  RefreshCw,
  Scale,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  Building2,
  Cpu,
  Flame,
  Users,
  MapPin,
  ArrowLeft,
  ExternalLink,
  CheckCircle2,
  BarChart2,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { CountryGlobalData, GlobalCountryCode } from '../../types/international';
import { internationalDataService } from '../../services/internationalDataService';
import { INITIAL_COUNTRIES_DATA } from '../../data/internationalData';
import { CountryCard } from './CountryCard';
import { InternationalComparisonTool } from './InternationalComparisonTool';
import { FlagVector } from './FlagVector';

interface InternationalHubProps {
  onBackToHome: () => void;
  onSelectStat?: (stat: any) => void;
}

export const InternationalHub: React.FC<InternationalHubProps> = ({
  onBackToHome,
}) => {
  const [countries, setCountries] = useState<CountryGlobalData[]>(INITIAL_COUNTRIES_DATA);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const [sourceName, setSourceName] = useState<string>('Jahon Banki (World Bank Open Data API)');
  const [isLive, setIsLive] = useState(true);
  const [activeCompareCountry, setActiveCompareCountry] = useState<GlobalCountryCode>('IND');
  const [detailModalCountry, setDetailModalCountry] = useState<CountryGlobalData | null>(null);
  const [refreshSuccessMessage, setRefreshSuccessMessage] = useState<string | null>(null);

  // Load data on mount
  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      setLoading(true);
      try {
        const res = await internationalDataService.getCountriesData(false);
        if (isMounted) {
          setCountries(res.data);
          setLastUpdated(res.lastUpdated);
          setSourceName(res.sourceName);
          setIsLive(res.isLive);
        }
      } catch (e) {
        console.error('Error loading international data:', e);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, []);

  // Manual refresh handler
  const handleRefresh = async () => {
    setRefreshing(true);
    setRefreshSuccessMessage(null);
    try {
      const res = await internationalDataService.getCountriesData(true);
      setCountries(res.data);
      setLastUpdated(res.lastUpdated);
      setSourceName(res.sourceName);
      setIsLive(true);
      setRefreshSuccessMessage("Jahon Banki ko'rsatkichlari muvaffaqiyatli yangilandi!");
      setTimeout(() => setRefreshSuccessMessage(null), 4000);
    } catch (e) {
      console.error('Refresh error:', e);
    } finally {
      setRefreshing(false);
    }
  };

  const handleSelectForComparison = (country: CountryGlobalData) => {
    setActiveCompareCountry(country.code);
    const comparisonElem = document.getElementById('taqqoslash-asbobi');
    if (comparisonElem) {
      comparisonElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300">
      {/* Back button and breadcrumb */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBackToHome}
          className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-teal-600 dark:hover:text-lime-400 transition cursor-pointer"
        >
          <ArrowLeft size={16} />
          <span>Bosh Sahifaga Qaytish</span>
        </button>

        {/* Live Data Sync Badge & Refresh */}
        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-mono font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Jonli API Sinxronizatsiyasi</span>
          </div>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition cursor-pointer disabled:opacity-50"
            title="World Bank API orqali yangilash"
          >
            <RefreshCw size={13} className={refreshing ? 'animate-spin text-teal-500' : ''} />
            <span>{refreshing ? 'Yangilanmoqda...' : 'Yangilash'}</span>
          </button>
        </div>
      </div>

      {/* Success Notification */}
      {refreshSuccessMessage && (
        <div className="mb-6 p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 text-xs sm:text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
            <span className="font-medium">{refreshSuccessMessage}</span>
          </div>
          <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400">
            {lastUpdated}
          </span>
        </div>
      )}

      {/* Hero Banner with Glassmorphism */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-teal-950 border border-slate-800 p-6 sm:p-10 mb-10 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-lime-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-lime-300 border border-teal-500/30 text-xs font-mono font-bold uppercase tracking-wider mb-3">
            <Globe size={13} className="text-lime-400" />
            <span>Xalqaro Ma'lumotlar Markazi</span>
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
            Global Davlatlar Statistikasi &{' '}
            <span className="bg-gradient-to-r from-teal-400 via-lime-400 to-emerald-400 bg-clip-text text-transparent">
              O'zbekiston Qiyosi
            </span>
          </h1>

          <p className="mt-3 text-sm sm:text-base text-slate-300 leading-relaxed font-normal">
            Jahon iqtisodiyotining 4 ta yetakchi davlati — <strong>Hindiston</strong> (Aholi, Iqtisodiyot, Texnologiya), <strong>Xitoy</strong> (YaIM, Eksport, Sanoat), <strong>Rossiya</strong> (Maydon, Energetika, Demografiya) va <strong>AQSh</strong> (Iqtisodiyot, Texnologiya) bo'yicha tasdiqlangan rasmiy ko'rsatkichlar hamda O'zbekiston bilan interaktiv taqqoslash.
          </p>

          {/* Data Source & Credibility Tag */}
          <div className="mt-6 flex flex-wrap items-center gap-3 pt-4 border-t border-slate-800 text-xs text-slate-400">
            <div className="flex items-center gap-1.5 font-medium text-slate-300">
              <ShieldCheck size={15} className="text-teal-400" />
              <span>Manba:</span>
              <span className="text-white font-semibold">{sourceName}</span>
            </div>
            <span className="text-slate-600">•</span>
            <div>
              Oxirgi tekshiruv:{' '}
              <span className="font-mono text-teal-300">{lastUpdated || "2024-2025 hisobot davri"}</span>
            </div>
            <span className="text-slate-600">•</span>
            <div className="text-slate-400">
              Avtomatik yangilanuvchi ochiq API protokoli
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 1: Country Cards Grid */}
      <section className="mb-12">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <span>Davlatlar Kartalari va Asosiy Ko'rsatkichlar</span>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                5 Ta Davlat
              </span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Har bir davlat bayrog'i, uning 3 ta asosiy ustuvor ko'rsatkichi va yetakchi sohalari.
            </p>
          </div>

          <a
            href="#taqqoslash-asbobi"
            className="text-xs font-semibold text-teal-600 dark:text-lime-400 hover:underline flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Taqqoslash asbobiga o'tish</span>
            <span>↓</span>
          </a>
        </div>

        {/* 5 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {countries.map((country) => (
            <CountryCard
              key={country.code}
              country={country}
              isSelected={activeCompareCountry === country.code}
              onSelectForComparison={handleSelectForComparison}
              onViewDetails={(c) => setDetailModalCountry(c)}
            />
          ))}
        </div>
      </section>

      {/* SECTION 2: Interactive Comparison Tool */}
      <section id="taqqoslash-asbobi" className="scroll-mt-24 mb-14">
        <InternationalComparisonTool
          countries={countries}
          selectedCompareCountryCode={activeCompareCountry}
        />
      </section>

      {/* SECTION 3: Deep Dive Analysis & Strategic Partnership with Uzbekistan */}
      <section className="bg-slate-100/70 dark:bg-slate-900/60 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 mb-10">
        <div className="mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Building2 size={13} />
            Strategik Hamkorlik & Tahlil
          </div>
          <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            O'zbekistonning Mazkur Davlatlar Bilan Savdo-Iqtisodiy Aloqalari
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Global kuch markazlari bilan mintaqaviy integratsiya, IT kooperatsiya va tashqi savdo muvozanati.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* India Box */}
          <div className="p-4.5 rounded-2xl bg-white dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2 mb-2">
              <FlagVector countryCode="IND" size="sm" />
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Hindiston — IT & Farmatsevtika</h4>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              O'zbekiston va Hindiston o'rtasida IT Park orqali kadrlar tayyorlash, dasturiy ta'minot autsorsingi hamda qo'shma farmatsevtika korxonalari keng yo'lga qo'yilmoqda. Toshkentdagi Amity va Sharda universitetlari bu hamkorlikning yorqin namunasidir.
            </p>
          </div>

          {/* China Box */}
          <div className="p-4.5 rounded-2xl bg-white dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2 mb-2">
              <FlagVector countryCode="CHN" size="sm" />
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Xitoy — Savdo & Yashil Energiya</h4>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Xitoy — O'zbekistonning eng yirik tashqi savdo hamkori ($13+ mlrd savdo aylanmasi). Quyosh va shamol elektr stansiyalari, BYD elektromobillar ishlab chiqarish zavodi va sanoat klasterlari Xitoy texnologiyalari asosida barpo etilmoqda.
            </p>
          </div>

          {/* Russia Box */}
          <div className="p-4.5 rounded-2xl bg-white dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2 mb-2">
              <FlagVector countryCode="RUS" size="sm" />
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Rossiya — Energetika & Logistika</h4>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              O'zbekiston meva-sabzavot va to'qimachilik mahsulotlari uchun eng yirik an'anaviy eksport bozori. Shuningdek, energetika, neft-gaz zaxiralari va sanoat kooperatsiyasi sohasida strategik sherik hisoblanadi.
            </p>
          </div>

          {/* USA Box */}
          <div className="p-4.5 rounded-2xl bg-white dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2 mb-2">
              <FlagVector countryCode="USA" size="sm" />
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">AQSh — Investitsiyalar & Moliya</h4>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              AQShning yetakchi IT kompaniyalari (Apple, Google, Microsoft, Meta) bilan O'zbekiston raqamli bozori aloqalari kengaymoqda. IT Park rezidentlari uchun AQSh eng asosiy eksport manzillaridan biri (jami IT eksportning 40%+ qismi) bo'lib qolmoqda.
            </p>
          </div>
        </div>
      </section>

      {/* Country Detail Modal */}
      {detailModalCountry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4 mb-6">
              <div className="flex items-center gap-3">
                <FlagVector countryCode={detailModalCountry.code} size="lg" />
                <div>
                  <h3 className="text-2xl font-black text-slate-900 dark:text-white">
                    {detailModalCountry.fullName}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                    Poytaxt: {detailModalCountry.capital} | Inglizcha: {detailModalCountry.englishName}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setDetailModalCountry(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                ✕
              </button>
            </div>

            {/* Modal Content */}
            <div className="space-y-5">
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {detailModalCountry.focusDescription}
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Aholi</div>
                  <div className="text-sm font-extrabold text-slate-900 dark:text-white font-mono mt-0.5">
                    {detailModalCountry.metrics.populationStr}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Nominal YaIM</div>
                  <div className="text-sm font-extrabold text-slate-900 dark:text-white font-mono mt-0.5">
                    {detailModalCountry.metrics.gdpNominalStr}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">YaIM / kishi</div>
                  <div className="text-sm font-extrabold text-slate-900 dark:text-white font-mono mt-0.5">
                    {detailModalCountry.metrics.gdpPerCapitaStr}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Yillik o'sish</div>
                  <div className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400 font-mono mt-0.5">
                    +{detailModalCountry.metrics.gdpGrowthRate}%
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Yer maydoni</div>
                  <div className="text-sm font-extrabold text-slate-900 dark:text-white font-mono mt-0.5">
                    {detailModalCountry.metrics.areaStr}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Eksport hajmi</div>
                  <div className="text-sm font-extrabold text-slate-900 dark:text-white font-mono mt-0.5">
                    {detailModalCountry.metrics.exportsStr}
                  </div>
                </div>
              </div>

              {/* Highlight Sectors */}
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-2">
                  Yetakchi Iqtisodiy Sohalar
                </h4>
                <div className="flex flex-wrap gap-2">
                  {detailModalCountry.highlightSectors.map((sector, idx) => (
                    <span
                      key={idx}
                      className="text-xs px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium"
                    >
                      {sector}
                    </span>
                  ))}
                </div>
              </div>

              {/* Data credibility note */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 text-xs text-slate-400 flex items-center justify-between border border-slate-200 dark:border-slate-800">
                <span>Manba: Jahon Banki (World Bank) Open Data API</span>
                <span className="font-mono text-teal-600 dark:text-lime-400 font-semibold">
                  Hisobot davri: {detailModalCountry.worldBankSourceDate || '2024'}
                </span>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3">
              <button
                onClick={() => {
                  handleSelectForComparison(detailModalCountry);
                  setDetailModalCountry(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-teal-600 hover:bg-teal-500 text-white transition flex items-center gap-1.5"
              >
                <Scale size={14} />
                <span>O'zbekiston bilan taqqoslash</span>
              </button>
              <button
                onClick={() => setDetailModalCountry(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
              >
                Yopish
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
