import React from 'react';
import { Sun, Moon } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

interface ThemeToggleSwitchProps {
  className?: string;
  showLabel?: boolean;
}

export const ThemeToggleSwitch: React.FC<ThemeToggleSwitchProps> = ({
  className = '',
  showLabel = false,
}) => {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === 'dark';

  return (
    <div className={`inline-flex items-center gap-2 ${className}`}>
      {showLabel && (
        <span className="text-xs font-medium text-slate-600 dark:text-slate-300">
          {isDark ? "Qorong'i rejim" : "Yorug' rejim"}
        </span>
      )}
      <button
        type="button"
        role="switch"
        aria-checked={isDark}
        aria-label={isDark ? "Yorug' rejimga o'tish" : "Qorong'i rejimga o'tish"}
        onClick={toggleTheme}
        title={isDark ? "Yorug' rejimga o'tish (Hozir: Tungi rejim)" : "Qorong'i rejimga o'tish (Hozir: Kunduzgi rejim)"}
        className="group relative inline-flex h-8 w-15 shrink-0 cursor-pointer items-center rounded-full p-1 transition-all duration-300 focus:outline-hidden focus-visible:ring-2 focus-visible:ring-lime-400 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900 border border-slate-300/80 dark:border-teal-500/40 bg-slate-200/90 dark:bg-slate-900/90 shadow-inner hover:border-teal-500/60 dark:hover:border-lime-400/70"
      >
        {/* Subtle background glow */}
        <span 
          className={`absolute inset-0 rounded-full transition-opacity duration-300 pointer-events-none ${
            isDark 
              ? 'bg-gradient-to-r from-teal-950 via-slate-900 to-lime-950/40 opacity-100' 
              : 'bg-gradient-to-r from-amber-100/60 to-slate-100 opacity-100'
          }`} 
        />

        {/* Ambient static icons on background */}
        <span className="absolute left-1.5 flex items-center justify-center pointer-events-none">
          <Sun 
            size={12} 
            className={`transition-all duration-300 ${
              isDark ? 'text-slate-500 opacity-40 scale-75' : 'text-amber-500 opacity-0 scale-50'
            }`} 
          />
        </span>
        <span className="absolute right-1.5 flex items-center justify-center pointer-events-none">
          <Moon 
            size={12} 
            className={`transition-all duration-300 ${
              isDark ? 'text-lime-400 opacity-0 scale-50' : 'text-slate-400 opacity-50 scale-75'
            }`} 
          />
        </span>

        {/* Sliding Thumb */}
        <span
          className={`relative z-10 flex h-6 w-6 transform items-center justify-center rounded-full shadow-md transition-all duration-300 ease-out ${
            isDark
              ? 'translate-x-7 bg-gradient-to-br from-slate-900 via-teal-950 to-slate-900 text-lime-300 shadow-lime-500/20 border border-lime-400/50'
              : 'translate-x-0 bg-white text-amber-500 shadow-slate-300/70 border border-amber-200/60'
          } group-hover:scale-105 active:scale-95`}
        >
          {isDark ? (
            <Moon 
              size={13} 
              className="transform rotate-0 transition-transform duration-300 text-lime-300 drop-shadow-[0_0_4px_rgba(163,230,53,0.6)]" 
            />
          ) : (
            <Sun 
              size={13} 
              className="transform rotate-0 transition-transform duration-300 text-amber-500 drop-shadow-[0_0_4px_rgba(245,158,11,0.5)]" 
            />
          )}
        </span>
      </button>
    </div>
  );
};
