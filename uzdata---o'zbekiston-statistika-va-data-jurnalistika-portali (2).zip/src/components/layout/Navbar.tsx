import React, { useState } from 'react';
import { 
  Search, 
  Moon, 
  Sun, 
  Shield, 
  Menu, 
  X, 
  BarChart2, 
  LogOut,
  LayoutDashboard,
  User,
  Sparkles,
  Trophy,
  SlidersHorizontal,
  Bookmark,
  Globe
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { ThemeToggleSwitch } from './ThemeToggleSwitch';

export type AppView = 'home' | 'admin' | 'table' | 'interactive' | 'quiz' | 'profile' | 'international';

interface NavbarProps {
  onOpenSearch: () => void;
  onOpenDeveloperModal: () => void;
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenSearch,
  onOpenDeveloperModal,
  currentView,
  setCurrentView,
}) => {
  const { theme, toggleTheme } = useTheme();
  const { user, isAdmin, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-white/90 dark:bg-slate-950/90 border-b border-slate-200/80 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div 
          onClick={() => {
            setCurrentView('home');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-slate-950 dark:bg-white text-white dark:text-slate-950 flex items-center justify-center font-black text-lg tracking-tight shadow-md group-hover:scale-105 transition-transform">
            <span className="text-teal-400 dark:text-teal-600 font-mono">UZ</span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xl font-black tracking-tight text-slate-950 dark:text-white font-mono">
                UZDATA
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300">
                PRO
              </span>
            </div>
            <p className="text-[10px] font-medium text-slate-400 -mt-1 hidden sm:block tracking-wide">
              O'zbekiston Statistika & Data Jurnalistika
            </p>
          </div>
        </div>

        {/* Center Nav Links (Desktop) */}
        <nav className="hidden lg:flex items-center gap-1 text-xs font-semibold text-slate-600 dark:text-slate-300">
          <button
            onClick={() => {
              setCurrentView('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-2.5 py-1.5 rounded-lg transition ${
              currentView === 'home'
                ? 'text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/50'
                : 'hover:text-slate-950 dark:hover:text-white'
            }`}
          >
            Bosh Sahifa
          </button>
          
          {/* Interactive Statistics Link */}
          <button
            onClick={() => {
              setCurrentView('interactive');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-2.5 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
              currentView === 'interactive'
                ? 'text-teal-600 dark:text-lime-400 bg-teal-50 dark:bg-teal-950/60 font-bold'
                : 'hover:text-slate-950 dark:hover:text-white'
            }`}
          >
            <Sparkles size={13} className="text-teal-600 dark:text-lime-400" />
            <span>Interaktiv Statistika</span>
          </button>

          {/* Quiz & Trivia Link */}
          <button
            onClick={() => {
              setCurrentView('quiz');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-2.5 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
              currentView === 'quiz'
                ? 'text-teal-600 dark:text-lime-400 bg-teal-50 dark:bg-teal-950/60 font-bold'
                : 'hover:text-slate-950 dark:hover:text-white'
            }`}
          >
            <Trophy size={13} className="text-amber-500" />
            <span>Viktorinalar</span>
            <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-amber-500/15 text-amber-600 dark:text-amber-400 font-bold">Quiz</span>
          </button>

          {/* International Data Hub Link */}
          <button
            onClick={() => {
              setCurrentView('international');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-2.5 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
              currentView === 'international'
                ? 'text-teal-600 dark:text-lime-400 bg-teal-50 dark:bg-teal-950/60 font-bold'
                : 'hover:text-slate-950 dark:hover:text-white'
            }`}
          >
            <Globe size={13} className="text-teal-600 dark:text-lime-400" />
            <span>Xalqaro</span>
            <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-teal-500/15 text-teal-600 dark:text-lime-400 font-bold">Hub</span>
          </button>

          <button
            onClick={() => setCurrentView('table')}
            className={`px-2.5 py-1.5 rounded-lg transition ${
              currentView === 'table'
                ? 'text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/50'
                : 'hover:text-slate-950 dark:hover:text-white'
            }`}
          >
            Jadval
          </button>

          <a
            href="#kategoriyalar"
            onClick={(e) => {
              if (currentView !== 'home') {
                e.preventDefault();
                setCurrentView('home');
                setTimeout(() => {
                  document.getElementById('kategoriyalar')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }
            }}
            className="px-2.5 py-1.5 rounded-lg hover:text-slate-950 dark:hover:text-white transition"
          >
            Sohalar
          </a>

          <a
            href="#hududlar"
            onClick={(e) => {
              if (currentView !== 'home') {
                e.preventDefault();
                setCurrentView('home');
                setTimeout(() => {
                  document.getElementById('hududlar')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }
            }}
            className="px-2.5 py-1.5 rounded-lg hover:text-slate-950 dark:hover:text-white transition"
          >
            Hududlar (14)
          </a>

          <a
            href="#maqolalar"
            onClick={(e) => {
              if (currentView !== 'home') {
                e.preventDefault();
                setCurrentView('home');
                setTimeout(() => {
                  document.getElementById('maqolalar')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }
            }}
            className="px-2.5 py-1.5 rounded-lg hover:text-slate-950 dark:hover:text-white transition"
          >
            Tahlillar
          </a>
        </nav>

        {/* Right Action Icons */}
        <div className="flex items-center gap-2">
          {/* Quick Search Button */}
          <button
            onClick={onOpenSearch}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/80 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
            title="Qidiruv (⌘K)"
          >
            <Search size={15} />
            <span className="hidden sm:inline font-medium">Qidiruv</span>
            <kbd className="hidden lg:inline text-[10px] font-mono bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700">
              ⌘K
            </kbd>
          </button>

          {/* 'Yaratuvchi haqida' Button */}
          <button
            onClick={onOpenDeveloperModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-teal-500/10 via-lime-500/10 to-emerald-500/10 hover:from-teal-500/20 hover:to-lime-500/20 text-slate-800 dark:text-lime-300 border border-teal-500/30 dark:border-lime-500/40 hover:border-lime-500/70 transition shadow-xs cursor-pointer"
            title="Platforma yaratuvchisi haqida"
          >
            <User size={14} className="text-teal-600 dark:text-lime-400 shrink-0" />
            <span className="font-semibold">Yaratuvchi haqida</span>
          </button>

          {/* Personal Profile Button */}
          <button
            onClick={() => {
              setCurrentView('profile');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
              currentView === 'profile'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
            title="Shaxsiy profil, saqlanganlar va tarix"
          >
            <Bookmark size={14} className={currentView === 'profile' ? 'text-white' : 'text-teal-600 dark:text-lime-400'} />
            <span className="font-semibold">Profil</span>
          </button>

          {/* Dark / Light Toggle Switch */}
          <ThemeToggleSwitch />

          {/* Admin CMS Button */}
          {isAdmin ? (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setCurrentView('admin')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                  currentView === 'admin'
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'bg-slate-900 text-white dark:bg-slate-800 hover:bg-teal-700'
                }`}
              >
                <LayoutDashboard size={14} />
                <span className="hidden sm:inline">Admin CMS</span>
              </button>
              <button
                onClick={logout}
                className="p-2 rounded-xl text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                title="Chiqish"
              >
                <LogOut size={16} />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setCurrentView('admin')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-900 text-white dark:bg-slate-800 dark:text-slate-100 hover:bg-teal-600 dark:hover:bg-teal-600 transition shadow-xs"
            >
              <Shield size={14} className="text-teal-400" />
              <span>Admin</span>
            </button>
          )}

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 md:hidden transition"
            aria-label="Menyu"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 py-4 space-y-2 text-sm font-semibold animate-in slide-in-from-top duration-200">
          <button
            onClick={() => {
              setCurrentView('home');
              setMobileMenuOpen(false);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="w-full text-left py-2 px-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200"
          >
            Bosh Sahifa
          </button>
          <button
            onClick={() => {
              setCurrentView('interactive');
              setMobileMenuOpen(false);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="w-full text-left py-2 px-3 rounded-lg hover:bg-teal-50 dark:hover:bg-teal-950/50 text-teal-700 dark:text-lime-400 font-semibold flex items-center justify-between"
          >
            <span className="flex items-center gap-2">
              <Sparkles size={15} />
              <span>Interaktiv Statistika</span>
            </span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-teal-500/10 text-teal-600 dark:text-lime-400">Yangi</span>
          </button>
          <button
            onClick={() => {
              setCurrentView('quiz');
              setMobileMenuOpen(false);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="w-full text-left py-2 px-3 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-950/50 text-amber-700 dark:text-amber-400 font-semibold flex items-center justify-between"
          >
            <span className="flex items-center gap-2">
              <Trophy size={15} />
              <span>Viktorinalar (Quiz)</span>
            </span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-600 dark:text-amber-400">Live</span>
          </button>
          <button
            onClick={() => {
              setCurrentView('international');
              setMobileMenuOpen(false);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="w-full text-left py-2 px-3 rounded-lg hover:bg-teal-50 dark:hover:bg-teal-950/50 text-teal-700 dark:text-lime-400 font-semibold flex items-center justify-between"
          >
            <span className="flex items-center gap-2">
              <Globe size={15} />
              <span>Xalqaro Ma'lumotlar Hub</span>
            </span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-teal-500/10 text-teal-600 dark:text-lime-400">Global</span>
          </button>
          <a
            href="#daily-essentials"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 px-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200"
          >
            Kundalik (Valyuta, Namoz, AQI)
          </a>
          <a
            href="#ob-havo"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 px-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200"
          >
            Ob-havo & Iqlim
          </a>
          <a
            href="#kategoriyalar"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 px-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200"
          >
            Sohalar
          </a>
          <a
            href="#hududlar"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 px-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200"
          >
            Hududlar (14)
          </a>
          <a
            href="#maqolalar"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 px-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200"
          >
            Tahliliy Maqolalar
          </a>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenDeveloperModal();
            }}
            className="w-full text-left py-2.5 px-3 rounded-xl bg-gradient-to-r from-teal-500/10 via-lime-500/10 to-emerald-500/10 border border-teal-500/30 dark:border-lime-500/40 text-teal-800 dark:text-lime-300 font-semibold flex items-center justify-between"
          >
            <span className="flex items-center gap-2">
              <User size={15} className="text-lime-500" />
              <span>Yaratuvchi haqida (Muhammadiso Akbarov)</span>
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-lime-500/20 text-lime-400">Muallif</span>
          </button>
          <button
            onClick={() => {
              setCurrentView('profile');
              setMobileMenuOpen(false);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="w-full text-left py-2 px-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-teal-700 dark:text-lime-300 font-semibold flex items-center justify-between"
          >
            <span className="flex items-center gap-2">
              <Bookmark size={15} />
              <span>Shaxsiy Profil (Saqlanganlar)</span>
            </span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-teal-500/10">Mening</span>
          </button>
          <button
            onClick={() => {
              setCurrentView('table');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 px-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200"
          >
            Statistika Jadvali
          </button>
          <div className="flex items-center justify-between py-2 px-3 rounded-xl bg-slate-100/80 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              Mavzu rejimi (Theme)
            </span>
            <ThemeToggleSwitch showLabel={false} />
          </div>
          <button
            onClick={() => {
              setCurrentView('admin');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 px-3 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 flex items-center justify-between"
          >
            <span>Admin CMS Portali</span>
            <Shield size={16} />
          </button>
        </div>
      )}
    </header>
  );
};
