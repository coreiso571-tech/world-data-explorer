import React from 'react';
import { ShieldCheck, Database, ExternalLink, Heart } from 'lucide-react';

interface FooterProps {
  onOpenDeveloperModal?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenDeveloperModal }) => {
  return (
    <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-600 dark:text-slate-400 text-xs transition-colors mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand & Mission */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg bg-slate-950 dark:bg-white text-white dark:text-slate-950 flex items-center justify-center font-bold text-sm">
                <span className="text-teal-400 dark:text-teal-600 font-mono">UZ</span>
              </div>
              <span className="text-lg font-black tracking-tight text-slate-950 dark:text-white font-mono">
                UZDATA
              </span>
            </div>
            <p className="text-xs leading-relaxed max-w-md text-slate-500 dark:text-slate-400">
              O'zbekistonning eng ishonchli va keng qamrovli statistik ma'lumotlar, demografik tendensiyalar va data-jurnalistika portali. Biz raqamlar orqali jamiyat, biznes va tadqiqotchilarga to'g'ri qaror qabul qilishda ko'maklashamiz.
            </p>
            <div className="flex items-center gap-2 mt-4 text-[11px] text-teal-600 dark:text-teal-400 font-medium">
              <ShieldCheck size={14} />
              <span>Har bir ko'rsatkich birlamchi davlat reestrlaridan tekshiriladi</span>
            </div>
          </div>

          {/* Rasmiy Manbalar */}
          <div>
            <h4 className="text-slate-900 dark:text-white font-bold mb-3 text-xs uppercase tracking-wider">
              Birlamchi Manbalar
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a
                  href="https://stat.uz"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-teal-600 dark:hover:text-teal-400 flex items-center gap-1 transition"
                >
                  <span>Statistika Agentligi (stat.uz)</span>
                  <ExternalLink size={11} className="opacity-60" />
                </a>
              </li>
              <li>
                <a
                  href="https://cbu.uz"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-teal-600 dark:hover:text-teal-400 flex items-center gap-1 transition"
                >
                  <span>Markaziy Bank (cbu.uz)</span>
                  <ExternalLink size={11} className="opacity-60" />
                </a>
              </li>
              <li>
                <a
                  href="https://digital.uz"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-teal-600 dark:hover:text-teal-400 flex items-center gap-1 transition"
                >
                  <span>Raqamli Texnologiyalar Vazirligi</span>
                  <ExternalLink size={11} className="opacity-60" />
                </a>
              </li>
              <li>
                <a
                  href="https://data.egov.uz"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-teal-600 dark:hover:text-teal-400 flex items-center gap-1 transition"
                >
                  <span>Ochiq Ma'lumotlar Portali</span>
                  <ExternalLink size={11} className="opacity-60" />
                </a>
              </li>
            </ul>
          </div>

          {/* Ochiq Ma'lumotlar Qoidalari */}
          <div>
            <h4 className="text-slate-900 dark:text-white font-bold mb-3 text-xs uppercase tracking-wider">
              Metodologiya & Huquq
            </h4>
            <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400 mb-3">
              UZDATA portali ma'lumotlaridan tahliliy maqolalar, ilmiy izlanishlar va ommaviy axborot vositalarida erkin foydalanish mumkin.
            </p>
            <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 text-[11px] font-mono text-slate-600 dark:text-slate-300">
              <Database size={12} />
              <span>CC BY 4.0 Litsenziyasi</span>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 border-t border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-400">
          <p>© {new Date().getFullYear()} UZDATA. Barcha huquqlar himoyalangan.</p>
          <div className="flex items-center gap-2">
            <span>Muallif:</span>
            {onOpenDeveloperModal ? (
              <button 
                onClick={onOpenDeveloperModal}
                className="text-slate-700 dark:text-slate-200 hover:text-teal-600 dark:hover:text-teal-400 font-semibold transition cursor-pointer underline underline-offset-2"
                title="Yaratuvchi haqida ma'lumot"
              >
                Muhammadiso Akbarov
              </button>
            ) : (
              <span className="text-slate-700 dark:text-slate-200 font-semibold">
                Muhammadiso Akbarov
              </span>
            )}
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <span>Mirzo Ulug'bek nomidagi Muhandislik Maktabi</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
