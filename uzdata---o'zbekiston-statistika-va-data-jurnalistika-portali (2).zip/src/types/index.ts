export type ContentStatus = 'Published' | 'Draft' | 'Unpublished';

export type ChartType = 'line' | 'area' | 'bar' | 'donut' | 'table';

export interface DataPoint {
  label: string; // e.g. "2020", "2021", or "Toshkent sh."
  value: number;
  secondaryValue?: number;
  note?: string;
}

export interface Statistic {
  id: string;
  title: string;
  slug: string;
  category: string; // 'demografiya' | 'iqtisodiyot' | 'talim' | 'it-biznes' | 'turizm' | 'narxlar' | 'hududlar'
  value: string; // e.g. "37.6 mln"
  numericValue?: number;
  unit: string; // e.g. "mln kishi", "mlrd dollar", "%"
  change?: string; // e.g. "+2.1%"
  isPositiveChange?: boolean;
  chartType: ChartType;
  sourceName: string; // e.g. "Statistika Agentligi (stat.uz)"
  sourceUrl: string;
  verificationDate: string; // e.g. "2026-10-15"
  status: ContentStatus;
  description: string;
  imageUrl?: string;
  dataSeries: DataPoint[];
  region?: string;
  featured?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  author: string;
  category: string;
  tags: string[];
  imageUrl?: string;
  readingTime: string;
  status: ContentStatus;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  color: string;
  count?: number;
}

export interface RegionData {
  id: string;
  name: string;
  center: string;
  population: number; // in thousands or millions
  populationStr: string;
  avgSalary: number; // in so'm
  avgSalaryStr: string;
  gdpShare: number; // in percentage
  areaKm2: number;
}

export interface AdminUser {
  uid: string;
  email: string;
  role: 'admin' | 'editor';
  displayName?: string;
  photoURL?: string;
}
