export type GlobalCountryCode = 'UZB' | 'IND' | 'CHN' | 'RUS' | 'USA';

export interface KeyStatItem {
  id: string;
  label: string;
  value: string;
  numericValue: number;
  unit: string;
  trend?: string;
  isPositive?: boolean;
  category: 'demografiya' | 'iqtisodiyot' | 'texnologiya' | 'hudud' | 'eksport' | 'energetika';
  note: string;
}

export interface CountryGlobalData {
  code: GlobalCountryCode;
  name: string;
  fullName: string;
  englishName: string;
  capital: string;
  flagEmoji: string;
  accentColor: string;
  bgGradient: string;
  top3Stats: [KeyStatItem, KeyStatItem, KeyStatItem];
  metrics: {
    populationMillion: number;
    populationStr: string;
    gdpNominalBillion: number;
    gdpNominalStr: string;
    gdpPerCapitaUsd: number;
    gdpPerCapitaStr: string;
    gdpGrowthRate: number; // in %
    areaThousandSqKm: number;
    areaStr: string;
    exportsBillion: number;
    exportsStr: string;
    techScore: number; // 0-100 score or tech metric
    techLabel: string;
  };
  highlightSectors: string[];
  focusDescription: string;
  worldBankSourceDate?: string;
}

export type ComparisonMetricKey =
  | 'population'
  | 'gdpNominal'
  | 'gdpPerCapita'
  | 'gdpGrowth'
  | 'area'
  | 'exports'
  | 'techScore';

export interface ComparisonMetricDef {
  key: ComparisonMetricKey;
  label: string;
  shortLabel: string;
  unit: string;
  description: string;
  formatValue: (val: number) => string;
  higherIsBetter?: boolean;
}
