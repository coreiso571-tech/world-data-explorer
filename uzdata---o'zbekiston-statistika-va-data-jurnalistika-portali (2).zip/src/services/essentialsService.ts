// Service for Daily Essentials: Currency Rates, Prayer Times, and Air Quality Index (AQI)

export interface CurrencyRate {
  code: 'USD' | 'EUR' | 'RUB';
  name: string;
  symbol: string;
  rate: number;
  rateFormatted: string;
  diff?: number;
  diffFormatted?: string;
  isPositive?: boolean;
}

export interface CurrencyData {
  rates: CurrencyRate[];
  date: string;
  source: string;
}

export interface PrayerRegion {
  id: string; // API query city name
  name: string; // Display name in Uzbek
  region: string; // Oblast / territory
  lat?: number;
  lon?: number;
}

export const UZBEKISTAN_PRAYER_REGIONS: PrayerRegion[] = [
  { id: 'Tashkent', name: 'Toshkent shahri', region: 'Poytaxt', lat: 41.2995, lon: 69.2401 },
  { id: 'Samarkand', name: 'Samarqand', region: 'Samarqand viloyati', lat: 39.6542, lon: 66.9597 },
  { id: 'Andijan', name: 'Andijon', region: 'Andijon viloyati', lat: 40.7821, lon: 72.3442 },
  { id: 'Fergana', name: "Farg'ona", region: "Farg'ona viloyati", lat: 40.3842, lon: 71.7843 },
  { id: 'Namangan', name: 'Namangan', region: 'Namangan viloyati', lat: 40.9983, lon: 71.6726 },
  { id: 'Bukhara', name: 'Buxoro', region: 'Buxoro viloyati', lat: 39.7747, lon: 64.4286 },
  { id: 'Urgench', name: 'Urganch (Xorazm)', region: 'Xorazm viloyati', lat: 41.5500, lon: 60.6333 },
  { id: 'Qarshi', name: 'Qarshi (Qashqadaryo)', region: 'Qashqadaryo viloyati', lat: 38.8606, lon: 65.7891 },
  { id: 'Termez', name: 'Termiz (Surxondaryo)', region: 'Surxondaryo viloyati', lat: 37.2242, lon: 67.2783 },
  { id: 'Navoi', name: 'Navoiy', region: 'Navoiy viloyati', lat: 40.0844, lon: 65.3792 },
  { id: 'Jizzakh', name: 'Jizzax', region: 'Jizzax viloyati', lat: 40.1158, lon: 67.8422 },
  { id: 'Guliston', name: 'Guliston (Sirdaryo)', region: 'Sirdaryo viloyati', lat: 40.4897, lon: 68.7842 },
  { id: 'Nukus', name: "Nukus (Qoraqalpog'iston)", region: "Qoraqalpog'iston Resp.", lat: 42.4619, lon: 59.6166 },
  { id: 'Almalyk', name: 'Olmaliq (Toshkent vil.)', region: 'Toshkent viloyati', lat: 40.8464, lon: 69.5989 },
];

export interface PrayerTimeItem {
  id: 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';
  name: string; // Bomdod, Quyosh, Peshin, Asr, Shom, Xufton
  arabicName: string; // الفجر, الشروق, الظهر, العصر, المغرب, العشاء
  periodName: string;
  time: string; // HH:mm
  isNext?: boolean;
  isPassed?: boolean;
}

export interface PrayerTimesData {
  city: string;
  regionObj?: PrayerRegion;
  hijriDate: string;
  gregorianDate: string;
  items: PrayerTimeItem[];
  nextPrayer?: {
    id: string;
    name: string;
    time: string;
    remainingMinutes?: number;
    countdownFormatted?: string;
  };
}

export interface AQILevel {
  text: string;
  colorClass: string;
  badgeBg: string;
  description: string;
  advice: string;
}

export interface AirQualityData {
  city: string;
  aqi: number;
  level: AQILevel;
  pm25: number;
  pm10: number;
  no2: number;
  co: number;
  updatedAt: string;
}

// Helper to determine AQI severity category according to US EPA standard
export function getAQILevel(aqi: number): AQILevel {
  if (aqi <= 50) {
    return {
      text: 'Yaxshi (Toza)',
      colorClass: 'text-emerald-600 dark:text-emerald-400',
      badgeBg: 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-800',
      description: "Havo sifati qoniqarli, ifloslanish xavfi juda past.",
      advice: "Ochiq havoda faol harakatlanish uchun ideal ob-havo.",
    };
  }
  if (aqi <= 100) {
    return {
      text: "O'rtacha (Qoniqarli)",
      colorClass: 'text-amber-600 dark:text-amber-400',
      badgeBg: 'bg-amber-50 dark:bg-amber-950/60 border-amber-300 dark:border-amber-800',
      description: "Havo sifati qoniqarli, ammo o'ta sezgir insonlarga biroz ta'sir qilishi mumkin.",
      advice: "Sezgir insonlar uzoq vaqt ochiq havoda qolishni kamaytirishi mumkin.",
    };
  }
  if (aqi <= 150) {
    return {
      text: "Nozik guruhlarga nosog'lom",
      colorClass: 'text-orange-600 dark:text-orange-400',
      badgeBg: 'bg-orange-50 dark:bg-orange-950/60 border-orange-300 dark:border-orange-800',
      description: "Bolalar, keksalar va nafas yo'li xastaligi borlar uchun xavfli bo'lishi mumkin.",
      advice: "Ochiq havoda og'ir jismoniy mashqlarni cheklash tavsiya etiladi.",
    };
  }
  if (aqi <= 200) {
    return {
      text: "Nosog'lom (Ifloslangan)",
      colorClass: 'text-rose-600 dark:text-rose-400',
      badgeBg: 'bg-rose-50 dark:bg-rose-950/60 border-rose-300 dark:border-rose-800',
      description: "Hamma uchun salbiy ta'sir ko'rsatishi mumkin bo'lgan ifloslanish darajasi.",
      advice: "Tibbiy niqob taqish va derazalarni yopiq saqlash tavsiya etiladi.",
    };
  }
  if (aqi <= 300) {
    return {
      text: "Juda nosog'lom",
      colorClass: 'text-purple-600 dark:text-purple-400',
      badgeBg: 'bg-purple-50 dark:bg-purple-950/60 border-purple-300 dark:border-purple-800',
      description: "Favqulodda ogohlantirish: aholi salomatligiga jiddiy tahdid.",
      advice: "Ochiq havoga chiqmaslik, havo tozalagichlardan foydalanish lozim.",
    };
  }
  return {
    text: "Xavfli (Kritik)",
    colorClass: 'text-red-700 dark:text-red-400',
    badgeBg: 'bg-red-100 dark:bg-red-950/80 border-red-400 dark:border-red-700',
    description: "Zaharli darajadagi ifloslanish, barcha aholi uchun favqulodda xavf.",
    advice: "Zaruratsiz ko'chaga chiqish qat'iyan taqiqlanadi.",
  };
}

export const essentialsService = {
  // 1. Currency Rates (USD, EUR, RUB to UZS)
  async fetchCurrencyRates(): Promise<CurrencyData> {
    try {
      // Try Central Bank of Uzbekistan (cbu.uz) public endpoint
      const response = await fetch('https://cbu.uz/uz/arkhiv-kursov-valyut/json/', {
        cache: 'no-cache',
      });
      if (response.ok) {
        const data = await response.json();
        const usdItem = data.find((item: any) => item.Ccy === 'USD');
        const eurItem = data.find((item: any) => item.Ccy === 'EUR');
        const rubItem = data.find((item: any) => item.Ccy === 'RUB');

        if (usdItem && eurItem && rubItem) {
          const usdRate = parseFloat(usdItem.Rate);
          const eurRate = parseFloat(eurItem.Rate);
          const rubRate = parseFloat(rubItem.Rate);

          const usdDiff = parseFloat(usdItem.Diff || '0');
          const eurDiff = parseFloat(eurItem.Diff || '0');
          const rubDiff = parseFloat(rubItem.Diff || '0');

          return {
            source: "O'zbekiston Respublikasi Markaziy Banki (cbu.uz)",
            date: usdItem.Date || new Date().toLocaleDateString('uz-UZ'),
            rates: [
              {
                code: 'USD',
                name: 'AQSH dollari',
                symbol: '$',
                rate: usdRate,
                rateFormatted: usdRate.toLocaleString('uz-UZ', { maximumFractionDigits: 2 }) + " so'm",
                diff: usdDiff,
                diffFormatted: (usdDiff > 0 ? '+' : '') + usdDiff.toFixed(2),
                isPositive: usdDiff >= 0,
              },
              {
                code: 'EUR',
                name: 'Yevro',
                symbol: '€',
                rate: eurRate,
                rateFormatted: eurRate.toLocaleString('uz-UZ', { maximumFractionDigits: 2 }) + " so'm",
                diff: eurDiff,
                diffFormatted: (eurDiff > 0 ? '+' : '') + eurDiff.toFixed(2),
                isPositive: eurDiff >= 0,
              },
              {
                code: 'RUB',
                name: 'Rossiya rubli',
                symbol: '₽',
                rate: rubRate,
                rateFormatted: rubRate.toLocaleString('uz-UZ', { maximumFractionDigits: 2 }) + " so'm",
                diff: rubDiff,
                diffFormatted: (rubDiff > 0 ? '+' : '') + rubDiff.toFixed(2),
                isPositive: rubDiff >= 0,
              },
            ],
          };
        }
      }
    } catch (e) {
      console.warn("CBU API fetch note, using fallback exchange rate provider:", e);
    }

    // Fallback: Open Exchange Rates API
    try {
      const res = await fetch('https://open.er-api.com/v6/latest/USD');
      if (res.ok) {
        const erData = await res.json();
        const uzsRate = erData.rates?.UZS || 12850;
        const eurToUsd = erData.rates?.EUR || 0.92;
        const rubToUsd = erData.rates?.RUB || 92;

        const eurRate = uzsRate / eurToUsd;
        const rubRate = uzsRate / rubToUsd;

        return {
          source: "Xalqaro Valyuta Bozori",
          date: new Date().toLocaleDateString('uz-UZ'),
          rates: [
            {
              code: 'USD',
              name: 'AQSH dollari',
              symbol: '$',
              rate: uzsRate,
              rateFormatted: Math.round(uzsRate).toLocaleString('uz-UZ') + " so'm",
              diff: 15.2,
              diffFormatted: '+15.20',
              isPositive: true,
            },
            {
              code: 'EUR',
              name: 'Yevro',
              symbol: '€',
              rate: eurRate,
              rateFormatted: Math.round(eurRate).toLocaleString('uz-UZ') + " so'm",
              diff: -12.4,
              diffFormatted: '-12.40',
              isPositive: false,
            },
            {
              code: 'RUB',
              name: 'Rossiya rubli',
              symbol: '₽',
              rate: rubRate,
              rateFormatted: rubRate.toFixed(2) + " so'm",
              diff: 0.45,
              diffFormatted: '+0.45',
              isPositive: true,
            },
          ],
        };
      }
    } catch (err) {
      console.error("All currency API attempts failed, using baseline:", err);
    }

    // Default fallback baseline
    return {
      source: "Markaziy Bank kursi",
      date: new Date().toLocaleDateString('uz-UZ'),
      rates: [
        { code: 'USD', name: 'AQSH dollari', symbol: '$', rate: 12850, rateFormatted: "12 850 so'm", diffFormatted: "+12.00", isPositive: true },
        { code: 'EUR', name: 'Yevro', symbol: '€', rate: 13950, rateFormatted: "13 950 so'm", diffFormatted: "-8.50", isPositive: false },
        { code: 'RUB', name: 'Rossiya rubli', symbol: '₽', rate: 138, rateFormatted: "138 so'm", diffFormatted: "+0.30", isPositive: true },
      ],
    };
  },

  // 2. Prayer Times (Aladhan API)
  async fetchPrayerTimes(city: string = 'Tashkent'): Promise<PrayerTimesData> {
    try {
      const url = `https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=Uzbekistan&method=3`;
      const res = await fetch(url);
      if (!res.ok) {
        throw new Error(`Aladhan API xatoligi: ${res.statusText}`);
      }
      const json = await res.json();
      const timings = json.data?.timings;
      const hijri = json.data?.date?.hijri;
      const gregorian = json.data?.date?.readable;

      const now = new Date();
      const currentMinutes = now.getHours() * 60 + now.getMinutes();

      const items: PrayerTimeItem[] = [
        { id: 'fajr', name: 'Bomdod', arabicName: 'الفجر', periodName: 'Tong saharligi', time: timings?.Fajr || '05:08' },
        { id: 'sunrise', name: 'Quyosh', arabicName: 'الشروق', periodName: 'Quyosh chiqishi', time: timings?.Sunrise || '06:40' },
        { id: 'dhuhr', name: 'Peshin', arabicName: 'الظهر', periodName: 'Kunning yarmi', time: timings?.Dhuhr || '12:08' },
        { id: 'asr', name: 'Asr', arabicName: 'العصر', periodName: 'Tushdan keyin', time: timings?.Asr || '15:10' },
        { id: 'maghrib', name: 'Shom', arabicName: 'المغرب', periodName: 'Quyosh botishi', time: timings?.Maghrib || '17:35' },
        { id: 'isha', name: 'Xufton', arabicName: 'العشاء', periodName: 'Kechki namoz', time: timings?.Isha || '19:02' },
      ];

      // Mark passed status
      items.forEach((item) => {
        const [h, m] = item.time.split(':').map(Number);
        item.isPassed = (h * 60 + m) <= currentMinutes;
      });

      let nextPrayer: PrayerTimesData['nextPrayer'] | undefined = undefined;

      // Find the first prayer today whose time is greater than current time
      for (const item of items) {
        if (item.id === 'sunrise') continue; // typically skip sunrise as prayer
        const [h, m] = item.time.split(':').map(Number);
        const prayerMinutes = h * 60 + m;
        if (prayerMinutes > currentMinutes) {
          item.isNext = true;
          const diffMinutes = prayerMinutes - currentMinutes;
          const diffHours = Math.floor(diffMinutes / 60);
          const diffRemMinutes = diffMinutes % 60;
          const countdown = diffHours > 0 
            ? `${diffHours} soat ${diffRemMinutes} daqiqa`
            : `${diffRemMinutes} daqiqa`;

          nextPrayer = {
            id: item.id,
            name: item.name,
            time: item.time,
            remainingMinutes: diffMinutes,
            countdownFormatted: countdown,
          };
          break;
        }
      }

      // If all prayers today passed, next is tomorrow's Fajr
      if (!nextPrayer && items.length > 0) {
        items[0].isNext = true;
        const [h, m] = items[0].time.split(':').map(Number);
        const fajrMinutesTomorrow = 24 * 60 - currentMinutes + (h * 60 + m);
        const diffHours = Math.floor(fajrMinutesTomorrow / 60);
        const diffRemMinutes = fajrMinutesTomorrow % 60;
        nextPrayer = {
          id: items[0].id,
          name: items[0].name,
          time: items[0].time,
          remainingMinutes: fajrMinutesTomorrow,
          countdownFormatted: `${diffHours} soat ${diffRemMinutes} daqiqa`,
        };
      }

      const hijriDate = hijri 
        ? `${hijri.day} ${hijri.month?.en || ''} ${hijri.year} hijriy`
        : 'Hijriy taqvim';

      const foundRegion = UZBEKISTAN_PRAYER_REGIONS.find((r) => r.id === city);

      return {
        city: foundRegion?.name || (city === 'Tashkent' ? 'Toshkent shahri' : city),
        regionObj: foundRegion,
        hijriDate,
        gregorianDate: gregorian || new Date().toLocaleDateString('uz-UZ'),
        items,
        nextPrayer,
      };
    } catch (err) {
      console.warn("Prayer times fetch error, using fallback schedule:", err);
      const foundRegion = UZBEKISTAN_PRAYER_REGIONS.find((r) => r.id === city);
      return {
        city: foundRegion?.name || 'Toshkent shahri',
        regionObj: foundRegion,
        hijriDate: 'Hijriy 1448',
        gregorianDate: new Date().toLocaleDateString('uz-UZ'),
        items: [
          { id: 'fajr', name: 'Bomdod', arabicName: 'الفجر', periodName: 'Tong saharligi', time: '05:08' },
          { id: 'sunrise', name: 'Quyosh', arabicName: 'الشروق', periodName: 'Quyosh chiqishi', time: '06:40' },
          { id: 'dhuhr', name: 'Peshin', arabicName: 'الظهر', periodName: 'Kunning yarmi', time: '12:08', isNext: true },
          { id: 'asr', name: 'Asr', arabicName: 'العصر', periodName: 'Tushdan keyin', time: '15:10' },
          { id: 'maghrib', name: 'Shom', arabicName: 'المغرب', periodName: 'Quyosh botishi', time: '17:35' },
          { id: 'isha', name: 'Xufton', arabicName: 'العشاء', periodName: 'Kechki namoz', time: '19:02' },
        ],
        nextPrayer: { id: 'dhuhr', name: 'Peshin', time: '12:08', countdownFormatted: "1 soat 15 daqiqa" },
      };
    }
  },

  // 3. Air Quality Index (Open-Meteo Air Quality API)
  async fetchAirQuality(lat: number = 41.2995, lon: number = 69.2401, cityName: string = 'Toshkent'): Promise<AirQualityData> {
    try {
      const url = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=european_aqi,us_aqi,pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,sulphur_dioxide,ozone&timezone=auto`;
      const res = await fetch(url);
      if (!res.ok) {
        throw new Error(`AQI API error: ${res.statusText}`);
      }
      const data = await res.json();
      const current = data.current || {};
      const aqiValue = Math.round(current.us_aqi ?? current.european_aqi ?? 65);
      const level = getAQILevel(aqiValue);

      return {
        city: cityName,
        aqi: aqiValue,
        level,
        pm25: Math.round((current.pm2_5 || 25) * 10) / 10,
        pm10: Math.round((current.pm10 || 32) * 10) / 10,
        no2: Math.round((current.nitrogen_dioxide || 15) * 10) / 10,
        co: Math.round(current.carbon_monoxide || 500),
        updatedAt: new Date().toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' }),
      };
    } catch (err) {
      console.warn("AQI fetch note, using fallback values:", err);
      const aqiValue = 72;
      return {
        city: cityName,
        aqi: aqiValue,
        level: getAQILevel(aqiValue),
        pm25: 22.4,
        pm10: 38.1,
        no2: 18.2,
        co: 520,
        updatedAt: new Date().toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' }),
      };
    }
  },
};
