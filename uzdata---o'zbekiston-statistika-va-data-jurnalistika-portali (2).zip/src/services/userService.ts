export interface RecentlyViewedItem {
  id: string;
  type: 'stat' | 'article';
  title: string;
  slug: string;
  category: string;
  value?: string;
  viewedAt: string;
}

export interface UserProfileSettings {
  displayName: string;
  profession: string;
  preferredRegion: string;
  preferredCategories: string[];
  emailAlerts: boolean;
  weeklyDigest: boolean;
}

const BOOKMARKS_KEY = 'uzdata_bookmarks_v1';
const RECENT_KEY = 'uzdata_recent_views_v1';
const PROFILE_KEY = 'uzdata_user_profile_v1';

export const userService = {
  // Get bookmarked IDs
  getBookmarkedIds(): string[] {
    try {
      const data = localStorage.getItem(BOOKMARKS_KEY);
      return data ? JSON.parse(data) : ['stat-aholi-soni', 'stat-it-eksport'];
    } catch {
      return ['stat-aholi-soni', 'stat-it-eksport'];
    }
  },

  // Check if item is bookmarked
  isBookmarked(id: string): boolean {
    const list = this.getBookmarkedIds();
    return list.includes(id);
  },

  // Toggle bookmark
  toggleBookmark(id: string): boolean {
    const list = this.getBookmarkedIds();
    let updated: string[];
    let isNowBookmarked: boolean;

    if (list.includes(id)) {
      updated = list.filter((item) => item !== id);
      isNowBookmarked = false;
    } else {
      updated = [id, ...list];
      isNowBookmarked = true;
    }

    try {
      localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(updated));
      window.dispatchEvent(new CustomEvent('uzdata_bookmarks_updated', { detail: { id, isBookmarked: isNowBookmarked } }));
    } catch (e) {
      console.warn('Bookmark save error:', e);
    }
    return isNowBookmarked;
  },

  // Get recently viewed items
  getRecentlyViewed(): RecentlyViewedItem[] {
    try {
      const data = localStorage.getItem(RECENT_KEY);
      if (data) return JSON.parse(data);
    } catch {
      // Fallback
    }

    return [
      {
        id: 'stat-aholi-soni',
        type: 'stat',
        title: "O'zbekiston Doimiy Aholisi Soni",
        slug: 'aholi-soni',
        category: 'demografiya',
        value: '37.6 mln',
        viewedAt: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
      },
      {
        id: 'stat-yaim-hajmi',
        type: 'stat',
        title: 'Yalpi Ichki Mahsulot (YaIM)',
        slug: 'yaim-hajmi',
        category: 'iqtisodiyot',
        value: '$112.5 mlrd',
        viewedAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
      },
      {
        id: 'art-it-eksporti-yol',
        type: 'article',
        title: "O'zbekiston IT-xizmatlari eksporti: $550 mln ko'rsatkichiga qanday erishildi?",
        slug: 'it-xizmatlar-eksporti-tahlili',
        category: 'it-biznes',
        viewedAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
      },
    ];
  },

  // Record a view
  recordView(item: Omit<RecentlyViewedItem, 'viewedAt'>) {
    try {
      const list = this.getRecentlyViewed();
      const filtered = list.filter((i) => i.id !== item.id);
      const updated: RecentlyViewedItem[] = [
        {
          ...item,
          viewedAt: new Date().toISOString(),
        },
        ...filtered,
      ].slice(0, 15); // keep max 15 recent

      localStorage.setItem(RECENT_KEY, JSON.stringify(updated));
      window.dispatchEvent(new CustomEvent('uzdata_recent_views_updated'));
    } catch (e) {
      console.warn('Recent view save error:', e);
    }
  },

  // Clear recent views
  clearRecentViews() {
    try {
      localStorage.removeItem(RECENT_KEY);
      window.dispatchEvent(new CustomEvent('uzdata_recent_views_updated'));
    } catch (e) {
      console.warn('Clear recent error:', e);
    }
  },

  // User Profile Settings
  getProfileSettings(defaultEmail: string = 'foydalanuvchi@uzdata.uz'): UserProfileSettings {
    try {
      const data = localStorage.getItem(PROFILE_KEY);
      if (data) return JSON.parse(data);
    } catch {
      // Fallback
    }

    return {
      displayName: 'Tahlilchi Foydalanuvchi',
      profession: 'Iqtisodiy Tahlilchi',
      preferredRegion: 'Toshkent shahri',
      preferredCategories: ['iqtisodiyot', 'it-biznes', 'demografiya'],
      emailAlerts: true,
      weeklyDigest: true,
    };
  },

  saveProfileSettings(settings: UserProfileSettings) {
    try {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(settings));
      window.dispatchEvent(new CustomEvent('uzdata_profile_updated', { detail: settings }));
    } catch (e) {
      console.warn('Save profile error:', e);
    }
  },
};
