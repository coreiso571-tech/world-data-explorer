export interface CommentItem {
  id: string;
  targetId: string; // statistic id or article id
  author: string;
  authorRole: string;
  text: string;
  createdAt: string;
  upvotes: number;
  downvotes: number;
  type: 'fikr' | 'savol' | 'taklif';
}

const COMMENTS_STORAGE_KEY = 'uzdata_community_comments_v1';
const VOTED_COMMENTS_KEY = 'uzdata_user_voted_comments_v1';

const INITIAL_COMMENTS: CommentItem[] = [
  {
    id: 'c1',
    targetId: 'stat-aholi-soni',
    author: 'Otabek Rustamov',
    authorRole: 'Demografiya bo\'yicha tahlilchi',
    text: "Doimiy aholi sonining 37.6 milliondan oshishi Markaziy Osiyo mehnat bozori uchun ulkan imkoniyat. Shaharlashuv (urbanizatsiya) darajasini ham 60% ga yetkazish rejalashtirilmoqda.",
    createdAt: '2026-10-18T10:15:00Z',
    upvotes: 24,
    downvotes: 1,
    type: 'tahlil' as any,
  },
  {
    id: 'c2',
    targetId: 'stat-aholi-soni',
    author: 'Nodira Salimova',
    authorRole: 'Tadqiqotchi',
    text: "Hududlar kesimida Samarqand va Farg'ona yetakchilik qilayotgani qiziq. Keyingi yangilanishda tumanlar bo'yicha ham batafsil ma'lumotlar qo'shilsa juda foydali bo'lardi.",
    createdAt: '2026-10-19T14:30:00Z',
    upvotes: 18,
    downvotes: 0,
    type: 'taklif',
  },
  {
    id: 'c3',
    targetId: 'stat-yaim-hajmi',
    author: 'Jasur Mirzayev',
    authorRole: 'Moliyaviy ekspert',
    text: "YaIM 112.5 milliard dollarga yetgani juda ijobiy tendensiya. Ayniqsa xizmatlar sohasi va sanoat diversifikatsiyasi o'sishning asosiy omili bo'lmoqda.",
    createdAt: '2026-10-16T16:20:00Z',
    upvotes: 31,
    downvotes: 2,
    type: 'tahlil' as any,
  },
  {
    id: 'c4',
    targetId: 'stat-it-eksport',
    author: 'Dilshod Karimov',
    authorRole: 'IT Park Rezidenti',
    text: "Eksport 550 million dollarga chiqqani BPO va kiberxavfsizlik kompaniyalari hisobiga tezlashdi. 2030 yilgacha 5 milliard dollar maqsadi qo'yilgan.",
    createdAt: '2026-10-17T11:45:00Z',
    upvotes: 42,
    downvotes: 1,
    type: 'tahlil' as any,
  },
  {
    id: 'c5',
    targetId: 'stat-inflyatsiya',
    author: 'Malika Ergasheva',
    authorRole: 'Iqtisodchi',
    text: "Yillik inflyatsiya 8.4 foizda ushlab turilgani Markaziy Bankning pul-kredit siyosati natijasi. Target 5% ga yaqinlashish kutilmoqda.",
    createdAt: '2026-10-18T09:00:00Z',
    upvotes: 15,
    downvotes: 0,
    type: 'fikr',
  },
  {
    id: 'c6',
    targetId: 'it-xizmatlar-eksporti-tahlili',
    author: 'Sanjar Po\'latov',
    authorRole: 'Dasturiy muhandis',
    text: "Viloyatlardagi BPO markazlari juda to'g'ri qadam bo'ldi. Yoshlar Toshkentga bormasdan ham o'z hududlarida xalqaro loyihalarda ishlamoqda.",
    createdAt: '2026-10-17T18:00:00Z',
    upvotes: 27,
    downvotes: 1,
    type: 'fikr',
  },
];

export const commentService = {
  getAllComments(): CommentItem[] {
    try {
      const data = localStorage.getItem(COMMENTS_STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch {
      // Fallback
    }
    return INITIAL_COMMENTS;
  },

  getCommentsForTarget(targetId: string): CommentItem[] {
    const all = this.getAllComments();
    return all.filter((c) => c.targetId === targetId);
  },

  addComment(comment: Omit<CommentItem, 'id' | 'createdAt' | 'upvotes' | 'downvotes'>): CommentItem {
    const all = this.getAllComments();
    const newComment: CommentItem = {
      ...comment,
      id: `comm-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      createdAt: new Date().toISOString(),
      upvotes: 1,
      downvotes: 0,
    };

    const updated = [newComment, ...all];
    try {
      localStorage.setItem(COMMENTS_STORAGE_KEY, JSON.stringify(updated));
      window.dispatchEvent(new CustomEvent('uzdata_comments_updated', { detail: newComment }));
    } catch (e) {
      console.warn('Comment save error:', e);
    }
    return newComment;
  },

  voteComment(commentId: string, direction: 'up' | 'down'): { upvotes: number; downvotes: number } | null {
    try {
      const votedMap: Record<string, 'up' | 'down'> = JSON.parse(
        localStorage.getItem(VOTED_COMMENTS_KEY) || '{}'
      );

      // Check if already voted the same direction
      if (votedMap[commentId] === direction) {
        return null; // already voted
      }

      const all = this.getAllComments();
      const comment = all.find((c) => c.id === commentId);
      if (!comment) return null;

      const previousVote = votedMap[commentId];
      if (previousVote === 'up') comment.upvotes = Math.max(0, comment.upvotes - 1);
      if (previousVote === 'down') comment.downvotes = Math.max(0, comment.downvotes - 1);

      if (direction === 'up') comment.upvotes += 1;
      if (direction === 'down') comment.downvotes += 1;

      votedMap[commentId] = direction;
      localStorage.setItem(VOTED_COMMENTS_KEY, JSON.stringify(votedMap));
      localStorage.setItem(COMMENTS_STORAGE_KEY, JSON.stringify(all));

      window.dispatchEvent(new CustomEvent('uzdata_comments_updated'));
      return { upvotes: comment.upvotes, downvotes: comment.downvotes };
    } catch {
      return null;
    }
  },

  getUserVote(commentId: string): 'up' | 'down' | null {
    try {
      const votedMap: Record<string, 'up' | 'down'> = JSON.parse(
        localStorage.getItem(VOTED_COMMENTS_KEY) || '{}'
      );
      return votedMap[commentId] || null;
    } catch {
      return null;
    }
  },
};
