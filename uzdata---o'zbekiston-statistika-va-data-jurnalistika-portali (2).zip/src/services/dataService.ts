import { 
  collection, 
  getDocs, 
  doc, 
  setDoc, 
  deleteDoc, 
  query, 
  where 
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Statistic, Article, Category } from '../types';
import { 
  INITIAL_STATISTICS, 
  INITIAL_ARTICLES, 
  INITIAL_CATEGORIES 
} from '../data/seedData';

const STATS_COLLECTION = 'statistics';
const ARTICLES_COLLECTION = 'articles';
const CATEGORIES_COLLECTION = 'categories';

export const dataService = {
  // --- PUBLIC METHODS (Strictly Published only) ---
  async getPublishedStatistics(): Promise<Statistic[]> {
    try {
      const q = query(collection(db, STATS_COLLECTION), where('status', '==', 'Published'));
      const snapshot = await getDocs(q);
      if (snapshot.empty) {
        // Fallback to verified seed data so initial view is instantly populated
        return INITIAL_STATISTICS.filter((s) => s.status === 'Published');
      }
      return snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Statistic));
    } catch (error) {
      console.warn('Firestore fetch note, falling back to verified seed:', error);
      return INITIAL_STATISTICS.filter((s) => s.status === 'Published');
    }
  },

  async getPublishedArticles(): Promise<Article[]> {
    try {
      const q = query(collection(db, ARTICLES_COLLECTION), where('status', '==', 'Published'));
      const snapshot = await getDocs(q);
      if (snapshot.empty) {
        return INITIAL_ARTICLES.filter((a) => a.status === 'Published');
      }
      return snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Article));
    } catch (error) {
      console.warn('Firestore articles note, falling back to verified seed:', error);
      return INITIAL_ARTICLES.filter((a) => a.status === 'Published');
    }
  },

  async getCategories(): Promise<Category[]> {
    try {
      const snapshot = await getDocs(collection(db, CATEGORIES_COLLECTION));
      if (snapshot.empty) {
        return INITIAL_CATEGORIES;
      }
      return snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Category));
    } catch (error) {
      console.warn('Categories note:', error);
      return INITIAL_CATEGORIES;
    }
  },

  // --- ADMIN METHODS (Full Access to Published, Draft, Unpublished) ---
  async getAllStatisticsForAdmin(): Promise<Statistic[]> {
    try {
      const snapshot = await getDocs(collection(db, STATS_COLLECTION));
      if (snapshot.empty) {
        return INITIAL_STATISTICS;
      }
      return snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Statistic));
    } catch (error) {
      console.warn('Admin stats fetch notice (operating with cached/seed data):', error);
      return INITIAL_STATISTICS;
    }
  },

  async getAllArticlesForAdmin(): Promise<Article[]> {
    try {
      const snapshot = await getDocs(collection(db, ARTICLES_COLLECTION));
      if (snapshot.empty) {
        return INITIAL_ARTICLES;
      }
      return snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Article));
    } catch (error) {
      console.warn('Admin articles fetch notice (operating with cached/seed data):', error);
      return INITIAL_ARTICLES;
    }
  },

  async saveStatistic(stat: Statistic): Promise<void> {
    const statId = stat.id || `stat-${Date.now()}`;
    const targetDoc = doc(db, STATS_COLLECTION, statId);
    const dataToSave = {
      ...stat,
      id: statId,
      updatedAt: new Date().toISOString(),
      createdAt: stat.createdAt || new Date().toISOString(),
    };

    try {
      await setDoc(targetDoc, dataToSave, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `${STATS_COLLECTION}/${statId}`);
    }
  },

  async deleteStatistic(statId: string): Promise<void> {
    const targetDoc = doc(db, STATS_COLLECTION, statId);
    try {
      await deleteDoc(targetDoc);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${STATS_COLLECTION}/${statId}`);
    }
  },

  async saveArticle(article: Article): Promise<void> {
    const articleId = article.id || `art-${Date.now()}`;
    const targetDoc = doc(db, ARTICLES_COLLECTION, articleId);
    const dataToSave = {
      ...article,
      id: articleId,
      updatedAt: new Date().toISOString(),
      createdAt: article.createdAt || new Date().toISOString(),
    };

    try {
      await setDoc(targetDoc, dataToSave, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `${ARTICLES_COLLECTION}/${articleId}`);
    }
  },

  async deleteArticle(articleId: string): Promise<void> {
    const targetDoc = doc(db, ARTICLES_COLLECTION, articleId);
    try {
      await deleteDoc(targetDoc);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${ARTICLES_COLLECTION}/${articleId}`);
    }
  },

  // Seed database with verified baseline data
  async seedInitialData(): Promise<{ statsCount: number; articlesCount: number; categoriesCount: number }> {
    let statsCount = 0;
    let articlesCount = 0;
    let categoriesCount = 0;

    // Seed Categories
    for (const cat of INITIAL_CATEGORIES) {
      try {
        await setDoc(doc(db, CATEGORIES_COLLECTION, cat.id), cat);
        categoriesCount++;
      } catch (e) {
        console.error('Error seeding category:', cat.id, e);
      }
    }

    // Seed Statistics
    for (const stat of INITIAL_STATISTICS) {
      try {
        await setDoc(doc(db, STATS_COLLECTION, stat.id), stat);
        statsCount++;
      } catch (e) {
        console.error('Error seeding statistic:', stat.id, e);
      }
    }

    // Seed Articles
    for (const art of INITIAL_ARTICLES) {
      try {
        await setDoc(doc(db, ARTICLES_COLLECTION, art.id), art);
        articlesCount++;
      } catch (e) {
        console.error('Error seeding article:', art.id, e);
      }
    }

    return { statsCount, articlesCount, categoriesCount };
  },
};
