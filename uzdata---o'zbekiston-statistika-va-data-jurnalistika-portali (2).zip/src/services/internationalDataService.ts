import { CountryGlobalData, GlobalCountryCode } from '../types/international';
import { INITIAL_COUNTRIES_DATA } from '../data/internationalData';

const CACHE_KEY = 'UZDATA_INTERNATIONAL_CACHE_V2';
const CACHE_TTL_MS = 1000 * 60 * 60 * 12; // 12 hours

interface CachedPayload {
  timestamp: number;
  data: CountryGlobalData[];
  sourceDate: string;
}

// World Bank Indicator Mapping
const INDICATORS = {
  population: 'SP.POP.TOTL',
  gdpNominal: 'NY.GDP.MKTP.CD',
  gdpPerCapita: 'NY.GDP.PCAP.CD',
  gdpGrowth: 'NY.GDP.MKTP.KD.ZG',
  landArea: 'AG.LND.TOTL.K2',
  exports: 'NE.EXP.GNFS.CD',
};

// World Bank Country Code mapping
const WB_COUNTRY_CODES: Record<GlobalCountryCode, string> = {
  UZB: 'UZB',
  IND: 'IND',
  CHN: 'CHN',
  RUS: 'RUS',
  USA: 'USA',
};

interface WorldBankIndicatorItem {
  indicator: { id: string; value: string };
  country: { id: string; value: string };
  countryiso3code: string;
  date: string;
  value: number | null;
}

async function fetchWBIndicator(countryCode: string, indicator: string): Promise<{ value: number; date: string } | null> {
  const url = `https://api.worldbank.org/v2/country/${countryCode}/indicator/${indicator}?format=json&mrnev=1`;
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000); // 6s timeout

    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        Accept: 'application/json',
      },
    });
    clearTimeout(timeoutId);

    if (!res.ok) return null;
    const json = await res.json();
    if (!Array.isArray(json) || json.length < 2 || !Array.isArray(json[1]) || json[1].length === 0) {
      return null;
    }

    const item: WorldBankIndicatorItem = json[1][0];
    if (item && typeof item.value === 'number') {
      return { value: item.value, date: item.date };
    }
    return null;
  } catch (err) {
    // Graceful offline or timeout fallback
    return null;
  }
}

export const internationalDataService = {
  /**
   * Retrieves international country data with World Bank auto-fetch and local caching
   */
  async getCountriesData(forceRefresh = false): Promise<{
    data: CountryGlobalData[];
    isLive: boolean;
    lastUpdated: string;
    sourceName: string;
  }> {
    // 1. Check local cache first if not force refresh
    if (!forceRefresh) {
      try {
        const cachedRaw = localStorage.getItem(CACHE_KEY);
        if (cachedRaw) {
          const parsed: CachedPayload = JSON.parse(cachedRaw);
          const isFresh = Date.now() - parsed.timestamp < CACHE_TTL_MS;
          if (isFresh && parsed.data && parsed.data.length > 0) {
            return {
              data: parsed.data,
              isLive: true,
              lastUpdated: new Date(parsed.timestamp).toLocaleTimeString('uz-UZ', {
                hour: '2-digit',
                minute: '2-digit',
                day: 'numeric',
                month: 'short',
              }),
              sourceName: 'Jahon Banki (World Bank Open Data API)',
            };
          }
        }
      } catch (e) {
        // Ignore cache parse error
      }
    }

    // 2. Fetch fresh indicators from World Bank API for each country
    const updatedCountries: CountryGlobalData[] = JSON.parse(JSON.stringify(INITIAL_COUNTRIES_DATA));
    let hasLiveUpdate = false;
    let latestReportDate = '2024-2025';

    try {
      const fetchPromises = updatedCountries.map(async (c) => {
        const wbCode = WB_COUNTRY_CODES[c.code];
        if (!wbCode) return;

        // Fetch Population, GDP, GDP Growth in parallel
        const [popRes, gdpRes, gdpCapRes, growthRes] = await Promise.allSettled([
          fetchWBIndicator(wbCode, INDICATORS.population),
          fetchWBIndicator(wbCode, INDICATORS.gdpNominal),
          fetchWBIndicator(wbCode, INDICATORS.gdpPerCapita),
          fetchWBIndicator(wbCode, INDICATORS.gdpGrowth),
        ]);

        if (popRes.status === 'fulfilled' && popRes.value) {
          hasLiveUpdate = true;
          const popMln = Number((popRes.value.value / 1_000_000).toFixed(1));
          c.metrics.populationMillion = popMln;
          c.metrics.populationStr =
            popMln >= 1000 ? `${(popMln / 1000).toFixed(2)} mlrd kishi` : `${popMln} mln kishi`;
          latestReportDate = popRes.value.date;

          // Update top3 stats if label matches
          const popItem = c.top3Stats.find((s) => s.category === 'demografiya');
          if (popItem) {
            popItem.value = popMln >= 1000 ? `${(popMln / 1000).toFixed(2)} mlrd` : `${popMln} mln`;
            popItem.numericValue = popMln;
          }
        }

        if (gdpRes.status === 'fulfilled' && gdpRes.value) {
          hasLiveUpdate = true;
          const gdpBln = Math.round(gdpRes.value.value / 1_000_000_000);
          c.metrics.gdpNominalBillion = gdpBln;
          c.metrics.gdpNominalStr =
            gdpBln >= 1000
              ? `$${(gdpBln / 1000).toFixed(2)} trln`
              : `$${gdpBln.toLocaleString()} mlrd`;

          // Update top3 stats
          const gdpItem = c.top3Stats.find((s) => s.category === 'iqtisodiyot');
          if (gdpItem && gdpItem.unit.includes('USD')) {
            gdpItem.value = gdpBln >= 1000 ? `$${(gdpBln / 1000).toFixed(2)} trln` : `$${gdpBln} mlrd`;
            gdpItem.numericValue = gdpBln;
          }
        }

        if (gdpCapRes.status === 'fulfilled' && gdpCapRes.value) {
          const capUsd = Math.round(gdpCapRes.value.value);
          c.metrics.gdpPerCapitaUsd = capUsd;
          c.metrics.gdpPerCapitaStr = `$${capUsd.toLocaleString()}`;
        }

        if (growthRes.status === 'fulfilled' && growthRes.value) {
          const rate = Number(growthRes.value.value.toFixed(1));
          c.metrics.gdpGrowthRate = rate;
        }

        c.worldBankSourceDate = latestReportDate;
      });

      await Promise.all(fetchPromises);

      // Save to cache
      const payload: CachedPayload = {
        timestamp: Date.now(),
        data: updatedCountries,
        sourceDate: latestReportDate,
      };
      localStorage.setItem(CACHE_KEY, JSON.stringify(payload));
    } catch (err) {
      console.warn('World Bank API fetch encountered issue, using cached or fallback data:', err);
    }

    return {
      data: updatedCountries,
      isLive: hasLiveUpdate,
      lastUpdated: new Date().toLocaleTimeString('uz-UZ', {
        hour: '2-digit',
        minute: '2-digit',
        day: 'numeric',
        month: 'short',
      }),
      sourceName: 'Jahon Banki (World Bank Open Data API)',
    };
  },
};
