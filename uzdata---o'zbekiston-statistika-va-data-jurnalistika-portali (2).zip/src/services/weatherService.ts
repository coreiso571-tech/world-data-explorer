export interface WeatherLocation {
  id: string;
  name: string;
  region: string;
  lat: number;
  lon: number;
}

export const UZBEKISTAN_WEATHER_LOCATIONS: WeatherLocation[] = [
  { id: 'tashkent', name: 'Toshkent shahri', region: 'Poytaxt', lat: 41.2995, lon: 69.2401 },
  { id: 'samarkand', name: 'Samarqand', region: 'Samarqand viloyati', lat: 39.6542, lon: 66.9597 },
  { id: 'bukhara', name: 'Buxoro', region: 'Buxoro viloyati', lat: 39.7747, lon: 64.4286 },
  { id: 'fergana', name: "Farg'ona", region: "Farg'ona viloyati", lat: 40.3842, lon: 71.7843 },
  { id: 'andijan', name: 'Andijon', region: 'Andijon viloyati', lat: 40.7821, lon: 72.3442 },
  { id: 'namangan', name: 'Namangan', region: 'Namangan viloyati', lat: 40.9983, lon: 71.6726 },
  { id: 'qarshi', name: 'Qarshi', region: 'Qashqadaryo viloyati', lat: 38.8606, lon: 65.7891 },
  { id: 'termiz', name: 'Termiz', region: 'Surxondaryo viloyati', lat: 37.2242, lon: 67.2783 },
  { id: 'nukus', name: 'Nukus', region: "Qoraqalpog'iston Resp.", lat: 42.4619, lon: 59.6166 },
  { id: 'urganch', name: 'Urganch', region: 'Xorazm viloyati', lat: 41.5500, lon: 60.6333 },
  { id: 'navoiy', name: 'Navoiy', region: 'Navoiy viloyati', lat: 40.0844, lon: 65.3792 },
  { id: 'jizzakh', name: 'Jizzax', region: 'Jizzax viloyati', lat: 40.1158, lon: 67.8422 },
  { id: 'guliston', name: 'Guliston', region: 'Sirdaryo viloyati', lat: 40.4897, lon: 68.7842 },
  { id: 'nurafshon', name: 'Nurafshon', region: 'Toshkent viloyati', lat: 41.0422, lon: 69.3589 },
];

export interface CurrentWeather {
  temperature: number;
  apparentTemperature: number;
  humidity: number;
  windSpeed: number;
  weatherCode: number;
  isDay: boolean;
  precipitation: number;
  pressure: number;
  conditionText: string;
}

export interface DailyForecast {
  date: string;
  dayName: string;
  maxTemp: number;
  minTemp: number;
  weatherCode: number;
  precipitationProb: number;
  conditionText: string;
}

export interface WeatherData {
  location: WeatherLocation;
  current: CurrentWeather;
  daily: DailyForecast[];
  updatedAt: string;
}

export function getWeatherConditionInfo(code: number, isDay = true): { text: string; iconType: 'sun' | 'cloud-sun' | 'cloud' | 'rain' | 'drizzle' | 'snow' | 'storm' | 'fog' } {
  switch (code) {
    case 0:
      return { text: isDay ? 'Musaffo osmon' : 'Ochiq tun', iconType: isDay ? 'sun' : 'cloud-sun' };
    case 1:
      return { text: 'Asosan ochiq', iconType: 'cloud-sun' };
    case 2:
      return { text: 'Qisman bulutli', iconType: 'cloud-sun' };
    case 3:
      return { text: 'Bulutli', iconType: 'cloud' };
    case 45:
    case 48:
      return { text: 'Tumanli', iconType: 'fog' };
    case 51:
    case 53:
    case 55:
      return { text: 'Shivalagan yomg‘ir', iconType: 'drizzle' };
    case 61:
    case 63:
    case 65:
      return { text: 'Yomg‘irli', iconType: 'rain' };
    case 71:
    case 73:
    case 75:
      return { text: 'Qor yog‘ishi', iconType: 'snow' };
    case 77:
      return { text: 'Qor donalari', iconType: 'snow' };
    case 80:
    case 81:
    case 82:
      return { text: 'Jala yomg‘ir', iconType: 'rain' };
    case 85:
    case 86:
      return { text: 'Kuchli qor', iconType: 'snow' };
    case 95:
    case 96:
    case 99:
      return { text: 'Momaqaldiroq / Chaqmoq', iconType: 'storm' };
    default:
      return { text: 'O‘zgaruvchan havo', iconType: 'cloud-sun' };
  }
}

const UZ_DAYS = ['Yak', 'Dush', 'Sesh', 'Chor', 'Pay', 'Jum', 'Shan'];

export async function fetchWeatherData(location: WeatherLocation): Promise<WeatherData> {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${location.lat}&longitude=${location.lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m,surface_pressure&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto`;

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Ob-havo serveridan javob olinmadi: ${res.statusText}`);
  }

  const data = await res.json();
  const currentRaw = data.current;
  const currentCondition = getWeatherConditionInfo(currentRaw.weather_code, Boolean(currentRaw.is_day));

  const current: CurrentWeather = {
    temperature: Math.round(currentRaw.temperature_2m),
    apparentTemperature: Math.round(currentRaw.apparent_temperature),
    humidity: Math.round(currentRaw.relative_humidity_2m),
    windSpeed: Math.round(currentRaw.wind_speed_10m),
    weatherCode: currentRaw.weather_code,
    isDay: Boolean(currentRaw.is_day),
    precipitation: currentRaw.precipitation || 0,
    pressure: Math.round(currentRaw.surface_pressure || 1013),
    conditionText: currentCondition.text,
  };

  const dailyRaw = data.daily;
  const daily: DailyForecast[] = (dailyRaw.time || []).map((dateStr: string, idx: number) => {
    const d = new Date(dateStr);
    const dayName = idx === 0 ? 'Bugun' : idx === 1 ? 'Ertaga' : UZ_DAYS[d.getDay()];
    const code = dailyRaw.weather_code[idx];
    const condition = getWeatherConditionInfo(code, true);

    return {
      date: dateStr,
      dayName,
      maxTemp: Math.round(dailyRaw.temperature_2m_max[idx]),
      minTemp: Math.round(dailyRaw.temperature_2m_min[idx]),
      weatherCode: code,
      precipitationProb: dailyRaw.precipitation_probability_max ? Math.round(dailyRaw.precipitation_probability_max[idx] || 0) : 0,
      conditionText: condition.text,
    };
  });

  return {
    location,
    current,
    daily,
    updatedAt: new Date().toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' }),
  };
}
