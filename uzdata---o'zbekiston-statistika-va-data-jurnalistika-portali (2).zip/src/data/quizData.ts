export interface QuizQuestion {
  id: string;
  category: 'demografiya' | 'iqtisodiyot' | 'it-biznes' | 'hududlar' | 'talim' | 'turizm';
  categoryLabel: string;
  difficulty: 'Oson' | "O'rtacha" | 'Murakkab';
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  source: string;
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    category: 'demografiya',
    categoryLabel: 'Demografiya',
    difficulty: 'Oson',
    question: "2026-yil holatiga ko'ra O'zbekistonning doimiy aholisi soni qancha nafarga yetdi?",
    options: ['34.2 million', '36.0 million', '37.6 million', '40.1 million'],
    correctIndex: 2,
    explanation: "O'zbekiston Respublikasining doimiy aholisi soni 37.6 million kishidan oshdi. Mamlakatimiz Markaziy Osiyo mintaqasida aholi soni bo'yicha mutlaq yetakchidir.",
    source: "Statistika Agentligi (stat.uz)"
  },
  {
    id: 'q2',
    category: 'iqtisodiyot',
    categoryLabel: 'Iqtisodiyot',
    difficulty: "O'rtacha",
    question: "O'zbekistonning YaIM hajmi (dollar hisobida) so'nggi yillarda qaysi marraga yetdi?",
    options: ['57 mlrd dollar', '80 mlrd dollar', '112.5 mlrd dollar', '150 mlrd dollar'],
    correctIndex: 2,
    explanation: "O'zbekiston yalpi ichki mahsuloti jadal rivojlanish natijasida 112.5 milliard dollardan oshib, barqaror 6% dan yuqori yillik real o'sish ko'rsatmoqda.",
    source: "Iqtisodiyot va Moliya Vazirligi / Jahon Banki"
  },
  {
    id: 'q3',
    category: 'it-biznes',
    categoryLabel: 'IT & Innovatsiya',
    difficulty: "O'rtacha",
    question: "O'zbekistonda IT xizmatlari va dasturiy mahsulotlar eksporti 2026-yilda qanday hajmga chiqdi?",
    options: ['$50 million', '$140 million', '$550 million', '$1 milliard'],
    correctIndex: 2,
    explanation: "2019-yilda 12 million dollar bo'lgan IT xizmatlari eksporti 2026-yilda 550 million dollardan oshdi. Asosiy bozorlar - AQSH, Yevropa va Fors ko'rfazi davlatlaridir.",
    source: "IT Park Uzbekistan / Raqamli Texnologiyalar Vazirligi"
  },
  {
    id: 'q4',
    category: 'hududlar',
    categoryLabel: 'Hududlar',
    difficulty: 'Oson',
    question: "Aholi soni bo'yicha O'zbekistonning eng katta viloyati qaysi?",
    options: ["Farg'ona viloyati", 'Samarqand viloyati', 'Andijon viloyati', 'Qashqadaryo viloyati'],
    correctIndex: 1,
    explanation: "Samarqand viloyati 4.2 milliondan ortiq aholi bilan respublikada eng ko'p sonli hudud hisoblanadi (undan keyin Farg'ona 4.05 mln va Qashqadaryo 3.55 mln).",
    source: "O'zbekiston Demografiya Ko'rsatkichlari (stat.uz)"
  },
  {
    id: 'q5',
    category: 'talim',
    categoryLabel: "Ta'lim",
    difficulty: "O'rtacha",
    question: "Bitiruvchilarning oliy ta'lim bilan qamrov darajasi 2017-yildagi 9% dan qanchaga yetdi?",
    options: ['18.5%', '27.0%', '42.5%', '65.0%'],
    correctIndex: 2,
    explanation: "Universitetlar soni 215 tadan oshishi va qabul kvotalari ko'payishi evaziga oliy ta'lim qamrovi 42.5% dan oshdi (2017-yildagiga nisbatan 4.7 barobar ko'p).",
    source: "Oliy Ta'lim, Fan va Innovatsiyalar Vazirligi"
  },
  {
    id: 'q6',
    category: 'hududlar',
    categoryLabel: 'Hududlar',
    difficulty: 'Oson',
    question: "Yer maydoni bo'yicha O'zbekistonning eng yirik hududi qaysi hisoblanadi?",
    options: ['Navoiy viloyati', 'Buxoro viloyati', "Qoraqalpog'iston Respublikasi", 'Qashqadaryo viloyati'],
    correctIndex: 2,
    explanation: "Qoraqalpog'iston Respublikasi 166 600 kv.km maydonga ega bo'lib, butun O'zbekiston hududining 37% dan ortig'ini egallaydi. Ikkinchi o'rinda Navoiy viloyati (110 800 kv.km).",
    source: "Davlat Kadastrlari Palatasi"
  },
  {
    id: 'q7',
    category: 'iqtisodiyot',
    categoryLabel: 'Iqtisodiyot',
    difficulty: "O'rtacha",
    question: "O'zbekiston Respublikasi Markaziy Bankining inflyatsiya bo'yicha o'rta muddatli targeti qanday?",
    options: ['2%', '5%', '10%', '15%'],
    correctIndex: 1,
    explanation: "Markaziy Bank inflyatsiyaviy targetlash rejimida o'rta muddatda yillik inflyatsiyani 5% darajasida barqarorlashtirishni asosiy maqsad qilib belgilagan.",
    source: "O'zbekiston Respublikasi Markaziy Banki (cbu.uz)"
  },
  {
    id: 'q8',
    category: 'turizm',
    categoryLabel: 'Turizm',
    difficulty: "O'rtacha",
    question: "O'zbekistonga bir yilda tashrif buyuradigan xorijiy sayyohlar soni qancha marraga yetdi?",
    options: ['2.5 million', '4.1 million', '7.8 million', '12 million'],
    correctIndex: 2,
    explanation: "Turizm infratuzilmasi, viza islohoti va yangi xalqaro aeroportlar evaziga yillik sayyohlar soni 7.8 million nafarga yetdi.",
    source: "Turizm Qo'mitasi (motac.uz)"
  },
  {
    id: 'q9',
    category: 'iqtisodiyot',
    categoryLabel: 'Iqtisodiyot',
    difficulty: 'Murakkab',
    question: "Respublika YaIM shakllanishida eng yuqori ulushga (taxminan 17.5%) ega hudud qaysi?",
    options: ['Navoiy viloyati', 'Samarqand viloyati', 'Toshkent shahri', 'Toshkent viloyati'],
    correctIndex: 2,
    explanation: "Poytaxt Toshkent shahri mamlakat YaIMining qariyb 17.5% qismini yaratadi. Ikkinchi o'rinda Toshkent viloyati (10.4%) va Navoiy viloyati (8.8%).",
    source: "Statistika Agentligi - Milliy Hisoblar"
  },
  {
    id: 'q10',
    category: 'demografiya',
    categoryLabel: 'Demografiya',
    difficulty: "O'rtacha",
    question: "O'zbekiston aholisining o'rtacha yoshi taxminan qancha hisoblanadi?",
    options: ['21 yosh', '29 yosh', '37 yosh', '45 yosh'],
    correctIndex: 1,
    explanation: "O'zbekiston aholisi nihoyatda yosh: o'rtacha yosh 29-30 yosh atrofida. Aholining 60 foizga yaqini mehnatga layoqatli yoshdagi fuqarolardir.",
    source: "Demografik Tahlillar Markazi"
  },
  {
    id: 'q11',
    category: 'iqtisodiyot',
    categoryLabel: 'Iqtisodiyot',
    difficulty: 'Murakkab',
    question: "O'zbekistonning oltin-valyuta rasmiy zaxiralari hajmi qancha miqdorda baholanmoqda?",
    options: ['12 mlrd dollar', '24 mlrd dollar', '40+ mlrd dollar', '75 mlrd dollar'],
    correctIndex: 2,
    explanation: "Oltin narxining ko'tarilishi va tashqi savdo faolligi hisobiga O'zbekiston rasmiy xalqaro zaxiralari 40 milliard dollardan ortiq darajani tashkil etmoqda.",
    source: "Markaziy Bank Rasmiy Hisoboti"
  },
  {
    id: 'q12',
    category: 'iqtisodiyot',
    categoryLabel: 'Iqtisodiyot',
    difficulty: 'Murakkab',
    question: "O'zbekiston 2030-yilga borib elektr energiyasi balansida qayta tiklanuvchi energiya ulushini qanchaga yetkazishni maqsad qilgan?",
    options: ['15%', '25%', '40%', '60%'],
    correctIndex: 2,
    explanation: "Prezident strategiyasiga muvofiq, 2030-yilga kelib quyosh va shamol elektr stansiyalari orqali umumiy ishlab chiqarishning 40 foizini yashil energiyadan olish rejalashtirilgan.",
    source: "Energetika Vazirligi"
  }
];
