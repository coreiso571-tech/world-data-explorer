import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  User, 
  signInWithPopup, 
  signOut as fbSignOut, 
  onAuthStateChanged 
} from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, googleProvider, db } from '../lib/firebase';
import { AdminUser } from '../types';

interface AuthContextType {
  user: User | null;
  adminUser: AdminUser | null;
  isAdmin: boolean;
  loading: boolean;
  authError: string | null;
  loginWithGoogle: () => Promise<boolean>;
  logout: () => Promise<void>;
  clearAuthError: () => void;
  targetAdminEmail: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Primary authorized admin from runtime environment
export const BOOTSTRAPPED_ADMIN_EMAIL = 'coreiso571@gmail.com';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser && currentUser.email) {
        const isBootstrapped = currentUser.email.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase();

        let firestoreAdmin = false;
        try {
          const adminDoc = await getDoc(doc(db, 'admins', currentUser.uid));
          firestoreAdmin = adminDoc.exists();
        } catch (e) {
          console.warn('Admin check note:', e);
        }

        if (isBootstrapped || firestoreAdmin) {
          setIsAdmin(true);
          setAdminUser({
            uid: currentUser.uid,
            email: currentUser.email,
            role: 'admin',
            displayName: currentUser.displayName || 'Bosh Muharrir',
            photoURL: currentUser.photoURL || undefined,
          });
          setAuthError(null);
        } else {
          // Standard logged-in citizen / community user
          setIsAdmin(false);
          setAdminUser(null);
          setAuthError(null);
        }
      } else {
        setIsAdmin(false);
        setAdminUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async (): Promise<boolean> => {
    setLoading(true);
    setAuthError(null);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const email = result.user.email?.toLowerCase();
      
      const isBootstrapped = email === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase();
      let firestoreAdmin = false;
      try {
        const adminDoc = await getDoc(doc(db, 'admins', result.user.uid));
        firestoreAdmin = adminDoc.exists();
      } catch (err) {
        console.warn('Admin check:', err);
      }

      if (isBootstrapped || firestoreAdmin) {
        setIsAdmin(true);
        setAdminUser({
          uid: result.user.uid,
          email: result.user.email || '',
          role: 'admin',
          displayName: result.user.displayName || 'Bosh Muharrir',
          photoURL: result.user.photoURL || undefined,
        });
      } else {
        setIsAdmin(false);
        setAdminUser(null);
      }

      setLoading(false);
      return true;
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Tizimga kirishda kutilmagan xatolik yuz berdi';
      setAuthError(errorMsg);
      setLoading(false);
      return false;
    }
  };

  const logout = async () => {
    setLoading(true);
    try {
      await fbSignOut(auth);
      setUser(null);
      setIsAdmin(false);
      setAdminUser(null);
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      setLoading(false);
    }
  };

  const clearAuthError = () => setAuthError(null);

  return (
    <AuthContext.Provider
      value={{
        user,
        adminUser,
        isAdmin,
        loading,
        authError,
        loginWithGoogle,
        logout,
        clearAuthError,
        targetAdminEmail: BOOTSTRAPPED_ADMIN_EMAIL,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
